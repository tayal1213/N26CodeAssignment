package com.airtel.money.bean;

import java.sql.Timestamp;

public class InwardFileBean 
{
	private Long id;
	private String apbsTransactionCode;
	private String destinationBankIIN;
	private String destinationAccountType;
	private String ledgerFolioNumber;
	private String beneficiaryAadhaarNumber;
	private String beneficiaryAccountHolderName;
	private String sponsorBankIIN;
	private String usernumber;
	private String userName;
	private String userCreditreference;
	private String amount;
	private String reserved1;
	private String reserved2;
	private String reserved3;
	private String destinationBankAccountNumber;
	private String returnReasonCode;
	private String flatFileRow;
	private String outputFileName;
	private String status;
	private String reconStatus;
	private Timestamp reconTimestamp;
	
	public String getApbsTransactionCode() {
		return apbsTransactionCode;
	}
	public void setApbsTransactionCode(String apbsTransactionCode) {
		this.apbsTransactionCode = apbsTransactionCode;
	}
	public String getDestinationBankIIN() {
		return destinationBankIIN;
	}
	public void setDestinationBankIIN(String destinationBankIIN) {
		this.destinationBankIIN = destinationBankIIN;
	}
	public String getDestinationAccountType() {
		return destinationAccountType;
	}
	public void setDestinationAccountType(String destinationAccountType) {
		this.destinationAccountType = destinationAccountType;
	}
	public String getLedgerFolioNumber() {
		return ledgerFolioNumber;
	}
	public void setLedgerFolioNumber(String ledgerFolioNumber) {
		this.ledgerFolioNumber = ledgerFolioNumber;
	}
	public String getBeneficiaryAadhaarNumber() {
		return beneficiaryAadhaarNumber;
	}
	public void setBeneficiaryAadhaarNumber(String beneficiaryAadhaarNumber) {
		this.beneficiaryAadhaarNumber = beneficiaryAadhaarNumber;
	}
	public String getBeneficiaryAccountHolderName() {
		return beneficiaryAccountHolderName;
	}
	public void setBeneficiaryAccountHolderName(String beneficiaryAccountHolderName) {
		this.beneficiaryAccountHolderName = beneficiaryAccountHolderName;
	}
	public String getSponsorBankIIN() {
		return sponsorBankIIN;
	}
	public void setSponsorBankIIN(String sponsorBankIIN) {
		this.sponsorBankIIN = sponsorBankIIN;
	}
	public String getUsernumber() {
		return usernumber;
	}
	public void setUsernumber(String usernumber) {
		this.usernumber = usernumber;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserCreditreference() {
		return userCreditreference;
	}
	public void setUserCreditreference(String userCreditreference) {
		this.userCreditreference = userCreditreference;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getReserved1() {
		return reserved1;
	}
	public void setReserved1(String reserved1) {
		this.reserved1 = reserved1;
	}
	public String getReserved2() {
		return reserved2;
	}
	public void setReserved2(String reserved2) {
		this.reserved2 = reserved2;
	}
	public String getReserved3() {
		return reserved3;
	}
	public void setReserved3(String reserved3) {
		this.reserved3 = reserved3;
	}
	public String getDestinationBankAccountNumber() {
		return destinationBankAccountNumber;
	}
	public void setDestinationBankAccountNumber(String destinationBankAccountNumber) {
		this.destinationBankAccountNumber = destinationBankAccountNumber;
	}
	public String getReturnReasonCode() {
		return returnReasonCode;
	}
	public void setReturnReasonCode(String returnReasonCode) {
		this.returnReasonCode = returnReasonCode;
	}
	public String getFlatFileRow() {
		return flatFileRow;
	}
	public void setFlatFileRow(String flatFileRow) {
		this.flatFileRow = flatFileRow;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getReconStatus() {
		return reconStatus;
	}
	public void setReconStatus(String reconStatus) {
		this.reconStatus = reconStatus;
	}
	public Timestamp getReconTimestamp() {
		return reconTimestamp;
	}
	public void setReconTimestamp(Timestamp reconTimestamp) {
		this.reconTimestamp = reconTimestamp;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "InwardFileBean [id=" + id + ", apbsTransactionCode="
				+ apbsTransactionCode + ", destinationBankIIN="
				+ destinationBankIIN + ", destinationAccountType="
				+ destinationAccountType + ", ledgerFolioNumber="
				+ ledgerFolioNumber + ", beneficiaryAadhaarNumber="
				+ beneficiaryAadhaarNumber + ", beneficiaryAccountHolderName="
				+ beneficiaryAccountHolderName + ", sponsorBankIIN="
				+ sponsorBankIIN + ", usernumber=" + usernumber + ", userName="
				+ userName + ", userCreditreference=" + userCreditreference
				+ ", amount=" + amount + ", reserved1=" + reserved1
				+ ", reserved2=" + reserved2 + ", reserved3=" + reserved3
				+ ", destinationBankAccountNumber="
				+ destinationBankAccountNumber + ", returnReasonCode="
				+ returnReasonCode
				+ "]";
	}
	public String getOutputFileName() {
		return outputFileName;
	}
	public void setOutputFileName(String outputFileName) {
		this.outputFileName = outputFileName;
	}
	
}
