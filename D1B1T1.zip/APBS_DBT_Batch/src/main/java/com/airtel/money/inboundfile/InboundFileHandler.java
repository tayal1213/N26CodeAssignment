package com.airtel.money.inboundfile;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.integration.annotation.ServiceActivator;

/**
 * @author Atul Tayal
 *
 */
public class InboundFileHandler {

	private static final int BUFFER_SIZE = 4096;
	private JobLauncher jobLauncher;
	private JobRegistry jobRegistry;
	private String jobName;
	private String destDirectory;

	public String getDestDirectory() {
		return destDirectory;
	}

	public void setDestDirectory(String destDirectory) {
		this.destDirectory = destDirectory;
	}

	Logger logger = Logger.getLogger(InboundFileHandler.class);

	/**
	 * @param input
	 * @throws NoSuchJobException
	 * @throws JobParametersInvalidException
	 */
	@ServiceActivator
	public void handleFile(File input) throws NoSuchJobException, JobParametersInvalidException {

		logger.info("Copying file from: " + input.getPath());
		try {
		

			if (jobName != null) {
				String srcFileName = FilenameUtils.getName(input.getAbsolutePath());
				logger.info("Processing Response Profiling for File" + srcFileName);
			//	destDirectory = destDirectory + "\\" + srcFileName;
				checkFileDownload(input);
				logger.info("Kicking job : " + jobName + " with file Param  : " + destDirectory);
				Job job = jobRegistry.getJob(jobName);
				Date date = new Date();
				JobParameters jobParameters = new JobParametersBuilder().addDate("tranDate", date).toJobParameters();
				jobParameters = new JobParametersBuilder()
						.addLong("currentMS", System.currentTimeMillis()).toJobParameters();
				org.springframework.batch.core.JobExecution jobExec = jobLauncher.run(job, jobParameters);
				logger.info(jobExec.getStatus());
			} else {
				logger.info("Invalid Job name" + jobName);

			}

		} catch ( JobExecutionAlreadyRunningException | JobRestartException
				| JobInstanceAlreadyCompleteException e) {
			logger.info("Exception while handling the incoming file and processing it" + e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * @param input
	 */
	private void checkFileDownload(File input) {
		long fileSize = 0;
		if (input != null) {
			while (true) {
				try {
					if (fileSize == input.length()) {
						Thread.sleep(5000);
						if (fileSize == input.length()) {
							logger.info("file is comp and size is :" + fileSize);
							break;
						}
					} else {
						fileSize = input.length();
						logger.info("file size as of now : " + fileSize);
					}
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					logger.info("Exception while trying to check file completion");
				}
			}
		}
		logger.info("File Download complete");
	}

	/**
	 * @param zipFilePath
	 * @param destDirectory
	 * @throws IOException
	 */
	public void unzip(String zipFilePath, String destDirectory) throws IOException {
		File destDir = new File(destDirectory);
		if (!destDir.exists()) {
			destDir.mkdir();
		}
		ZipInputStream zipIn = new ZipInputStream(new FileInputStream(zipFilePath));
		ZipEntry entry = zipIn.getNextEntry();
		// iterates over entries in the zip file
		while (entry != null) {
			String filePath = destDirectory + File.separator + entry.getName();
			if (!entry.isDirectory()) {
				// if the entry is a file, extracts it
				extractFile(zipIn, filePath);
			} else {
				// if the entry is a directory, make the directory
				File dir = new File(filePath);
				dir.mkdir();
			}
			zipIn.closeEntry();
			entry = zipIn.getNextEntry();
		}
		zipIn.close();
	}

	/**
	 * @param zipIn
	 * @param filePath
	 * @throws IOException
	 */
	void extractFile(ZipInputStream zipIn, String filePath) throws IOException {
		BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filePath));
		byte[] bytesIn = new byte[BUFFER_SIZE];
		int read = 0;
		while ((read = zipIn.read(bytesIn)) != -1) {
			bos.write(bytesIn, 0, read);
		}
		bos.close();
	}

	public JobLauncher getJobLauncher() {
		return jobLauncher;
	}

	public void setJobLauncher(JobLauncher jobLauncher) {
		this.jobLauncher = jobLauncher;
	}

	public JobRegistry getJobRegistry() {
		return jobRegistry;
	}

	public void setJobRegistry(JobRegistry jobRegistry) {
		this.jobRegistry = jobRegistry;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

}