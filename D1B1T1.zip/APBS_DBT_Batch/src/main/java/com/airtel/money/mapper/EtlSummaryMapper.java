package com.airtel.money.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.airtel.money.bean.ETLSummary;

public class EtlSummaryMapper implements RowMapper<ETLSummary>
{

	@Override
	public ETLSummary mapRow(ResultSet rs, int arg1) throws SQLException 
	{   
		           
		ETLSummary etlSummary = new ETLSummary();
		etlSummary.setId(rs.getLong("ID"));;
		etlSummary.setUcId(rs.getString("UC_ID"));
		etlSummary.setInputFilename(rs.getString("INPUT_FILENAME"));
		etlSummary.setOutputFilename(rs.getString("OUTPUT_FILENAME"));
		etlSummary.setTotalAmount(rs.getDouble("TOTAL_AMOUNT"));
		etlSummary.setRecordCount(rs.getLong("RECORD_COUNT"));
		etlSummary.setStatus(rs.getString("STATUS"));
		etlSummary.setChannel(rs.getString("CHANNEL"));
		return etlSummary;
	}

}
