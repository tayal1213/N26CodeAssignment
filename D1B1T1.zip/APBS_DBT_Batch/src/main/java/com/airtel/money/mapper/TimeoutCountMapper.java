package com.airtel.money.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.airtel.money.bean.TimeoutCountBean;

public class TimeoutCountMapper implements RowMapper<TimeoutCountBean> 
{

	@Override
	public TimeoutCountBean mapRow(ResultSet rs, int arg1) throws SQLException 
	{
		
		
		
		TimeoutCountBean timeoutCountBean = new  TimeoutCountBean();
		timeoutCountBean.setEtlSummaryId(rs.getLong("ETL_SUMMARY_ID"));
		timeoutCountBean.setTotalCount(rs.getLong("TOTAL_COUNT"));
		timeoutCountBean.setTimeoutCount(rs.getLong("TIMEOUT_COUNT"));
		return timeoutCountBean;
	}

}
