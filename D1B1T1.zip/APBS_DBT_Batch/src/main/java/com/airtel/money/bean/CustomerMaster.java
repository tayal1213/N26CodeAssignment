package com.airtel.money.bean;

import java.sql.Timestamp;

public class CustomerMaster 
{
	private String actorType;
	private String msisdn;
	private String mpinResponse;
	private Timestamp createdTs;
	public String getActorType() {
		return actorType;
	}
	public void setActorType(String actorType) {
		this.actorType = actorType;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getMpinResponse() {
		return mpinResponse;
	}
	public void setMpinResponse(String mpinResponse) {
		this.mpinResponse = mpinResponse;
	}
	public Timestamp getCreatedTs() {
		return createdTs;
	}
	public void setCreatedTs(Timestamp createdTs) {
		this.createdTs = createdTs;
	}
	
}
