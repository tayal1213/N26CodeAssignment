package com.airtel.money.bean;

import java.sql.Timestamp;

public class DbtReconBean 
{
	
	//
	private String partnerTxnId;
	private String status;
	private String reconStatus;
	private Timestamp reconTimestamp;
	private TrmtReconData trmtReconData;
	private String coreTxnId;
	private String errorCode;
	public String getPartnerTxnId() {
		return partnerTxnId;
	}
	public void setPartnerTxnId(String partnerTxnId) {
		this.partnerTxnId = partnerTxnId;
	}
	public String getReconStatus() {
		return reconStatus;
	}
	public void setReconStatus(String reconStatus) {
		this.reconStatus = reconStatus;
	}
	public Timestamp getReconTimestamp() {
		return reconTimestamp;
	}
	public void setReconTimestamp(Timestamp reconTimestamp) {
		this.reconTimestamp = reconTimestamp;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public TrmtReconData getTrmtReconData() {
		return trmtReconData;
	}
	public void setTrmtReconData(TrmtReconData trmtReconData) {
		this.trmtReconData = trmtReconData;
	}
	public String getCoreTxnId() {
		return coreTxnId;
	}
	public void setCoreTxnId(String coreTxnId) {
		this.coreTxnId = coreTxnId;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
}
