package com.airtel.money.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.airtel.money.bean.TrmtReconData;

public class TrmtReconDataMapper implements RowMapper<TrmtReconData>
{
	@Override
	public TrmtReconData mapRow(ResultSet rs, int arg1) throws SQLException 
	{
		TrmtReconData trmtReconData = new TrmtReconData();
		trmtReconData.setTxnStatus(rs.getString("CUSTOM_COL_20"));
		trmtReconData.setCoreTxnId(rs.getString("BUSINESS_ENGINE_SESSION_ID"));
		trmtReconData.setErrorCode(rs.getString("CUSTOM_COL_30"));
		return trmtReconData;
	}

}
