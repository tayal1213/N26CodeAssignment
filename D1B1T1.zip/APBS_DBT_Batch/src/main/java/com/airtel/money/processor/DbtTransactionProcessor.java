package com.airtel.money.processor;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.camel.ProducerTemplate;
import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.AadhaarVaultRequest;
import com.airtel.money.bean.ApbsErrorLogBean;
import com.airtel.money.bean.DbtMappingDetailsBean;
import com.airtel.money.bean.DbtTransactionDataBean;
import com.airtel.money.bean.ETLTransaction;
import com.airtel.money.bean.GlobalBean;
import com.airtel.money.dao.DbtMappingDao;
import com.airtel.money.util.Utility;

public class DbtTransactionProcessor implements ItemProcessor<ETLTransaction, ETLTransaction> {
	Logger LOGGER = Logger.getLogger(DbtTransactionProcessor.class);

	private MessageSource messageSource;
	private DbtMappingDao dbtMappingDao;

	private String apbsTransactionCode = null;
	private String destinationBankIIN = null;
	private String destinationAccountType = null;
	private String ucId = null;
	private Utility util;
	private GlobalBean singletonMap;

	public GlobalBean getSingletonMap() {
		return singletonMap;
	}

	public void setSingletonMap(GlobalBean singletonMap) {
		this.singletonMap = singletonMap;
	}

	public Utility getUtil() {
		return util;
	}

	public void setUtil(Utility util) {
		this.util = util;
	}

	public void initIt() throws Exception {
		apbsTransactionCode = messageSource.getMessage("inward.records.apbs.transaction.code", null, Locale.US);
		destinationBankIIN = messageSource.getMessage("inward.records.destination.bank.iin", null, Locale.US);
		destinationAccountType = messageSource.getMessage("inward.records.destination.account.type", null, Locale.US);
		ucId = messageSource.getMessage("aadhar.transaction.ucid", null, Locale.US);
	}

	@Override
	public ETLTransaction process(ETLTransaction etlTransaction) throws Exception {
		/*
		 * 1-2 apbsTransactionCode --configurable --77 3-11 destinationBankIIN
		 * --configurable --508507 12-13 destinationAccountType --configurable
		 * --10 14-16 ledgerFolioNumber --file --FROM_ACTOR_PARAM5
		 * 
		 * 17-31 beneficiaryAadhaarNumber --File --ToActorParam1 32-71
		 * beneficiaryAccountholderName --File --ToActorParam2 72-80
		 * sponsorBankIIN --File --FromActorParam4 81-87 userNumber --File
		 * --FromActorParam1 88-107 userName --File --FromActorParam2 108-120
		 * userCreditReference --File --FromActorParam3 121-133 amount --File
		 * --Amount 134-143 reserved1 --File --PartnerTxnId
		 * 
		 * 144-153 reserved2 --Not Required 154-155 reserved3 --Not Required
		 * 156-175 destinationBankAccountNumber --File --TO_ACTOR_PARAM3 176-177
		 * returnReasonCode --File --ERROR_CODE
		 */
		LOGGER.info("APBS Batch: Record being processing for etlTransaction: " + etlTransaction);
		try {
			if (etlTransaction.getApbsErrorLogBean() != null) {
				dbtMappingDao.insertApbsErrorLog(etlTransaction.getApbsErrorLogBean());
				return null;
			}

			List<String> transactionCode = Arrays.asList(apbsTransactionCode.split(","));
			if (!transactionCode.contains(etlTransaction.getApbsTransactionCode())) {
				LOGGER.warn("apbsTransactionCode <" + etlTransaction.getApbsTransactionCode()
						+ "> could not match with configuration");
				throw new Exception("apbsTransactionCode <" + etlTransaction.getApbsTransactionCode()
						+ "> could not match with configuration");
			}
			if (!destinationBankIIN.equalsIgnoreCase(etlTransaction.getDestinationBankIIN())) {
				LOGGER.warn("destinationBankIIN <" + etlTransaction.getDestinationBankIIN()
						+ "> could not match with configuration");
				throw new Exception("destinationBankIIN <" + etlTransaction.getDestinationBankIIN()
						+ "> could not match with configuration");
			}
			boolean isTxnAlreadyExist = dbtMappingDao.isEtlTransactionAlready(etlTransaction.getPartnerTxnId());
			if (isTxnAlreadyExist) {
				LOGGER.warn("destinationBankIIN <" + etlTransaction.getDestinationBankIIN()
						+ "> could not match with configuration");
				throw new Exception("PartnerTxnId: " + etlTransaction.getPartnerTxnId() + "> already processed.");
			}
			/*
			 * if(!destinationAccountType.equalsIgnoreCase(etlTransaction.
			 * getDestinationAccountType())) {
			 * LOGGER.warn("destinationAccountType <"+etlTransaction.
			 * getDestinationAccountType()
			 * +"> could not match with configuration"); throw new
			 * Exception("destinationAccountType <"+etlTransaction.
			 * getDestinationAccountType()
			 * +"> could not match with configuration"); }
			 */

			etlTransaction.setCreatedChannel("FTP");
			etlTransaction.setUcId(ucId);
			etlTransaction.setCreatedTimestamp(new Timestamp(System.currentTimeMillis()));
			etlTransaction.setModifiedTimestamp(new Timestamp(System.currentTimeMillis()));
			etlTransaction.setFreeField1("PROCESSED");

			DbtMappingDetailsBean dbtMappingDetailsBean = dbtMappingDao
					.getDbtMappingDetailsBeanByAadhaar(etlTransaction.getToActorParam1());
			if (dbtMappingDetailsBean != null) {
				etlTransaction.setToActorMsisdn(dbtMappingDetailsBean.getCustMsisdn() == null ? null
						: Long.valueOf(dbtMappingDetailsBean.getCustMsisdn()));
				etlTransaction.setToActorParam2(dbtMappingDetailsBean.getAccHolderName() == null ? ""
						: dbtMappingDetailsBean.getAccHolderName());
				etlTransaction.setToActorParam3(dbtMappingDetailsBean.getAccNumber() == null ? ""
						: dbtMappingDetailsBean.getAccNumber().toString());
				etlTransaction.setFreeField10("AADHAAR");
			} else {

				AadhaarVaultRequest request = new AadhaarVaultRequest();
				request.setUid(etlTransaction.getToActorParam1());
				request.setRequestId("ABPS" + (new Date().getTime() * 94 % 100000000 * 6));
				request.setApiKey("paymentBank");
				String refKey = util.callVaultAPI(request);
				if (refKey != null) {
					dbtMappingDetailsBean = dbtMappingDao.getDbtMappingDetailsBeanByAadhaar(refKey);
					if (dbtMappingDetailsBean != null) {
						etlTransaction.setToActorMsisdn(dbtMappingDetailsBean.getCustMsisdn() == null ? null
								: Long.valueOf(dbtMappingDetailsBean.getCustMsisdn()));
						etlTransaction.setToActorParam2(dbtMappingDetailsBean.getAccHolderName() == null ? ""
								: dbtMappingDetailsBean.getAccHolderName());
						etlTransaction.setToActorParam3(dbtMappingDetailsBean.getAccNumber() == null ? ""
								: dbtMappingDetailsBean.getAccNumber().toString());
						singletonMap.getMap().put(refKey, etlTransaction.getToActorParam1());
						etlTransaction.setToActorParam1(refKey);
						etlTransaction.setFreeField10("REF_KEY");
					} else {

						LOGGER.warn("CustMsisdn could not found in DBT_MAPPING_DETAILS by Ref Key:" + refKey + "Aadhaar Number" + etlTransaction.getToActorParam1());
						throw new Exception("CustMsisdn could not found in DBT_MAPPING_DETAILS by REF KEY:" + refKey + "Aadhaar Number" + etlTransaction.getToActorParam1());

					}

				} else {

					etlTransaction.setFreeField4("AADHAR_VAULT_FAILURE");
					etlTransaction.setFreeField5("AADHAR_VAULT_FAILURE");
					etlTransaction.setStatus("1");
					etlTransaction.setErrorCode("124");
					etlTransaction.setFreeField10("AADHAAR");

				}
				return etlTransaction;

				// LOGGER.warn("CustMsisdn could not found in
				// DBT_MAPPING_DETAILS by aadhar number:"
				// + etlTransaction.getToActorParam1());
				// throw new Exception("CustMsisdn could not found in
				// DBT_MAPPING_DETAILS by aadhar number:"
				// + etlTransaction.getToActorParam1());
			}

		} catch (Exception e) {
			ApbsErrorLogBean apbsErrorLogBean = new ApbsErrorLogBean();
			apbsErrorLogBean.setBatchName("dbt-transaction-job");
			apbsErrorLogBean.setErrorMsg(e.getMessage());
			apbsErrorLogBean.setInputData(etlTransaction.getInputData());
			apbsErrorLogBean.setFileName(etlTransaction.getInputFilename());
			dbtMappingDao.insertApbsErrorLog(apbsErrorLogBean);
			LOGGER.error("APBS Batch:  Exception occured: " + e.getMessage());

			return null;
		}

		return etlTransaction;
	}

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public DbtMappingDao getDbtMappingDao() {
		return dbtMappingDao;
	}

	public void setDbtMappingDao(DbtMappingDao dbtMappingDao) {
		this.dbtMappingDao = dbtMappingDao;
	}

}
