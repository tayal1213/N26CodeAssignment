package com.airtel.money.reader;

import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.core.io.Resource;

import com.airtel.money.bean.DbtTransactionDataBean;
import com.airtel.money.bean.ETLTransaction;

public class FilenameItemReader extends FlatFileItemReader<ETLTransaction> {

	private DbtTransactionDataBean dbtTransactionDataBean;
    private Resource myresource;

    @Override
    public void setResource(Resource var1) 
    {
        super.setResource(var1);
        myresource = var1;
    }

    @Override
    protected ETLTransaction doRead() throws Exception 
    {    	
    	ETLTransaction etlTransaction = super.doRead();
        if (etlTransaction == null) {
            return null;
        }
        etlTransaction.setInputFilename(myresource.getFile().getName());
        etlTransaction.setEtlSummaryId(dbtTransactionDataBean.getMapFileEtlId().get(myresource.getFile().getName()));
        return etlTransaction;
    }
    
	public DbtTransactionDataBean getDbtTransactionDataBean() {
		return dbtTransactionDataBean;
	}

	public void setDbtTransactionDataBean(DbtTransactionDataBean dbtTransactionDataBean) {
		this.dbtTransactionDataBean = dbtTransactionDataBean;
	}   
}