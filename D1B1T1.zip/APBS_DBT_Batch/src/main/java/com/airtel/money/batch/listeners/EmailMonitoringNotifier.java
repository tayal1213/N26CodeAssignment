package com.airtel.money.batch.listeners;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.context.MessageSource;
import org.springframework.mail.javamail.JavaMailSender;

import com.airtel.money.adapter.mail.SendMailService;
import com.airtel.money.util.Property;

public class EmailMonitoringNotifier implements BatchMonitoringNotifier
{
	private SendMailService sendMailService;
	private JavaMailSender mailSender;
	private MessageSource messageSource;
	Logger logger = Logger.getLogger(EmailMonitoringNotifier.class);
	
	public void notify(JobExecution jobExecution, String batchStage) 
	{
		logger.info("ABPS Batch: Inside EmailMonitoringNotifier");
		String messageBody= null;
		String subject = null;
		if(batchStage.equals(Property.BATCH_BEFORE_JOB))
		{
			messageBody=createMsgContentBeforeJob(jobExecution);
			subject = messageSource.getMessage("batch.notifier.subject",null, Locale.US);
		}
		else
		{
			messageBody=createMsgContentAfterJob(jobExecution);
			subject = messageSource.getMessage("batch.notifier.subject",null, Locale.US);			
		}
		sendMailService.setFields(mailSender,
				messageSource.getMessage("batch.notifier.email.from",null,Locale.US),
				messageSource.getMessage("batch.notifier.email.to",null, Locale.US),
				messageSource.getMessage("batch.notifier.email.cc", null, Locale.US),
				null,
				null,
				subject,
				messageBody);
		sendMailService.sendMail();
		logger.info("ABPS Batch: EmailMonitoringNotifier completed");

	}
	private String createMsgContentBeforeJob(JobExecution jobExecution) 
	{
		StringBuilder content = new StringBuilder();
		content.append("Job execution #");
		content.append(jobExecution.getId());
		content.append(" of job instance ");
		content.append(jobExecution.getJobInstance().getJobName() + "(#"+jobExecution.getJobInstance().getId()+")");
		
		content.append(" started");
		return content.toString();
	}
	private String createMsgContentAfterJob(JobExecution jobExecution) {
		List<Throwable> exceptions = jobExecution.getFailureExceptions();
		
		
		StringBuilder content = new StringBuilder();
		content.append("Job execution #");
		content.append(jobExecution.getId());
		content.append(" of job instance ");
		content.append(jobExecution.getJobInstance().getJobName() + "(#"+jobExecution.getJobInstance().getId()+")");
		if(jobExecution.getStatus() == BatchStatus.FAILED) 
		{
			content.append(" failed with following exceptions:");
			for (Throwable exception : exceptions) 
			{
				content.append("<br/>");
				content.append(formatExceptionMessage(exception));
			}
			Object[] objEx = jobExecution.getStepExecutions().toArray();
			for(Object obj: objEx)
			{
				content.append("<br/>");
				content.append(obj.toString());
			}
		}
		else
		{
			content.append(" completed successfully.");
		}
		return content.toString();
	}
	private String formatExceptionMessage(Throwable exception) 
	{
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		exception.printStackTrace(new PrintStream(baos));
		return baos.toString();
	}
	
	public SendMailService getSendMailService() {
		return sendMailService;
	}
	public void setSendMailService(SendMailService sendMailService) {
		this.sendMailService = sendMailService;
	}
	public JavaMailSender getMailSender() {
		return mailSender;
	}
	public void setMailSender(JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}
	public MessageSource getMessageSource() {
		return messageSource;
	}
	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}
}
