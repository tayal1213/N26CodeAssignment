package com.airtel.money.app;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class BatchApp {

	@SuppressWarnings({ "resource", "unused" })
	public static void main(String[] args) {
		
	//	ApplicationContext ctx = new ClassPathXmlApplicationContext("camel-context.xml");
		
	//	ApplicationContext ctx = new FileSystemXmlApplicationContext("camel-context.xml");
		
		
		int[] n={1,2,3,9,4,7,8,10};
		largestThree(n);
	
	}

	private static void largestThree(int[] n) {
		
	int maxOne=0;
	int maxTwo=0;
	int maxThree=0;
	int maxFour=0;
	for(int i:n)
	{
		
		if(i>maxOne)
		{
			maxFour=maxThree;
			maxThree=maxTwo;
			maxTwo=maxOne;
			maxOne=i;
		}
		
		else if(i>maxTwo)
		{
			maxFour=maxThree;
			maxThree=maxTwo;
			maxTwo=i;
		}
		
		else if(i>maxThree)
		{
			maxFour=maxThree;
			maxThree=i;
			
		}
		else if(i>maxFour)
		{
		//	maxFour=maxThree;
			maxFour=i;
			
		}
	}
	System.out.println(maxOne);
	System.out.println(maxTwo);
	System.out.println(maxThree);
	System.out.println(maxFour);
		
	}
		
		//FileSystemXmlApplicationContext ftx = new FileSystemXmlApplicationContext();
		//RECORD_COUNT
	}

