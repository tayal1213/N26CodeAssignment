package com.airtel.money.writer;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.ApbsErrorLogBean;
import com.airtel.money.bean.CustomerMaster;
import com.airtel.money.dao.DbtMappingDao;
import com.airtel.money.util.Utility;

public class DbtCustUnblockWriter implements ItemWriter<CustomerMaster>
{

	private String wsUrl;
	private String wsUserId;
	private String wsPassword;
	
	private MessageSource messageSource; 
	private ItemWriter<CustomerMaster> delegate1;
	private DbtMappingDao dbtMappingDao;
	Logger LOGGER = Logger.getLogger(DbtCustUnblockWriter.class);
	public void initIt()  throws Exception
	{
		try 
		{
			wsUrl = messageSource.getMessage("cust.rest.block.user.ws.url",null,Locale.US);
			wsUserId =  messageSource.getMessage("cust.mpin.reset.user.id", null, Locale.US);
			wsPassword =  messageSource.getMessage("cust.mpin.reset.user.pws",null, Locale.US);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}
	@Override
	public void write(List<? extends CustomerMaster> items) throws Exception 
	{
		LOGGER.info("Inside DbtCustUnblockWriter.write");
		List<CustomerMaster> lstCustomerMaster = new ArrayList<CustomerMaster>();
		for(CustomerMaster cust: items)
		{
			try 
			{
				Map<String, Object> input = new HashMap<String, Object>();
				input.put("customerMaster", cust);
				String responseText = Utility.getFtlResponse("cust_block.ftl", input);
				
				
				URL obj = new URL(wsUrl);
				HttpURLConnection connection = (HttpURLConnection) obj.openConnection();

				connection.setRequestMethod("POST");
				connection.setRequestProperty("User-Agent", "Jakarta Commons-HttpClient/3.1");
				connection.setRequestProperty("SOAPAction", "");
				connection.setRequestProperty("APIVERSION", "1.0");
				connection.setRequestProperty("USERNAME", wsUserId);
				connection.setRequestProperty("PASSWORD", wsPassword);
				connection.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
				
				connection.setDoOutput(true);
				connection.setInstanceFollowRedirects(false);
				connection.setRequestMethod("POST");
				connection.setRequestProperty("Content-Type", "application/xml");

				OutputStream os = connection.getOutputStream();

				TransformerFactory tf = TransformerFactory.newInstance();
				Transformer transformer = tf.newTransformer();
				transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
				//FileReader fileReader = new FileReader("C:\\Documents and Settings\\Nagra\\My Documents\\Responseserver\\workingVoting\\VoteSubmitter\\Body.xml");
				
				StreamSource source = new StreamSource(new StringReader(responseText));
				StreamResult result = new StreamResult(os);
				transformer.transform(source, result);

				os.flush();
				connection.getResponseCode();

				int responseCode = connection.getResponseCode();

				BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();
				connection.disconnect();
				cust.setMpinResponse(response.toString());
				cust.setCreatedTs(new Timestamp(System.currentTimeMillis()));
				lstCustomerMaster.add(cust);
			} 
			catch (Exception e) 
			{
				LOGGER.warn("Error ocured:" +e.getMessage());
				ApbsErrorLogBean apbsErrorLogBean = new ApbsErrorLogBean();
				apbsErrorLogBean.setBatchName("dbt-transaction-job");
				apbsErrorLogBean.setErrorMsg(e.getMessage());
				dbtMappingDao.insertApbsErrorLog(apbsErrorLogBean);
			}
			
		}
		delegate1.write(lstCustomerMaster);
	}
	public MessageSource getMessageSource() {
		return messageSource;
	}
	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}
	public ItemWriter<CustomerMaster> getDelegate1() {
		return delegate1;
	}
	public void setDelegate1(ItemWriter<CustomerMaster> delegate1) {
		this.delegate1 = delegate1;
	}
	public DbtMappingDao getDbtMappingDao() {
		return dbtMappingDao;
	}
	public void setDbtMappingDao(DbtMappingDao dbtMappingDao) {
		this.dbtMappingDao = dbtMappingDao;
	}
	
}
