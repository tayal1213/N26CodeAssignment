package com.airtel.money.bean;

public class AadhaarVaultResponse {
	private Result result;

	private String requestId;

	private String referenceKey;

	private String uid;

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public Result getResult() {
		return result;
	}

	public void setResult(Result result) {
		this.result = result;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getReferenceKey() {
		return referenceKey;
	}

	public void setReferenceKey(String referenceKey) {
		this.referenceKey = referenceKey;
	}

	@Override
	public String toString() {
		return "ClassPojo [result = " + result + ", requestId = " + requestId + ", referenceKey = " + referenceKey
				+ "]";
	}
}
