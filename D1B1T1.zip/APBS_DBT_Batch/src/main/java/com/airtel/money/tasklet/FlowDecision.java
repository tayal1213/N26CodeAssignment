package com.airtel.money.tasklet;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;
import org.springframework.context.MessageSource;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;


import com.airtel.money.bean.InwardFileDataBean;
import com.airtel.money.dao.DbtMappingDao;
 
public class FlowDecision implements JobExecutionDecider {
     
    private Logger LOGGER = LoggerFactory.getLogger(this.getClass());
	private MessageSource messageSource;
	private DbtMappingDao dbtMappingDao;
	private InwardFileDataBean inwardFileDataBean;
	private MessageChannel sftpChannel;
     
    public FlowExecutionStatus decide(JobExecution jobExecution, StepExecution stepExecution) 
    {
    	LOGGER.info("Inside FlowDecision.decide");
        dbtMappingDao.updateETLSummaryFileName(inwardFileDataBean.getEtlSummaryId(), inwardFileDataBean.getFileName());
		File file = new File(messageSource.getMessage("dbt.inward.output.file.location", null, Locale.US)+inwardFileDataBean.getFileName());
		 
        if (file.exists()) 
        {
             Message message = MessageBuilder.withPayload(file).build();
            try {
                sftpChannel.send(message);
            } catch (Exception e) {
                System.out.println("Could not send file per SFTP: " + e);
            }
        } else {
            System.out.println("File does not exist.");
        }
        if(inwardFileDataBean.getCurCount()>=inwardFileDataBean.getLstEtlSummary().size()-1)
        {
        	//For DBT credit file creation
        	/*SimpleDateFormat sdf = new SimpleDateFormat("_dd_MM_yyyy_HH_mm_ss");
        	try {
        		File file = new File(messageSource.getMessage("dbt.credit.file.location",null, Locale.US)+messageSource.getMessage("dbt.credit.file.name",null, Locale.US)+sdf.format(new Date())+messageSource.getMessage("dbt.credit.file.extension",null, Locale.US));
            	file.createNewFile();
            	inwardFileDataBean.setDbtCreditFileName(file.getName());
            	
			} catch (Exception e) {
				e.printStackTrace();
			}*/
        	
        	
        	LOGGER.info("FlowDecision.decide: Status: COMPLETED");
        	return FlowExecutionStatus.COMPLETED;
        }
        else
        {
        	LOGGER.info("FlowDecision.decide: Status: UNKNOWN");
        	inwardFileDataBean.setCurCount(inwardFileDataBean.getCurCount()+1);
        	inwardFileDataBean.setEtlSummaryId(inwardFileDataBean.getLstEtlSummary().get(inwardFileDataBean.getCurCount()).getId());
        	return FlowExecutionStatus.UNKNOWN;
        }
       
        
    }

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public DbtMappingDao getDbtMappingDao() {
		return dbtMappingDao;
	}

	public void setDbtMappingDao(DbtMappingDao dbtMappingDao) {
		this.dbtMappingDao = dbtMappingDao;
	}

	public InwardFileDataBean getInwardFileDataBean() {
		return inwardFileDataBean;
	}

	public void setInwardFileDataBean(InwardFileDataBean inwardFileDataBean) {
		this.inwardFileDataBean = inwardFileDataBean;
	}

	public MessageChannel getSftpChannel() {
		return sftpChannel;
	}

	public void setSftpChannel(MessageChannel sftpChannel) {
		this.sftpChannel = sftpChannel;
	}
    
    
}