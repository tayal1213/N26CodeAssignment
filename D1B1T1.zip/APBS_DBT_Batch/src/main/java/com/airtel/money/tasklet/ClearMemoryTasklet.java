package com.airtel.money.tasklet;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.GlobalBean;
import com.airtel.money.dao.DbtMappingDao;

public class ClearMemoryTasklet implements Tasklet {

	Logger LOGGER = Logger.getLogger(ClearMemoryTasklet.class);
	private GlobalBean singletonMap;
	private MessageSource messageSource;
	private DbtMappingDao dbtMappingDao;

	public DbtMappingDao getDbtMappingDao() {
		return dbtMappingDao;
	}

	public void setDbtMappingDao(DbtMappingDao dbtMappingDao) {
		this.dbtMappingDao = dbtMappingDao;
	}

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public GlobalBean getSingletonMap() {
		return singletonMap;
	}

	public void setSingletonMap(GlobalBean singletonMap) {
		this.singletonMap = singletonMap;
	}

	@Override
	public RepeatStatus execute(StepContribution arg0, ChunkContext arg1) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.info("APBS Batch:  Inside ClearMemoryTasklet.execute()");
		singletonMap.getMap().clear();
		if (dbtMappingDao.isAllInwardCompleted()) {
			dbtMappingDao.updateAadhaarVaultNumbers();
		}
		return RepeatStatus.FINISHED;
	}

	/*
	 * public static void main(String[] args) { Map<String,String> map=new
	 * HashMap<String,String>();
	 * 
	 * map.put("bjdc", "efjjc"); map.clear(); map.get("bjdc");
	 * System.out.println(map.get("bjdc"));
	 * 
	 * }
	 */

}
