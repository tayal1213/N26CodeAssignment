package com.airtel.money.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.airtel.money.bean.AadharSeedingResponseXmlBean;

public class XMLResponseMapper implements RowMapper<AadharSeedingResponseXmlBean> 
{
	Logger LOGGER = Logger.getLogger(XMLResponseMapper.class);

	@Override
	public AadharSeedingResponseXmlBean mapRow(ResultSet rs, int arg1) 	throws SQLException 
	{
		AadharSeedingResponseXmlBean aadharSeedingResponseXmlBean = new AadharSeedingResponseXmlBean();
		try 
		{
			aadharSeedingResponseXmlBean.setAadharNo(rs.getString("AADHAAR_NO"));
			aadharSeedingResponseXmlBean.setMappedIin(rs.getString("MAPPED_IIN"));
			aadharSeedingResponseXmlBean.setScheme(rs.getString("SCHEME"));
			aadharSeedingResponseXmlBean.setMandateCustDate(rs.getString("MANDATE_CUST_DATE"));
			aadharSeedingResponseXmlBean.setMappingStatus(rs.getString("MAPPING_STATUS"));
			aadharSeedingResponseXmlBean.setUidReasonCode(rs.getString("UID_REASON_CODE"));
			aadharSeedingResponseXmlBean.setUidResult(rs.getString("UID_RESULT"));
			aadharSeedingResponseXmlBean.setAccepted(rs.getString("ACCEPTED"));
		} 
		catch (Exception e) 
		{
			LOGGER.error("APBS Batch:  Exception occured: "+e.getMessage());
		}
		
		
		return aadharSeedingResponseXmlBean;
	}

}
