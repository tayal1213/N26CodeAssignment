package com.airtel.money.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.airtel.money.bean.SuccessPayoutBean;

public class SuccessPayoutMapper implements RowMapper<SuccessPayoutBean> {

	Logger LOGGER = Logger.getLogger(SuccessPayoutMapper.class);

	@Override
	public SuccessPayoutBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		SuccessPayoutBean bean = null;
		LOGGER.info("APBS Batch:  Inside SuccessPayoutLatLonagMapper ");
		if (rs != null) {
			bean = new SuccessPayoutBean();
			bean.setCustMsisdn(rs.getString("CUST_MSISDN").substring(3));
		//	bean.setCustMsisdn("9560011052");
			bean.setRetMsisdn(rs.getString("MSISDN"));
			bean.setShopName(rs.getString("SHOP_NAME"));
			bean.setRetadd1(rs.getString("ACTOR_ADDRESS_1"));
			bean.setRetAdd2(rs.getString("ACTOR_ADDRESS_2"));
			bean.setRetAdd3(rs.getString("ACTOR_ADDRESS_3"));
			bean.setRetcity(rs.getString("ACTOR_CITY"));
			bean.setAmount(rs.getString("AMOUNT"));

		}
		return bean;
	}
//	7387700267
//	9560011052

}