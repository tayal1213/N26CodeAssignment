package com.airtel.money.processor;

import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.log4j.Logger;
import org.springframework.context.MessageSource;

import com.airtel.money.dao.DbtMappingDao;

public class UpdateTransactionBean 
{
	Logger LOGGER = Logger.getLogger(UpdateTransactionBean.class);
	private DbtMappingDao dbtMappingDao = null;
	private MessageSource messageSource;
	public void updateTransaction(final Exchange exchange,Map<String,Object> body) 
	{
		LOGGER.info("Inside UpdateTransactionBean.updateTransaction with body "+body);
		try 
		{
			if(body!=null )
			{
				dbtMappingDao.updateTransaction(body);
			}
			else
			{
				LOGGER.info("Body is null");
			}
		} 
		catch (Exception e) 
		{
			LOGGER.warn("APBS Batch:  Exception occured: "+e.getMessage());
		}
		
    }
	public DbtMappingDao getDbtMappingDao() {
		return dbtMappingDao;
	}
	public void setDbtMappingDao(DbtMappingDao dbtMappingDao) {
		this.dbtMappingDao = dbtMappingDao;
	}
	public MessageSource getMessageSource() {
		return messageSource;
	}
	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}
	
}
