package com.airtel.money.bean;

public class TrmtReconData 
{
	private String txnStatus;
	private String coreTxnId;
	private String errorCode;
	
	public String getTxnStatus() {
		return txnStatus;
	}

	public void setTxnStatus(String txnStatus) {
		this.txnStatus = txnStatus;
	}

	public String getCoreTxnId() {
		return coreTxnId;
	}

	public void setCoreTxnId(String coreTxnId) {
		this.coreTxnId = coreTxnId;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	

}
