package com.airtel.money.util;

import java.util.Locale;

public interface Property
{
    /* Following member is used to define LOCALE to EN */
    Locale LOCALE_EN = new Locale("EN");
    String ERROR = "ERROR";
    String TRUE = "true";
    String DOT = ".";
    String UNDER_SCORE = "_";
    String FILE_EXT_XLS = "xls";
    String NO_RECORD_FOUND = "NO DATA FOUND";
    String EMPTY_STRING = "";
    String HYPHEN = "-";
    String XLS = "XLS";
    String COMMA = ",";
    String SPACE = " ";
    String MODULUS = "%";
    
    String BATCH_BEFORE_JOB="BEFORE_JOB";
    String BATCH_AFTER_JOB="AFTER_JOB";
}
