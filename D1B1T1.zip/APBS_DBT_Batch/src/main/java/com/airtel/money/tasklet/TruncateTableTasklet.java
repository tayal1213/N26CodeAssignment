package com.airtel.money.tasklet;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import com.airtel.money.dao.DbtMappingDao;

public class TruncateTableTasklet implements Tasklet {
	Logger LOGGER = Logger.getLogger(TruncateTableTasklet.class);
	private DbtMappingDao dbtMappingDao;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info("APBS Batch:  Inside TruncateTableTasklet.execute()");

		try {
			dbtMappingDao.truncateXmlDataTbl();
		} catch (Exception e) {
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}

		return RepeatStatus.FINISHED;
	}

	public DbtMappingDao getDbtMappingDao() {
		return dbtMappingDao;
	}

	public void setDbtMappingDao(DbtMappingDao dbtMappingDao) {
		this.dbtMappingDao = dbtMappingDao;
	}

}
