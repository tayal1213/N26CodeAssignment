package com.airtel.money.processor;

import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.DbtMappingDetailsBean;
import com.airtel.money.service.SmsService;
import com.airtel.money.util.Utility;

public class RespSendSmsProcessor implements ItemProcessor<DbtMappingDetailsBean, DbtMappingDetailsBean> 
{
	private SmsService smsService;
	private MessageSource messageSource;
	Logger logger = Logger.getLogger(RespSendSmsProcessor.class);
	@Override
	public DbtMappingDetailsBean process(DbtMappingDetailsBean dbtMappingDetailsBean)throws Exception 
	{
		String msgContent = messageSource.getMessage("sms.txt.dbt.confirmation",null,Locale.US);
		try 
		{
			if(!Utility.isEmpty(dbtMappingDetailsBean.getDbtStatus()) && dbtMappingDetailsBean.getDbtStatus().equalsIgnoreCase("ACTIVE"))
			{
				String smsStatus = smsService.sendSMS(dbtMappingDetailsBean.getCustMsisdn(), msgContent);
				dbtMappingDetailsBean.setSmsStatus(smsStatus);
				//dbtMappingDetailsBean.setSmsStatus("SUCCESS");
				dbtMappingDetailsBean.setSmsTxt(msgContent);
				
				
			}
			else
			{
				dbtMappingDetailsBean.setSmsStatus("NO");
			}
			
		} 
		catch (Exception e) 
		{
			logger.error("Error occured in RespSendSmsProcessor.process: "+ e.getMessage());
		}
		
		return dbtMappingDetailsBean;
	}

	public SmsService getSmsService() {
		return smsService;
	}

	public void setSmsService(SmsService smsService) {
		this.smsService = smsService;
	}

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}
	

}
