package com.airtel.money.mapper;

import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import com.airtel.money.bean.AadhaarVaultRequest;
import com.airtel.money.bean.ApbsErrorLogBean;
import com.airtel.money.bean.ETLTransaction;
import com.airtel.money.dao.DbtMappingDao;
import com.airtel.money.util.Utility;

public class DbtTranMapper implements FieldSetMapper<ETLTransaction> {
	Logger LOGGER = Logger.getLogger(DbtTranMapper.class);

	private DbtMappingDao dbtMappingDao;


	@Override
	public ETLTransaction mapFieldSet(FieldSet fieldSet) throws BindException {

		ETLTransaction etlTransaction = new ETLTransaction();

		/*
		 * 1-2 apbsTransactionCode --configurable --77 3-11 destinationBankIIN
		 * --configurable --508507 12-13 destinationAccountType --configurable
		 * --10 14-16 ledgerFolioNumber --file --FROM_ACTOR_PARAM5
		 * 
		 * 17-31 beneficiaryAadhaarNumber --File --ToActorParam1 32-71
		 * beneficiaryAccountholderName --File --ToActorParam2 72-80
		 * sponsorBankIIN --File --FromActorParam4 81-87 userNumber --File
		 * --FromActorParam1 88-107 userName --File --FromActorParam2 108-120
		 * userCreditReference --File --FromActorParam3 121-133 amount --File
		 * --Amount 134-143 reserved1 --File --PartnerTxnId
		 * 
		 * 144-153 reserved2 --Not Required 154-155 reserved3 --Not Required
		 * 156-175 destinationBankAccountNumber --File --TO_ACTOR_PARAM3 176-177
		 * returnReasonCode --File --ERROR_CODE
		 */
		try {
			etlTransaction.setInputData(fieldSet.readString("inputData"));
			etlTransaction.setApbsTransactionCode(fieldSet.readString("apbsTransactionCode"));
			etlTransaction
					.setDestinationBankIIN(fieldSet.readString("destinationBankIIN").replaceFirst("^0+(?!$)", ""));
			etlTransaction.setDestinationAccountType(fieldSet.readString("destinationAccountType"));

			etlTransaction.setFromActorParam5("ledgerFolioNumber");
			etlTransaction.setPartnerTxnId(
					Long.valueOf(fieldSet.readString("reserved1").trim().replaceFirst("^0+(?!$)", "")));
			DecimalFormat df2 = new DecimalFormat("#.##");
			Double amount = Double.valueOf(fieldSet.readString("amount").trim()) / 100;
			etlTransaction.setAmount(Double.valueOf(df2.format(amount)));
			etlTransaction.setFromActorParam1(fieldSet.readString("userNumber"));
			etlTransaction.setFromActorParam2(fieldSet.readString("userName"));
			etlTransaction.setFromActorParam3(fieldSet.readString("userCreditReference"));
			etlTransaction.setFromActorParam4(fieldSet.readString("sponsorBankIIN"));
			etlTransaction
					.setToActorParam1(fieldSet.readString("beneficiaryAadhaarNumber").replaceFirst("^0+(?!$)", ""));
			etlTransaction.setToActorParam2(fieldSet.readString("beneficiaryAccountholderName"));
			etlTransaction.setToActorParam3(fieldSet.readString("destinationBankAccountNumber"));
			etlTransaction.setErrorCode(fieldSet.readString("returnReasonCode"));
			etlTransaction.setFreeField2(fieldSet.readString("reserved2").trim().replaceFirst("^0+(?!$)", ""));

		} catch (Exception e) {
			ApbsErrorLogBean apbsErrorLogBean = new ApbsErrorLogBean();
			apbsErrorLogBean.setBatchName("dbt-transaction-job");
			apbsErrorLogBean.setErrorMsg(e.getMessage());
			apbsErrorLogBean.setInputData(etlTransaction.getInputData());
			etlTransaction.setApbsErrorLogBean(apbsErrorLogBean);
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}
		return etlTransaction;
	}

	public DbtMappingDao getDbtMappingDao() {
		return dbtMappingDao;
	}

	public void setDbtMappingDao(DbtMappingDao dbtMappingDao) {
		this.dbtMappingDao = dbtMappingDao;
	}

}
