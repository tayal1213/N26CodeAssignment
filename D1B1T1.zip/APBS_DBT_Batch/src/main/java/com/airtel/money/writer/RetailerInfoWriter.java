package com.airtel.money.writer;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.SuccessPayoutBean;
import com.airtel.money.service.SmsService;

public class RetailerInfoWriter implements ItemWriter<SuccessPayoutBean> {

	static final Logger Log = Logger.getLogger(RetailerInfoWriter.class);

	private ItemWriter<SuccessPayoutBean> delegate;

	private MessageSource messageSource;

	private SmsService smsService;

	public SmsService getSmsService() {
		return smsService;
	}

	public void setSmsService(SmsService smsService) {
		this.smsService = smsService;
	}

	List<SuccessPayoutBean> list = new ArrayList<SuccessPayoutBean>();

	public ItemWriter<SuccessPayoutBean> getDelegate() {
		return delegate;
	}

	public void setDelegate(ItemWriter<SuccessPayoutBean> delegate) {
		this.delegate = delegate;
	}

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	@Override
	public void write(List<? extends SuccessPayoutBean> listParam) throws Exception {

		Log.info("APBS Batch: Inside RetailerInfoWriter.write()");
		String msgContentRetailer = messageSource.getMessage("dbt.success.payput.nearest.retailers.message", null, Locale.US);
		String msgContentAmount=messageSource.getMessage("dbt.success.payput.amount.message", null, Locale.US);
		List<SuccessPayoutBean> tempList = new ArrayList<>();
		/*
		 * for (Map<SuccessPayoutBean, List<SuccessPayoutBean>> map : listParam)
		 * {
		 * 
		 * Set<Entry<SuccessPayoutBean, List<SuccessPayoutBean>>> entrySet =
		 * map.entrySet(); for (Entry<SuccessPayoutBean,
		 * List<SuccessPayoutBean>> entry : entrySet) { SuccessPayoutBean key =
		 * entry.getKey(); List<SuccessPayoutBean> list = entry.getValue();
		 * SuccessPayoutBean bean = null; SuccessPayoutBean tempbean = null;
		 * boolean isListIteratedOnce = false;
		 * 
		 * if (key.getMessageStatus() != null &&
		 * !key.getMessageStatus().equalsIgnoreCase("No Nearby Retailers Found"
		 * )) { for (SuccessPayoutBean retInfo : list) {
		 * 
		 * if (list.size() > 1 && !isListIteratedOnce) { tempbean = new
		 * SuccessPayoutBean(); tempbean.setMsisdn(key.getMsisdn());
		 * tempbean.setRetAddress(retInfo.getRetAddress());
		 * tempbean.setRetCity(retInfo.getRetCity());
		 * tempbean.setRetMsisdn(retInfo.getRetMsisdn());
		 * tempbean.setSiteId(retInfo.getSiteId()); // this.list.add(bean); //
		 * tempList.add(bean); // int modifiedSize = list.size() - 1;
		 * isListIteratedOnce = true; } else if (isListIteratedOnce) { bean =
		 * new SuccessPayoutBean(); bean.setMsisdn(key.getMsisdn());
		 * bean.setRetAddress(tempbean.getRetAddress() + "|" +
		 * retInfo.getRetAddress()); bean.setRetCity(tempbean.getRetCity() + "|"
		 * + retInfo.getRetCity()); if (tempbean.getRetMsisdn() != null &&
		 * retInfo.getRetMsisdn() != null) {
		 * bean.setRetMsisdn(tempbean.getRetMsisdn() + "|" +
		 * retInfo.getRetMsisdn()); msgContent = msgContent +
		 * bean.getRetAddress() + bean.getRetAddress(); } else msgContent =
		 * msgContent + bean.getRetAddress();
		 * bean.setSiteId(retInfo.getSiteId());
		 * bean.setLatitude(key.getLatitude());
		 * bean.setLongitude(key.getLongitude()); bean.setId(key.getId());
		 * 
		 * tempList.add(bean);
		 * 
		 * } else if (list.size() == 1) { bean = new SuccessPayoutBean();
		 * bean.setRetAddress(retInfo.getRetAddress());
		 * bean.setRetCity(retInfo.getRetCity());
		 * bean.setMsisdn(key.getMsisdn()); if (retInfo.getRetMsisdn() != null)
		 * { bean.setRetMsisdn(retInfo.getRetMsisdn()); msgContent = msgContent
		 * + bean.getRetAddress() + bean.getRetAddress(); } else msgContent =
		 * msgContent + bean.getRetAddress();
		 * bean.setRetMsisdn(retInfo.getRetMsisdn());
		 * bean.setSiteId(retInfo.getSiteId());
		 * bean.setLatitude(key.getLatitude());
		 * bean.setLongitude(key.getLongitude()); bean.setId(key.getId());
		 * tempList.add(bean);
		 * 
		 * }
		 * 
		 * } } else { bean = new SuccessPayoutBean();
		 * bean.setLatitude(key.getLatitude());
		 * bean.setLongitude(key.getLongitude());
		 * bean.setMsisdn(key.getMsisdn()); bean.setId(key.getId());
		 * tempList.add(bean);
		 * 
		 * } try { if (key.getMessageStatus() != null &&
		 * !key.getMessageStatus().equalsIgnoreCase("No Nearby Retailers Found")
		 * && smsService.sendSMS(key.getMsisdn(),
		 * msgContent).equalsIgnoreCase("SUCCESS")) {
		 * bean.setMessageStatus("MESSAGE_SENT"); } else if
		 * (key.getMessageStatus() != null &&
		 * key.getMessageStatus().equalsIgnoreCase("No Nearby Retailers Found"))
		 * { bean.setMessageStatus("NO NEARBY RETAILER"); } else
		 * bean.setMessageStatus("FAILED"); } catch (Exception e) {
		 * Log.info("Exception Occured While Sending ");
		 * bean.setMessageStatus("FAILED"); } for (SuccessPayoutBean retInfo :
		 * tempList) { if
		 * (retInfo.getMsisdn().equalsIgnoreCase(bean.getMsisdn()))
		 * retInfo.setMessageStatus(bean.getMessageStatus());
		 * this.list.add(retInfo); } }
		 * 
		 * }
		 * 
		 * delegate.write(list);
		 * 
		 * }
		 */

		for (SuccessPayoutBean bean : listParam) {

			try {
				msgContentRetailer = msgContentRetailer + bean.getShopName();
				msgContentAmount=msgContentAmount.replaceAll("amount", bean.getAmount());
				msgContentAmount=msgContentAmount.replaceAll("accountNum", bean.getCustMsisdn());
				
				if (bean.getRetadd1() != null)
					msgContentRetailer = msgContentRetailer + "," + bean.getRetadd1();
				if (bean.getRetAdd2() != null)
					msgContentRetailer = msgContentRetailer + "," + bean.getRetAdd2();
				if (bean.getRetAdd3() != null)
					msgContentRetailer = msgContentRetailer + "," + bean.getRetAdd3();
				msgContentRetailer = msgContentRetailer + ","  + bean.getRetcity() +","+ bean.getRetMsisdn();
				if (smsService.sendSMS(bean.getCustMsisdn(), msgContentAmount).equalsIgnoreCase("SUCCESS"))
					bean.setMessaeStatusAmount("MESSAGE_SENT");
				else
					bean.setMessaeStatusAmount("FAILED");
				if (smsService.sendSMS(bean.getCustMsisdn(), msgContentRetailer).equalsIgnoreCase("SUCCESS"))
					bean.setMessaeStatusRetailerInfo("MESSAGE_SENT");
				else
					bean.setMessaeStatusRetailerInfo("FAILED");
			} catch (Exception e) {
				Log.info("Exception Occured While Sending ");
			}
			tempList.add(bean);

		}
		delegate.write(tempList);

	}

}