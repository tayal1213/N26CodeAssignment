package com.airtel.money.util;

public interface Constants 
{
	String ACTIVATION_STATUS_YES = "INITIATED_FOR_YES";
	String ACTIVATION_STATUS_NO = "INITIATED_FOR_NO";
	String OD_FLAG_YES = "Y";
}
