package com.airtel.money.tasklet;

import java.io.File;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.AadhaarVaultRequest;
import com.airtel.money.bean.AadharSeedingResponseXmlBean;
import com.airtel.money.bean.DbtMappingDataBean;
import com.airtel.money.dao.DbtMappingDao;
import com.airtel.money.processor.ResponseProfilingProcessor;
import com.airtel.money.service.XmlBeanHandler;
import com.airtel.money.util.Utility;

public class AadharXmlToDB implements Tasklet {
	Logger LOGGER = Logger.getLogger(AadharXmlToDB.class);
	private DbtMappingDao dbtMappingDao;
	private DbtMappingDataBean dbtMappingDataBean;
	private MessageSource messageSource;
	private Utility util;

	public Utility getUtil() {
		return util;
	}

	public void setUtil(Utility util) {
		this.util = util;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info("APBS Batch:  Inside AadharXmlToDB.execute()");

		try {
			// dbtMappingDao.truncateXmlDataTbl();
			File folder = new File(messageSource.getMessage("response.profiling.xml.input.dir.path", null, Locale.US));
			File[] listOfFiles = folder.listFiles();

			for (File file : listOfFiles) {
				if (file.isFile() && (file.getName().endsWith(".xml") || file.getName().endsWith(".XML"))) {
					System.out.println(file.getName());
					SAXParserFactory factory = SAXParserFactory.newInstance();
					SAXParser saxParser = factory.newSAXParser();
					XmlBeanHandler userhandler = new XmlBeanHandler();
					saxParser.parse(file, userhandler);
					List<AadharSeedingResponseXmlBean> lstXmlBeans = userhandler.getLstasrBean();
					for (AadharSeedingResponseXmlBean bean : lstXmlBeans) {

						if (dbtMappingDao.isAadhaarExist(bean.getAadharNo().trim())) {
							dbtMappingDao.insert(bean);
						} else {
							AadhaarVaultRequest request = new AadhaarVaultRequest();
							request.setUid(bean.getAadharNo().trim());
							request.setRequestId("ABPS" + (new Date().getTime() * 94 % 100000000 * 6));
							request.setApiKey("paymentBank");
							String refKey = util.callVaultAPI(request);
							if (refKey != null) {
								bean.setAadharNo(refKey);
								dbtMappingDao.insert(bean);
							} else
								LOGGER.info("REF_KEY Recieved from Aadhaar_vault is empty");
						}
					}

				}
			}
		} catch (Exception e) {
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}

		return RepeatStatus.FINISHED;
	}

	public DbtMappingDao getDbtMappingDao() {
		return dbtMappingDao;
	}

	public void setDbtMappingDao(DbtMappingDao dbtMappingDao) {
		this.dbtMappingDao = dbtMappingDao;
	}

	public DbtMappingDataBean getDbtMappingDataBean() {
		return dbtMappingDataBean;
	}

	public void setDbtMappingDataBean(DbtMappingDataBean dbtMappingDataBean) {
		this.dbtMappingDataBean = dbtMappingDataBean;
	}

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

}
