package com.airtel.money.adapter.mail;

import java.io.File;
import java.io.FileFilter;
import java.io.FilenameFilter;

import javax.ejb.Stateless;
import javax.mail.Message;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;
//import org.jboss.seam.annotations.Name;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;

import com.airtel.money.util.Utility;
 
@Stateless
//@Name("SendMail")
public class SendMailService {
 
    Logger logger = Logger.getLogger(SendMailService.class);
    private JavaMailSender mailSender;
    private String senderAddress;
    private String recipientTO;
    private String recipientCC;
    private String attachmentFilePath;
    private String attachmentFileName;
    private String subject;
    private String bodyData;
 
    // set the fields
    public void setFields(JavaMailSender mailSender, String senderAddress, String recipientTO, String recipientCC, String attachmentFilePath, String attachmentFileName, String subject, String bodyData) {
 
        this.mailSender = mailSender;
        this.senderAddress = senderAddress;
        this.recipientTO = recipientTO;
        this.recipientCC = recipientCC;
        this.attachmentFilePath = attachmentFilePath;
        this.attachmentFileName=attachmentFileName;
        this.subject = subject;
        this.bodyData = bodyData;
        
    }
 
    public void sendMail() {
        logger.debug("Initiating request to send Email.");
        // read directory
       
        
 
        MimeMessagePreparator preparator = new MimeMessagePreparator() {
            public void prepare(MimeMessage mimeMessage) throws Exception {
                //mimeMessage.setRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
            	mimeMessage.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientTO));
            	if(recipientCC!= null && !recipientCC.isEmpty())
            		mimeMessage.setRecipients(Message.RecipientType.CC, InternetAddress.parse(recipientCC));
                mimeMessage.setFrom(new InternetAddress(senderAddress));
                mimeMessage.setSubject(subject);
                
                // MimeMessagesHelper is needed for the attachment. The Boolean value in
                // constructor is for multipart/data = true
                MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
                if(!Utility.isEmpty(attachmentFilePath))
                {
                	logger.info("Attachment path :" + attachmentFilePath);
                    File directory = new File(attachmentFilePath);
                    // get file from directory
                    //final File file = directory.listFiles(FILE_FILTER)[0];
                    
                    final File file = directory.listFiles(new FilenameFilter() {
                            public boolean accept(File dir, String name) {
                                return name.equals(attachmentFileName);
                            }
                        })[0];
                    helper.addAttachment(file.getName(), new FileSystemResource(file));
                }
                
                helper.setText(bodyData,true);
            }
        };
        try {
            this.mailSender.send(preparator);
            //file.delete();
            logger.info("Mail sent successfully.");
        } catch (MailException ex) {
            logger.error("Exception occured while sending Email.", ex);
        }
    }
 
	public void sendSoaEmail(final String inlineFilePath) {
        logger.debug("Initiating request to send Email.");
        // read directory
        logger.info("Attachment path :" + attachmentFilePath);
        File directory = new File(attachmentFilePath);
        // get file from directory
        //final File file = directory.listFiles(FILE_FILTER)[0];
        
        final File file = directory.listFiles(new FilenameFilter() {
                public boolean accept(File dir, String name) {
                    return name.equals(attachmentFileName);
                }
            })[0];
 
        MimeMessagePreparator preparator = new MimeMessagePreparator() {
            public void prepare(MimeMessage mimeMessage) throws Exception {
                //mimeMessage.setRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
            	mimeMessage.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientTO));
            	if(recipientCC!= null && !recipientCC.isEmpty())
            		mimeMessage.setRecipients(Message.RecipientType.CC, InternetAddress.parse(recipientCC));
                mimeMessage.setFrom(new InternetAddress(senderAddress));
                mimeMessage.setSubject(subject);
                
                // MimeMessagesHelper is needed for the attachment. The Boolean value in
                // constructor is for multipart/data = true
                MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
                helper.addAttachment(file.getName(), new FileSystemResource(file));
                helper.setText(bodyData,true);
                helper.addInline("myLogo",new File(inlineFilePath+"/airtel-bank-logo.jpg"));
                helper.addInline("apoloIcon",new File(inlineFilePath+"/apolo-icon.jpg"));
                helper.addInline("eabyIcon",new File(inlineFilePath+"/ebay-icon.jpg"));
                helper.addInline("myBusTicketIcon",new File(inlineFilePath+"/mybusticket-icon.jpg"));
                
            }
        };
        try {
            this.mailSender.send(preparator);
            //file.delete();
            logger.info("Mail sent successfully.");
        } catch (MailException ex) {
            logger.error("Exception occured while sending Email.", ex);
        }
    }
//    public static FilenameFilter FILE_FILTER = new FilenameFilter() {
//        public boolean accept(File file, String name) {
//        	return name.equals(arg0);
//            //return !file.isDirectory();
//        }
//    };
 }
