package com.airtel.money.mapper;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.jdbc.core.PreparedStatementSetter;

public class ParameterSetter implements PreparedStatementSetter {

    private final String x;

    public ParameterSetter(String x) {this.x = x;}

    @Override
    public void setValues(PreparedStatement ps) throws SQLException {
    	System.out.println("etlSummaryID"+x);
        ps.setString(1, x);
    }
	
}

