package com.airtel.money.tasklet;

import java.io.File;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.integration.support.MessageBuilder;

public class InwardCompletedTasklet implements Tasklet {

	Logger LOGGER = Logger.getLogger(InwardCompletedTasklet.class);
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception 
	{
		LOGGER.info("Inward return file batch completed successfully");
		/**/
		return RepeatStatus.FINISHED;
	}
	
}
