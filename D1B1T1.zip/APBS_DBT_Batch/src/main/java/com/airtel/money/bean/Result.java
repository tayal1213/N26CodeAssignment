package com.airtel.money.bean;

public class Result {
	private String statusCode;

	private String statusDescription;

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

	@Override
	public String toString() {
		return "ClassPojo [statusCode = " + statusCode + ", statusDescription = " + statusDescription + "]";
	}
}