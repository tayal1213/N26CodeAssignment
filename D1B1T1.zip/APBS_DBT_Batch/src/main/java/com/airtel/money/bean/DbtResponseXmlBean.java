package com.airtel.money.bean;


import java.io.Serializable;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.airtel.money.adapter.JaxbBigDecimalAdapter;
import com.airtel.money.adapter.JaxbDateAdapter;

@XmlRootElement(name = "Record")
public class DbtResponseXmlBean implements Serializable
{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long aadharNo;
	private long mappedIin;
	private String scheme;
	private String mandateCustDate;
	private String mappingStatus;
	private String uidReasonCode;
	private String uidResult;
	private String accepted;
	
	@XmlElement(name = "AADHAAR_NO")
	public long getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(long aadharNo) {
		this.aadharNo = aadharNo;
	}
	@XmlElement(name = "MAPPED_IIN")
	public long getMappedIin() {
		return mappedIin;
	}
	public void setMappedIin(long mappedIin) {
		this.mappedIin = mappedIin;
	}
	@XmlElement(name = "SCHEME")
	public String getScheme() {
		return scheme;
	}
	public void setScheme(String scheme) {
		this.scheme = scheme;
	}
	@XmlElement(name = "MANDATE_CUST_DATE")
	public String getMandateCustDate() {
		return mandateCustDate;
	}
	public void setMandateCustDate(String mandateCustDate) {
		this.mandateCustDate = mandateCustDate;
	}
	@XmlElement(name = "MAPPING_STATUS")
	public String getMappingStatus() {
		return mappingStatus;
	}
	public void setMappingStatus(String mappingStatus) {
		this.mappingStatus = mappingStatus;
	}
	@XmlElement(name = "UID_REASON_CODE")
	public String getUidReasonCode() {
		return uidReasonCode;
	}
	public void setUidReasonCode(String uidReasonCode) {
		this.uidReasonCode = uidReasonCode;
	}
	@XmlElement(name = "UID_RESULT")
	public String getUidResult() {
		return uidResult;
	}
	public void setUidResult(String uidResult) {
		this.uidResult = uidResult;
	}
	@XmlElement(name = "ACCEPTED")
	public String getAccepted() {
		return accepted;
	}
	public void setAccepted(String accepted) {
		this.accepted = accepted;
	}
	@Override
	public String toString() {
		return "DbtResponseXmlBean [aadharNo=" + aadharNo + ", mappedIin="
				+ mappedIin + ", scheme=" + scheme + ", mandateCustDate="
				+ mandateCustDate + ", mappingStatus=" + mappingStatus
				+ ", uidReasonCode=" + uidReasonCode + ", uidResult="
				+ uidResult + ", accepted=" + accepted + "]";
	}
	
	
	/*
	*/
	/*private int refId;
	private String name;
	private int age;
	private Date dob;
	private BigDecimal income;

	@XmlAttribute(name = "refId")
	public int getRefId() {
		return refId;
	}

	public void setRefId(int refId) {
		this.refId = refId;
	}

	@XmlElement(name = "age")
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@XmlElement
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@XmlJavaTypeAdapter(JaxbDateAdapter.class)
	@XmlElement
	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	@XmlJavaTypeAdapter(JaxbBigDecimalAdapter.class)
	@XmlElement
	public BigDecimal getIncome() {
		return income;
	}

	public void setIncome(BigDecimal income) {
		this.income = income;
	}

	// for csv file only
	public String getCsvDob() {

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		return dateFormat.format(getDob());

	}*/
	
}