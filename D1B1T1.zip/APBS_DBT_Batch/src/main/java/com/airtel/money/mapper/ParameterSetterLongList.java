package com.airtel.money.mapper;

import java.sql.Array;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.PreparedStatementSetter;

import com.airtel.money.bean.InwardFileDataBean;

public class ParameterSetterLongList implements PreparedStatementSetter {


	private InwardFileDataBean inwardFileDataBean;

    @Override
    public void setValues(PreparedStatement ps) throws SQLException {
    	try {
    		Array array = ps.getConnection().createArrayOf("VARCHAR", new Object[]{"396", "397"});
    		ps.setArray(1, array);
    		
    		
		} catch (Exception e) {
			e.printStackTrace();
		}
    	
    }

	public InwardFileDataBean getInwardFileDataBean() {
		return inwardFileDataBean;
	}

	public void setInwardFileDataBean(InwardFileDataBean inwardFileDataBean) {
		this.inwardFileDataBean = inwardFileDataBean;
	}
	
}

