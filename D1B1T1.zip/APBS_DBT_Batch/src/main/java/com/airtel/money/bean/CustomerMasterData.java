package com.airtel.money.bean;

public class CustomerMasterData 
{
	private String msisdn;
	private String customerFName;
	private String customerMName;
	private String customerLName;
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getCustomerFName() {
		return customerFName;
	}
	public void setCustomerFName(String customerFName) {
		this.customerFName = customerFName;
	}
	public String getCustomerMName() {
		return customerMName;
	}
	public void setCustomerMName(String customerMName) {
		this.customerMName = customerMName;
	}
	public String getCustomerLName() {
		return customerLName;
	}
	public void setCustomerLName(String customerLName) {
		this.customerLName = customerLName;
	}
	@Override
	public String toString() {
		return "CustomerMasterData [msisdn=" + msisdn + ", customerFName="
				+ customerFName + ", customerMName=" + customerMName
				+ ", customerLName=" + customerLName + "]";
	}
	
}
