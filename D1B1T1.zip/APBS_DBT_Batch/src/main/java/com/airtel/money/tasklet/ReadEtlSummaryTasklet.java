package com.airtel.money.tasklet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.ETLSummary;
import com.airtel.money.bean.InwardFileDataBean;
import com.airtel.money.bean.TimeoutCountBean;
import com.airtel.money.dao.DbtMappingDao;

public class ReadEtlSummaryTasklet implements JobExecutionDecider 
{
	Logger LOGGER = Logger.getLogger(ReadEtlSummaryTasklet.class);
	private MessageSource messageSource;
	private DbtMappingDao dbtMappingDao;
	private InwardFileDataBean inwardFileDataBean;
	
	@Override
	public FlowExecutionStatus decide(JobExecution jobExecution, StepExecution stepExecution)  
	{
		LOGGER.info("Inside ReadEtlSummaryTasklet.decide");
		dbtMappingDao.deleteEtlIdsInward("DBT_TRANSACTION");
		List<ETLSummary> lstEtlSummary = dbtMappingDao.getEtlSummary();
		if(lstEtlSummary!=null && lstEtlSummary.size()>0)
		{
			String etlSummaryIds = "";
			List<Long> lstEtlIds = new ArrayList<Long>();
			for(ETLSummary etlSummary : lstEtlSummary)
			{
				lstEtlIds.add(etlSummary.getId());
				etlSummaryIds = etlSummaryIds+etlSummary.getId()+",";
			}
			if(etlSummaryIds.length()>0)
			{
				etlSummaryIds = etlSummaryIds.substring(0,etlSummaryIds.length()-1);
			}
			List<TimeoutCountBean> lstTimeoutCountBean = dbtMappingDao.getTimeoutCount(etlSummaryIds);
			Map<Long, TimeoutCountBean> mapTimeout = new HashMap<Long, TimeoutCountBean>();
			if(lstTimeoutCountBean!=null)
			for(TimeoutCountBean timeoutCountBean:lstTimeoutCountBean)
			{
				mapTimeout.put(timeoutCountBean.getEtlSummaryId(), timeoutCountBean);
			}
			Iterator<ETLSummary> iterator = lstEtlSummary.iterator();
			while (iterator.hasNext()) 
			{
				ETLSummary etlSummary = iterator.next();
				TimeoutCountBean timeoutCountBean = mapTimeout.get(etlSummary.getId());
			    if (timeoutCountBean==null || timeoutCountBean.getTimeoutCount()>0)
			    {
			        iterator.remove();
			    }
			}
			if(lstEtlSummary!=null && lstEtlSummary.size()>0)
			{
		
				inwardFileDataBean.setCurCount(0);
				inwardFileDataBean.setLstEtlSummary(lstEtlSummary);
				inwardFileDataBean.setEtlSummaryId(inwardFileDataBean.getLstEtlSummary().get(0).getId());
				
				
				dbtMappingDao.insertEtlIdsInward(lstEtlIds,"DBT_TRANSACTION");
				LOGGER.info("ReadEtlSummaryTasklet.FlowExecutionStatus: Status:COMPLETED");
				return FlowExecutionStatus.COMPLETED;
			}
			else
			{
				LOGGER.info("ReadEtlSummaryTasklet.FlowExecutionStatus: Status:UNKNOWN");
				return FlowExecutionStatus.UNKNOWN;
			}
		}
		else
		{
			LOGGER.info("ReadEtlSummaryTasklet.FlowExecutionStatus: Status:UNKNOWN");
			return FlowExecutionStatus.UNKNOWN;
		}
			
	}
	public MessageSource getMessageSource() {
		return messageSource;
	}
	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}
	public DbtMappingDao getDbtMappingDao() {
		return dbtMappingDao;
	}
	public void setDbtMappingDao(DbtMappingDao dbtMappingDao) {
		this.dbtMappingDao = dbtMappingDao;
	}
	public InwardFileDataBean getInwardFileDataBean() {
		return inwardFileDataBean;
	}
	public void setInwardFileDataBean(InwardFileDataBean inwardFileDataBean) {
		this.inwardFileDataBean = inwardFileDataBean;
	}
	public static void main(String[] args) {
		String str = "2,3,4,";
		System.out.println(str.substring(0,str.length()-1));
	}
	
	
}
