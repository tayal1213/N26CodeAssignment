package com.airtel.money.writer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.jms.JmsItemWriter;

import com.airtel.money.bean.AadharSeedingResponseXmlBean;
import com.airtel.money.util.Utility;

public class SolaceMqCompositeWriter implements ItemWriter<AadharSeedingResponseXmlBean> {

	private JmsItemWriter<String> jmsWriter;
	private ItemWriter<AadharSeedingResponseXmlBean> dbtMappingDetailsWriter;
	

	static final Logger Log = Logger.getLogger(SolaceMqCompositeWriter.class);

	public JmsItemWriter<String> getJmsWriter() {
		return jmsWriter;
	}

	public void setJmsWriter(JmsItemWriter<String> jmsWriter) {
		this.jmsWriter = jmsWriter;
	}

	public ItemWriter<AadharSeedingResponseXmlBean> getDbtMappingDetailsWriter() {
		return dbtMappingDetailsWriter;
	}

	public void setDbtMappingDetailsWriter(ItemWriter<AadharSeedingResponseXmlBean> dbtMappingDetailsWriter) {
		this.dbtMappingDetailsWriter = dbtMappingDetailsWriter;
	}

	@Override
	public void write(List<? extends AadharSeedingResponseXmlBean> bean) throws Exception {

		Log.info("Inside SolaceMqCompositeWriter.write");
		List<String> templist = new ArrayList<String>();
		String responseText = null;
		for (AadharSeedingResponseXmlBean responseBean : bean) {
			try {

				responseBean.setExtRefNum(UUID.randomUUID().toString().replaceAll("-", ""));
				Map<String, Object> input = new HashMap<String, Object>();
				input.put("bean", responseBean);
				responseText = Utility.getFtlResponse("update_profile.ftl", input);
			} catch (Exception e) {
				Log.info("Exception while creating the CBS MQ Temaplte" + e);
			}
			templist.add(responseText);
		}

		Log.info("Writting to Queue and DBT_MAPPING_DETAILS SolaceMqCompositeWriter.write");
		jmsWriter.write(templist);
		dbtMappingDetailsWriter.write(bean);

	}

}
