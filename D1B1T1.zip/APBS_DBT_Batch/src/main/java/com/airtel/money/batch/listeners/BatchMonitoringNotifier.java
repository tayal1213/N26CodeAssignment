package com.airtel.money.batch.listeners;

import org.springframework.batch.core.JobExecution;

public interface BatchMonitoringNotifier {
	void notify(JobExecution jobExecution, String batchStage);
}
