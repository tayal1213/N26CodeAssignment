package com.airtel.money.processor;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;

import com.airtel.money.bean.AadhaarVaultRequest;
import com.airtel.money.bean.AadharSeedingResponseXmlBean;
import com.airtel.money.dao.DbtMappingDao;
import com.airtel.money.util.Utility;

public class ResponseProfilingProcessor
		implements ItemProcessor<AadharSeedingResponseXmlBean, AadharSeedingResponseXmlBean> {

	Logger LOGGER = Logger.getLogger(ResponseProfilingProcessor.class);
	private DbtMappingDao dao;


	
	public DbtMappingDao getDao() {
		return dao;
	}

	public void setDao(DbtMappingDao dao) {
		this.dao = dao;
	}

	@Override
	public AadharSeedingResponseXmlBean process(AadharSeedingResponseXmlBean dbtResponseXmlBean) throws Exception {
		LOGGER.info("APBS Batch: Record being processing for dbtResponseXmlBean: " + dbtResponseXmlBean);
		try {
			dbtResponseXmlBean = dao.getNationId(dbtResponseXmlBean);

			if (Utility.isEmpty(dbtResponseXmlBean.getNatId())) {

				/*AadhaarVaultRequest request = new AadhaarVaultRequest();
				request.setUid(dbtResponseXmlBean.getAadharNo());
				request.setRequestId("ABPS" + (new Date().getTime() * 94 % 100000000 * 6));
				request.setApiKey("paymentBank");
				String refKey = util.callVaultAPI(request);
				if (refKey != null) {
					dbtResponseXmlBean.setAadharNo(refKey);
					dbtResponseXmlBean = dao.getNationId(dbtResponseXmlBean);
					if(Utility.isEmpty(dbtResponseXmlBean.getNatId()))
							return null;
				} else
					return null;*/
				
				return null;

			}

			if (dbtResponseXmlBean.getMappingStatus() != null
					&& dbtResponseXmlBean.getMappingStatus().equalsIgnoreCase("A")) {
				dbtResponseXmlBean.setStatus("ACTIVE");
			} else {
				dbtResponseXmlBean.setStatus("INACTIVE");
			}
		} catch (Exception e) {
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}

		return dbtResponseXmlBean;
	}

}
