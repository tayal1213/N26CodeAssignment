package com.airtel.money.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class HashGeneratorUtil {
	
	public static String generateMD5(String message) throws Exception {
		return hashString(message, "MD5");
	}
	
	public static String generateSHA1(String message) throws Exception {
		return hashString(message, "SHA-1");
	}

	public static String generateSHA256(String message) throws Exception {
		return hashString(message, "SHA-256");
	}

	private static String hashString(String message, String algorithm)
			throws Exception {

		try {
			MessageDigest digest = MessageDigest.getInstance(algorithm);
			byte[] hashedBytes = digest.digest(message.getBytes("UTF-8"));

			return convertByteArrayToHexString(hashedBytes);
		} catch (NoSuchAlgorithmException | UnsupportedEncodingException ex) {
			throw new Exception(
					"Could not generate hash from String", ex);
		}
	}
		
	private static String convertByteArrayToHexString(byte[] arrayBytes) {
		StringBuffer stringBuffer = new StringBuffer();
		for (int i = 0; i < arrayBytes.length; i++) {
			stringBuffer.append(Integer.toString((arrayBytes[i] & 0xff) + 0x100, 16)
					.substring(1));
		}
		System.out.println(stringBuffer);
		return stringBuffer.toString();
	}
	
	public static long hex2decimal(String s) {
	    long val = 0;
	    for (int i = 0; i < s.length(); i++) {
	        char c = s.charAt(i);
	        int num = (int) c;
	        val = 256*val + num;
	    }
	    return val;
	}
	
	public static void main(String args[]) throws Exception{
		//HashGeneratorUtil util = new HashGeneratorUtil();
		//long x = hex2decimal(HashGeneratorUtil.hashString("Hi Hellowbhhjfghgcf", "MD5"))%1000000;
		//System.out.println(x);
		String str="";
		 /*String amount = "0000000015944";
		 String sponsor_bank_code="000508548"; // FromActorParam4
		 String receiver_bank_code="000990288";
		 String aadhaar_number="000423521208882";//ToActorParam1
		 String user_number="21BZ1SB";//FromActorParam1
		 String product_type="77";
		 String umrn = "NOTPROVIDED";//480876690
*/		 //8500767649
		
		 String amount = "0000000200000";
		 String sponsor_bank_code="000508534"; // FromActorParam4
		 String receiver_bank_code="000990288";
		 String aadhaar_number="000329899564122";//ToActorParam1
		 String user_number="10DCSIC";//FromActorParam1
		 String product_type="77";
		 String umrn = "NOTPROVIDED";//480876690
		 String transaction_reference_number="C071700552465";
		 str=""+amount+sponsor_bank_code+receiver_bank_code+aadhaar_number+user_number+product_type+umrn+transaction_reference_number;
		 
		 //1145091141
		 
		

		
		System.out.println(hex2decimal(HashGeneratorUtil.hashString(str, "SHA-256"))%10000000000l);
	}
}