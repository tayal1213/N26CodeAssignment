package com.airtel.money.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.airtel.money.bean.DbtReasonCode;

public class DbtReasonCodeMapper implements RowMapper<DbtReasonCode>
{

	@Override
	public DbtReasonCode mapRow(ResultSet rs, int arg1) throws SQLException 
	{
		DbtReasonCode dbtReasonCode = new DbtReasonCode();		
		dbtReasonCode.setId(rs.getLong("ID"));
		dbtReasonCode.setDbtCode(rs.getString("DBT_CODE"));
		dbtReasonCode.setMappingCode(rs.getString("MAPPING_CODE"));
		dbtReasonCode.setName(rs.getString("NAME"));
		dbtReasonCode.setStatus(rs.getString("TYPE"));
		dbtReasonCode.setType(rs.getString("STATUS"));
		return dbtReasonCode;
	}

}
