package com.airtel.money.processor;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.AadhaarVaultRequest;
import com.airtel.money.bean.ApbsErrorLogBean;
import com.airtel.money.bean.DbtMappingDetailsBean;
import com.airtel.money.dao.DbtMappingDao;
import com.airtel.money.util.Constants;
import com.airtel.money.util.Utility;

public class AadharSeedingProcessor implements ItemProcessor<DbtMappingDetailsBean, DbtMappingDetailsBean> {
	Logger LOGGER = Logger.getLogger(AadharSeedingProcessor.class);
	private MessageSource messageSource;
	private DbtMappingDao dbtMappingDao;
	private Utility util;

	public Utility getUtil() {
		return util;
	}

	public void setUtil(Utility util) {
		this.util = util;
	}

	@Override
	public DbtMappingDetailsBean process(DbtMappingDetailsBean dbtMappingDetailsBean) throws Exception {
		LOGGER.info("APBS Batch: Record being processing for dbtMappingDetailsBean: " + dbtMappingDetailsBean);
		try {
			Date date = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			int year = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH) + 1;
			int day = cal.get(Calendar.DAY_OF_MONTH);
			String dateStr = (year + "").substring(0, 1) + (month > 9 ? "" + month : "0" + month)
					+ (day > 9 ? "" + day : "0" + day);

			int identifierLength = 2;
			int referenceNumberLength = 15;
			int aadhaarNumberLength = 15;
			int mappedIINLength = 9;
			int dateOfCustomerMandateLength = 8;

			String headerIdentifier = messageSource.getMessage("aadhar.seeding.file.records.identifier", null,
					Locale.US);
			String referenceNumber = "" + dbtMappingDetailsBean.getAccNumber() + dateStr;
			// Aadhaar Vault Change
			String aadhaarNumber = null;
			// dbtMappingDetailsBean.getAadharNumber()==null?"":
			// ""+dbtMappingDetailsBean.getAadharNumber();
			if (dbtMappingDetailsBean.getIsRefKey() != null
					&& dbtMappingDetailsBean.getIsRefKey().equalsIgnoreCase("yes")) {
				AadhaarVaultRequest request = new AadhaarVaultRequest();
				request.setReferenceKey(dbtMappingDetailsBean.getRefKey());
				request.setRequestId("ABPS" + (new Date().getTime() * 94 % 100000000 * 6));
				request.setApiKey("paymentBank");
				aadhaarNumber = util.callVaultAPI(request);
				if (aadhaarNumber == null)
					return null;

			} else
				aadhaarNumber = dbtMappingDetailsBean.getRefKey();

			String mappedIIN = messageSource.getMessage("aadhar.seeding.file.records.iin", null, Locale.US);
			String mandateFlag = messageSource.getMessage("aadhar.mandate.flag", null, Locale.US);

			StringBuffer sb = new StringBuffer("");

			for (int i = 0; i < identifierLength - headerIdentifier.length(); i++) {
				sb.append("0");
			}
			sb.append(headerIdentifier);

			for (int i = 0; i < referenceNumberLength - referenceNumber.length(); i++) {
				sb.append("0");
			}
			sb.append(referenceNumber);

			for (int i = 0; i < aadhaarNumberLength - aadhaarNumber.length(); i++) {
				sb.append("0");
			}
			sb.append(aadhaarNumber);

			for (int i = 0; i < mappedIINLength - mappedIIN.length(); i++) {
				sb.append("0");
			}
			sb.append(mappedIIN);
			sb.append(mandateFlag);
			if (mandateFlag.equalsIgnoreCase("Y") && dbtMappingDetailsBean.getMandateTimestamp() != null) {
				Calendar cald = Calendar.getInstance();
				cald.setTime(dbtMappingDetailsBean.getMandateTimestamp());
				int yy = cald.get(Calendar.YEAR);
				int mm = cald.get(Calendar.MONTH) + 1;
				int dd = cald.get(Calendar.DAY_OF_MONTH);
				String dtStr = (dd > 9 ? "" + dd : "0" + dd) + (mm > 9 ? "" + mm : "0" + mm) + yy;
				sb.append(dtStr);
			} else {
				for (int i = 0; i < dateOfCustomerMandateLength; i++) {
					sb.append(" ");
				}
			}
			if (dbtMappingDetailsBean.getActivationStatus().equalsIgnoreCase(Constants.ACTIVATION_STATUS_YES)) {
				sb.append(messageSource.getMessage("aadhar.activation.status.yes", null, Locale.US));
			} else {
				sb.append(messageSource.getMessage("aadhar.activation.status.no", null, Locale.US));
				;
			}
			sb.append(messageSource.getMessage("aadhar.od.flag", null, Locale.US));
			if (messageSource.getMessage("aadhar.od.flag", null, Locale.US).equalsIgnoreCase(Constants.OD_FLAG_YES)
					&& dbtMappingDetailsBean.getMandateTimestamp() != null) {
				SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
				sb.append(sdf.format(dbtMappingDetailsBean.getMandateTimestamp()));
			} else {
				for (int i = 0; i < 8; i++) {
					sb.append(" ");
				}
			}
			for (int i = 0; i < 300; i++) {
				sb.append(" ");
			}
			dbtMappingDetailsBean.setFlatFileRow(sb.toString());

		} catch (Exception e) {
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
			ApbsErrorLogBean apbsErrorLogBean = new ApbsErrorLogBean();
			apbsErrorLogBean.setBatchName("aadhar-seeding-job");
			apbsErrorLogBean.setErrorMsg(e.getMessage());
			apbsErrorLogBean.setInputData(dbtMappingDetailsBean.toString());
			dbtMappingDao.insertApbsErrorLog(apbsErrorLogBean);
			return null;
		}

		return dbtMappingDetailsBean;
	}

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public DbtMappingDao getDbtMappingDao() {
		return dbtMappingDao;
	}

	public void setDbtMappingDao(DbtMappingDao dbtMappingDao) {
		this.dbtMappingDao = dbtMappingDao;
	}

}
