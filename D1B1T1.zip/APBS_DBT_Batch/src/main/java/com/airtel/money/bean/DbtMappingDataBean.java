package com.airtel.money.bean;

public class DbtMappingDataBean 
{
	private Integer rowCount;
	private String fileName;
	private String header;
	public Integer getRowCount() 
	{
		return rowCount;
	}
	public void setRowCount(Integer rowCount) 
	{
		this.rowCount = rowCount;
	}
	public String getFileName() 
	{
		return fileName;
	}
	public void setFileName(String fileName) 
	{
		this.fileName = fileName;
	}
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
}
