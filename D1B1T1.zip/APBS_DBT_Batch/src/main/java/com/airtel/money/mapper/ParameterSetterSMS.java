package com.airtel.money.mapper;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.jdbc.core.PreparedStatementSetter;

public class ParameterSetterSMS implements PreparedStatementSetter {

	public String getTranDate() {
		return tranDate;
	}

	public void setTranDate(String tranDate) {
		this.tranDate = tranDate;
	}

	private String tranDate;

	/*public ParameterSetterSMS() {

	}

	public ParameterSetterSMS(String tranDate) {
		this.tranDate = tranDate;
	}
*/
	@Override
	public void setValues(PreparedStatement ps) throws SQLException {
		ps.setString(1, tranDate);
		ps.setString(2, tranDate);
	}

}
