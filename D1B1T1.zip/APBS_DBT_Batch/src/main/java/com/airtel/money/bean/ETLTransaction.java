package com.airtel.money.bean;

import java.sql.Timestamp;

public class ETLTransaction 
{
	private Long id;
	private Long partnerTxnId;
	private Long voltTxnId;
	private Long coreTxnId;
	private String ucId;
	private Long fromActorId;
	private Long fromActorMsisdn;
	private Long toActorId;
	private Long toActorMsisdn;
	private Double amount;
	private String status;
	private Timestamp createdTimestamp;
	private Timestamp modifiedTimestamp;
	private String createdChannel;
	private String modifiedChannel;
	private String inputFilename;
	private String outputFilename;
	private String circle;
	private String fromActorParam1;
	private String fromActorParam2;
	private String fromActorParam3;
	private String fromActorParam4;
	private String fromActorParam5;
	private String toActorParam1;
	private String toActorParam2;
	private String toActorParam3;
	private String toActorParam4;
	private String toActorParam5;
	private String refundFlag;
	private Timestamp refundTimestamp;
	private Long refundTxnId;
	private Long refundAmount;
	private String remarks;
	private String reconStatus;
	private Timestamp reconTimestamp;
	private String reconFilename;
	private String freeField1;
	private String freeField2;
	private String freeField3;
	private String freeField4;
	private String freeField5;
	private String freeField6;
	private String freeField7;
	private String freeField8;
	private String freeField9;
	private String freeField10;
	private String errorCode;
	private Long etlSummaryId;
	
	private String apbsTransactionCode;
	private String destinationBankIIN;
	private String destinationAccountType;
	
	
	private String inputData;
	private boolean isError;
	private String errorMsg;
	private ApbsErrorLogBean apbsErrorLogBean;
	
	
	
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getPartnerTxnId() {
		return partnerTxnId;
	}
	public void setPartnerTxnId(Long partnerTxnId) {
		this.partnerTxnId = partnerTxnId;
	}
	public Long getVoltTxnId() {
		return voltTxnId;
	}
	public void setVoltTxnId(Long voltTxnId) {
		this.voltTxnId = voltTxnId;
	}
	public Long getCoreTxnId() {
		return coreTxnId;
	}
	public void setCoreTxnId(Long coreTxnId) {
		this.coreTxnId = coreTxnId;
	}
	public String getUcId() {
		return ucId;
	}
	public void setUcId(String ucId) {
		this.ucId = ucId;
	}
	public Long getFromActorId() {
		return fromActorId;
	}
	public void setFromActorId(Long fromActorId) {
		this.fromActorId = fromActorId;
	}
	public Long getFromActorMsisdn() {
		return fromActorMsisdn;
	}
	public void setFromActorMsisdn(Long fromActorMsisdn) {
		this.fromActorMsisdn = fromActorMsisdn;
	}
	public Long getToActorId() {
		return toActorId;
	}
	public void setToActorId(Long toActorId) {
		this.toActorId = toActorId;
	}
	public Long getToActorMsisdn() {
		return toActorMsisdn;
	}
	public void setToActorMsisdn(Long toActorMsisdn) {
		this.toActorMsisdn = toActorMsisdn;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}
	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}
	public Timestamp getModifiedTimestamp() {
		return modifiedTimestamp;
	}
	public void setModifiedTimestamp(Timestamp modifiedTimestamp) {
		this.modifiedTimestamp = modifiedTimestamp;
	}
	public String getCreatedChannel() {
		return createdChannel;
	}
	public void setCreatedChannel(String createdChannel) {
		this.createdChannel = createdChannel;
	}
	public String getModifiedChannel() {
		return modifiedChannel;
	}
	public void setModifiedChannel(String modifiedChannel) {
		this.modifiedChannel = modifiedChannel;
	}
	public String getInputFilename() {
		return inputFilename;
	}
	public void setInputFilename(String inputFilename) {
		this.inputFilename = inputFilename;
	}
	public String getOutputFilename() {
		return outputFilename;
	}
	public void setOutputFilename(String outputFilename) {
		this.outputFilename = outputFilename;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getFromActorParam1() {
		return fromActorParam1;
	}
	public void setFromActorParam1(String fromActorParam1) {
		this.fromActorParam1 = fromActorParam1;
	}
	public String getFromActorParam2() {
		return fromActorParam2;
	}
	public void setFromActorParam2(String fromActorParam2) {
		this.fromActorParam2 = fromActorParam2;
	}
	public String getFromActorParam3() {
		return fromActorParam3;
	}
	public void setFromActorParam3(String fromActorParam3) {
		this.fromActorParam3 = fromActorParam3;
	}
	public String getFromActorParam4() {
		return fromActorParam4;
	}
	public void setFromActorParam4(String fromActorParam4) {
		this.fromActorParam4 = fromActorParam4;
	}
	public String getFromActorParam5() {
		return fromActorParam5;
	}
	public void setFromActorParam5(String fromActorParam5) {
		this.fromActorParam5 = fromActorParam5;
	}
	public String getToActorParam1() {
		return toActorParam1;
	}
	public void setToActorParam1(String toActorParam1) {
		this.toActorParam1 = toActorParam1;
	}
	public String getToActorParam2() {
		return toActorParam2;
	}
	public void setToActorParam2(String toActorParam2) {
		this.toActorParam2 = toActorParam2;
	}
	public String getToActorParam3() {
		return toActorParam3;
	}
	public void setToActorParam3(String toActorParam3) {
		this.toActorParam3 = toActorParam3;
	}
	public String getToActorParam4() {
		return toActorParam4;
	}
	public void setToActorParam4(String toActorParam4) {
		this.toActorParam4 = toActorParam4;
	}
	public String getToActorParam5() {
		return toActorParam5;
	}
	public void setToActorParam5(String toActorParam5) {
		this.toActorParam5 = toActorParam5;
	}
	public String getRefundFlag() {
		return refundFlag;
	}
	public void setRefundFlag(String refundFlag) {
		this.refundFlag = refundFlag;
	}
	public Timestamp getRefundTimestamp() {
		return refundTimestamp;
	}
	public void setRefundTimestamp(Timestamp refundTimestamp) {
		this.refundTimestamp = refundTimestamp;
	}
	public Long getRefundTxnId() {
		return refundTxnId;
	}
	public void setRefundTxnId(Long refundTxnId) {
		this.refundTxnId = refundTxnId;
	}
	public Long getRefundAmount() {
		return refundAmount;
	}
	public void setRefundAmount(Long refundAmount) {
		this.refundAmount = refundAmount;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getReconStatus() {
		return reconStatus;
	}
	public void setReconStatus(String reconStatus) {
		this.reconStatus = reconStatus;
	}
	public Timestamp getReconTimestamp() {
		return reconTimestamp;
	}
	public void setReconTimestamp(Timestamp reconTimestamp) {
		this.reconTimestamp = reconTimestamp;
	}
	public String getReconFilename() {
		return reconFilename;
	}
	public void setReconFilename(String reconFilename) {
		this.reconFilename = reconFilename;
	}
	public String getFreeField1() {
		return freeField1;
	}
	public void setFreeField1(String freeField1) {
		this.freeField1 = freeField1;
	}
	public String getFreeField2() {
		return freeField2;
	}
	public void setFreeField2(String freeField2) {
		this.freeField2 = freeField2;
	}
	public String getFreeField3() {
		return freeField3;
	}
	public void setFreeField3(String freeField3) {
		this.freeField3 = freeField3;
	}
	public String getFreeField4() {
		return freeField4;
	}
	public void setFreeField4(String freeField4) {
		this.freeField4 = freeField4;
	}
	public String getFreeField5() {
		return freeField5;
	}
	public void setFreeField5(String freeField5) {
		this.freeField5 = freeField5;
	}
	public String getFreeField6() {
		return freeField6;
	}
	public void setFreeField6(String freeField6) {
		this.freeField6 = freeField6;
	}
	public String getFreeField7() {
		return freeField7;
	}
	public void setFreeField7(String freeField7) {
		this.freeField7 = freeField7;
	}
	public String getFreeField8() {
		return freeField8;
	}
	public void setFreeField8(String freeField8) {
		this.freeField8 = freeField8;
	}
	public String getFreeField9() {
		return freeField9;
	}
	public void setFreeField9(String freeField9) {
		this.freeField9 = freeField9;
	}
	public String getFreeField10() {
		return freeField10;
	}
	public void setFreeField10(String freeField10) {
		this.freeField10 = freeField10;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getApbsTransactionCode() {
		return apbsTransactionCode;
	}
	public void setApbsTransactionCode(String apbsTransactionCode) {
		this.apbsTransactionCode = apbsTransactionCode;
	}
	public String getDestinationBankIIN() {
		return destinationBankIIN;
	}
	public void setDestinationBankIIN(String destinationBankIIN) {
		this.destinationBankIIN = destinationBankIIN;
	}
	public String getDestinationAccountType() {
		return destinationAccountType;
	}
	public void setDestinationAccountType(String destinationAccountType) {
		this.destinationAccountType = destinationAccountType;
	}
	public Long getEtlSummaryId() {
		return etlSummaryId;
	}
	public void setEtlSummaryId(Long etlSummaryId) {
		this.etlSummaryId = etlSummaryId;
	}
	public String getInputData() {
		return inputData;
	}
	public void setInputData(String inputData) {
		this.inputData = inputData;
	}
	public boolean isError() {
		return isError;
	}
	public void setError(boolean isError) {
		this.isError = isError;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public ApbsErrorLogBean getApbsErrorLogBean() {
		return apbsErrorLogBean;
	}
	public void setApbsErrorLogBean(ApbsErrorLogBean apbsErrorLogBean) {
		this.apbsErrorLogBean = apbsErrorLogBean;
	}
	
}
