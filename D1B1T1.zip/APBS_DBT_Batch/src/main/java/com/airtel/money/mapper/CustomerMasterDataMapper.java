package com.airtel.money.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.airtel.money.bean.CustomerMasterData;


public class CustomerMasterDataMapper implements RowMapper<CustomerMasterData> 
{	
	Logger LOGGER = Logger.getLogger(CustomerMasterDataMapper.class);
	@Override
	public CustomerMasterData mapRow(ResultSet rs, int rowNum) 	throws SQLException 
	{
			CustomerMasterData data = new CustomerMasterData();
			try 
			{
				data.setMsisdn(rs.getString("CUST_MSISDN"));
				data.setCustomerFName(rs.getString("CUST_FNAME"));
				data.setCustomerMName(rs.getString("CUST_MNAME"));
				data.setCustomerLName(rs.getString("CUST_LNAME"));
			} 
			catch (Exception e) 
			{
				LOGGER.error("APBS Batch:  Exception occured: "+e.getMessage());
			}
						
			return data;
	}
}

			