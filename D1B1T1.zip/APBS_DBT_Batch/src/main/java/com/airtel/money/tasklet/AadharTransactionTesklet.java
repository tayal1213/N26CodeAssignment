package com.airtel.money.tasklet;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.ApbsErrorLogBean;
import com.airtel.money.bean.DbtTransactionDataBean;
import com.airtel.money.bean.ETLSummary;
import com.airtel.money.dao.DbtMappingDao;

public class AadharTransactionTesklet implements Tasklet {

	private DbtMappingDao dbtMappingDao;
	private MessageSource messageSource;
	private DbtTransactionDataBean dbtTransactionDataBean;
	Logger LOGGER = Logger.getLogger(AadharTransactionTesklet.class);

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info("APBS Batch:  Inside AadharTransactionTesklet.execute()");
		boolean isError = false;
		String errorMsg = "";
		File inputFile = null;
		String inputLine = null;
		List<File> listErrorFile = new ArrayList<File>();
		dbtMappingDao.deleteEtlIdsInward("INWARD_RETURN");
		try {
			String inwardFile = messageSource.getMessage("dbt.inward.input.file.locatiion", null, Locale.US);

			File inputDir = new File(inwardFile);
			List<File> files = (List<File>) FileUtils.listFiles(inputDir, new String[] { "txt" }, true);
			Map<String, Long> mapFileEtlId = new HashMap<String, Long>();

			for (File file : files) {
				inputFile = file;

				if (dbtMappingDao.checkFileAlreadyExist(file.getName())) {
					listErrorFile.add(file);
				}

				BufferedReader brTemp = new BufferedReader(new FileReader(file));
				String lineTemp = brTemp.readLine();
				inputLine = lineTemp;
				brTemp.close();
				if (lineTemp != null)

				{
					ETLSummary etlSummary = new ETLSummary();
					etlSummary.setInputFilename(file.getName());
					etlSummary.setCreatedTimestamp(new Timestamp(System.currentTimeMillis()));
					BufferedReader br = new BufferedReader(new FileReader(file));
					String line = br.readLine();
					inputLine = line;
					br.close();
					etlSummary.setTotalAmount(Double.valueOf(line.substring(113, 125)));
					etlSummary.setRecordCount(Long.valueOf(line.substring(104, 112)));
					etlSummary.setStatus(
							messageSource.getMessage("aadhar.transaction.summary.status.processing", null, Locale.US));
					etlSummary.setUcId(messageSource.getMessage("aadhar.transaction.ucid", null, Locale.US));
					etlSummary.setChannel(
							messageSource.getMessage("aadhar.transaction.summary.channel", null, Locale.US));
					etlSummary.setId(dbtMappingDao.getDBTHeaderSeq());
					if(!listErrorFile.contains(file))
					dbtMappingDao.insertHeaderInfo(etlSummary);
					dbtTransactionDataBean.setEtlSummaryId(etlSummary.getId());
					dbtTransactionDataBean.setFileName(file.getName());
					mapFileEtlId.put(file.getName(), etlSummary.getId());
				} else {
					if (!listErrorFile.contains(file))
						listErrorFile.add(file);
				}
			}
			dbtTransactionDataBean.setMapFileEtlId(mapFileEtlId);
			if (mapFileEtlId != null && mapFileEtlId.size() > 0) {
				
				dbtMappingDao.insertEtlIdsInward(mapFileEtlId.values(), "INWARD_RETURN");
			}

		} catch (Exception e) {
			isError = true;
			errorMsg = e.toString();
			LOGGER.warn("APBS Batch:  Exception occured: " + e);
		}
		if (listErrorFile.size() > 0) {
			Timestamp ts = new Timestamp(System.currentTimeMillis());
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH_mm_ss");
			String discardFileDir = messageSource.getMessage("dbt.inwar.discard.file.location", null, Locale.US);
			File discardFile = new File(discardFileDir + sdf.format(ts));
			discardFile.mkdir();
			for (File file : listErrorFile) {
				FileUtils.copyFileToDirectory(file, discardFile);

				ApbsErrorLogBean apbsErrorLogBean = new ApbsErrorLogBean();
				apbsErrorLogBean.setBatchName("dbt-transaction-job");
				apbsErrorLogBean.setErrorMsg(
						file.getName() + " is an invalid file: Error Msg: File already processed or is Empty ");
				apbsErrorLogBean.setInputData(inputLine);
				apbsErrorLogBean.setFileName(file.getName());
				dbtMappingDao.insertApbsErrorLog(apbsErrorLogBean);
				file.delete();
			}
		}
		if (isError) {
			String fileName = inputFile==null || inputFile.getName() == null ? "" : inputFile.getName();
			ApbsErrorLogBean apbsErrorLogBean = new ApbsErrorLogBean();
			apbsErrorLogBean.setBatchName("dbt-transaction-job");
			apbsErrorLogBean.setErrorMsg(errorMsg);
			apbsErrorLogBean.setInputData(inputLine);
			apbsErrorLogBean.setFileName(fileName);
			dbtMappingDao.insertApbsErrorLog(apbsErrorLogBean);
			throw new Exception(errorMsg);
		}
		return RepeatStatus.FINISHED;
	}

	public DbtMappingDao getDbtMappingDao() {
		return dbtMappingDao;
	}

	public void setDbtMappingDao(DbtMappingDao dbtMappingDao) {
		this.dbtMappingDao = dbtMappingDao;
	}

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public DbtTransactionDataBean getDbtTransactionDataBean() {
		return dbtTransactionDataBean;
	}

	public void setDbtTransactionDataBean(DbtTransactionDataBean dbtTransactionDataBean) {
		this.dbtTransactionDataBean = dbtTransactionDataBean;
	}

}
