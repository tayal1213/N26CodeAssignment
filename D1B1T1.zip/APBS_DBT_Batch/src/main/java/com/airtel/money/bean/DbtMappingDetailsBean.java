package com.airtel.money.bean;

import java.sql.Timestamp;

public class DbtMappingDetailsBean {
	private Long aadharNumber;
	private String refKey;

	private Long accNumber;
	private String dbtStatus;
	private String activationStatus;
	private Timestamp mandateTimestamp;
	private Timestamp createdTimestamp;
	private String createdChannel;
	private String modifiedChannel;
	private String fileName;
	private String uidReasonCode;
	private String uidResult;
	private String flatFileRow;
	private String custMsisdn;
	private String accHolderName;
	private String smsTxt;
	private String smsStatus;
	private String mapperIIN;
	private String scheme;
	private String mappingStatus;
	private String accepted;
	private String isRefKey;

	public String getIsRefKey() {
		return isRefKey;
	}

	public void setIsRefKey(String isRefKey) {
		this.isRefKey = isRefKey;
	}

	public Long getAadharNumber() {
		return aadharNumber;
	}

	public String getRefKey() {
		return refKey;
	}

	public void setRefKey(String refKey) {
		this.refKey = refKey;
	}

	public void setAadharNumber(Long aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public Long getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(Long accNumber) {
		this.accNumber = accNumber;
	}

	public String getDbtStatus() {
		return dbtStatus;
	}

	public void setDbtStatus(String dbtStatus) {
		this.dbtStatus = dbtStatus;
	}

	public String getActivationStatus() {
		return activationStatus;
	}

	public void setActivationStatus(String activationStatus) {
		this.activationStatus = activationStatus;
	}

	public Timestamp getMandateTimestamp() {
		return mandateTimestamp;
	}

	public void setMandateTimestamp(Timestamp mandateTimestamp) {
		this.mandateTimestamp = mandateTimestamp;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getCreatedChannel() {
		return createdChannel;
	}

	public void setCreatedChannel(String createdChannel) {
		this.createdChannel = createdChannel;
	}

	public String getModifiedChannel() {
		return modifiedChannel;
	}

	public void setModifiedChannel(String modifiedChannel) {
		this.modifiedChannel = modifiedChannel;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getUidReasonCode() {
		return uidReasonCode;
	}

	public void setUidReasonCode(String uidReasonCode) {
		this.uidReasonCode = uidReasonCode;
	}

	public String getUidResult() {
		return uidResult;
	}

	public void setUidResult(String uidResult) {
		this.uidResult = uidResult;
	}

	public String getFlatFileRow() {
		return flatFileRow;
	}

	public void setFlatFileRow(String flatFileRow) {
		this.flatFileRow = flatFileRow;
	}

	public String getCustMsisdn() {
		return custMsisdn;
	}

	public void setCustMsisdn(String custMsisdn) {
		this.custMsisdn = custMsisdn;
	}

	@Override
	public String toString() {
		return "DbtMappingDetailsBean [aadharNumber=" + aadharNumber + ", accNumber=" + accNumber + ", dbtStatus="
				+ dbtStatus + ", activationStatus=" + activationStatus + ", mandateTimestamp=" + mandateTimestamp
				+ ", createdChannel=" + createdChannel + ", modifiedChannel=" + modifiedChannel + ", fileName="
				+ fileName + ", uidReasonCode=" + uidReasonCode + ", uidResult=" + uidResult + ", flatFileRow="
				+ flatFileRow + ", custMsisdn=" + custMsisdn + "]";
	}

	public String getAccHolderName() {
		return accHolderName;
	}

	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}

	public String getSmsStatus() {
		return smsStatus;
	}

	public void setSmsStatus(String smsStatus) {
		this.smsStatus = smsStatus;
	}

	public String getMapperIIN() {
		return mapperIIN;
	}

	public void setMapperIIN(String mapperIIN) {
		this.mapperIIN = mapperIIN;
	}

	public String getScheme() {
		return scheme;
	}

	public void setScheme(String scheme) {
		this.scheme = scheme;
	}

	public String getMappingStatus() {
		return mappingStatus;
	}

	public void setMappingStatus(String mappingStatus) {
		this.mappingStatus = mappingStatus;
	}

	public String getAccepted() {
		return accepted;
	}

	public void setAccepted(String accepted) {
		this.accepted = accepted;
	}

	public String getSmsTxt() {
		return smsTxt;
	}

	public void setSmsTxt(String smsTxt) {
		this.smsTxt = smsTxt;
	}

}
