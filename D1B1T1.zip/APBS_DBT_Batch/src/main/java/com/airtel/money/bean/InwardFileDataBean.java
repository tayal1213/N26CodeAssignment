package com.airtel.money.bean;

import java.util.List;

public class InwardFileDataBean 
{
	
	private Integer rowCount;
	private String fileName;
	private String header;
	private List<ETLSummary> lstEtlSummary;
	private int curCount;
	private Long etlSummaryId;
	private String dbtCreditFileName;
	public Integer getRowCount() 
	{
		return rowCount;
	}
	public void setRowCount(Integer rowCount) 
	{
		this.rowCount = rowCount;
	}
	public String getFileName() 
	{
		return fileName;
	}
	public void setFileName(String fileName) 
	{
		this.fileName = fileName;
	}
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
	public List<ETLSummary> getLstEtlSummary() {
		return lstEtlSummary;
	}
	public void setLstEtlSummary(List<ETLSummary> lstEtlSummary) {
		this.lstEtlSummary = lstEtlSummary;
	}
	public int getCurCount() {
		return curCount;
	}
	public void setCurCount(int curCount) {
		this.curCount = curCount;
	}
	public Long getEtlSummaryId() {
		return etlSummaryId;
	}
	public void setEtlSummaryId(Long etlSummaryId) {
		this.etlSummaryId = etlSummaryId;
	}
	public String getDbtCreditFileName() {
		return dbtCreditFileName;
	}
	public void setDbtCreditFileName(String dbtCreditFileName) {
		this.dbtCreditFileName = dbtCreditFileName;
	}
	
	
}
