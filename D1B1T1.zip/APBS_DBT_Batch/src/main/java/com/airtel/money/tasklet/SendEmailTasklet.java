package com.airtel.money.tasklet;

import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.MessageSource;
import org.springframework.mail.javamail.JavaMailSender;

import com.airtel.money.adapter.mail.SendMailService;
import com.airtel.money.bean.InwardFileDataBean;
import com.airtel.money.dao.DbtMappingDao;

public class SendEmailTasklet implements Tasklet {

	private SendMailService sendMailService;
	private JavaMailSender mailSender;
	private MessageSource messageSource;
	private InwardFileDataBean inwardFileDataBean;
	private DbtMappingDao dbtMappingDao;
	Logger LOGGER = Logger.getLogger(SendEmailTasklet.class);
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception 
	{
		LOGGER.info("Inward return file batch completed successfully");
		if(inwardFileDataBean.getLstEtlSummary()!=null && inwardFileDataBean.getLstEtlSummary().size()>0)
		{
			
			
			String subject = messageSource.getMessage("dbt.credit.email.subject",null,Locale.US);
			String messageBody = messageSource.getMessage("dbt.credit.email.body",null,Locale.US);
			sendMailService.setFields(mailSender,
					messageSource.getMessage("dbt.credit.email.from",null,Locale.US),
					messageSource.getMessage("dbt.credit.email.to",null, Locale.US),
					messageSource.getMessage("dbt.credit.email.cc", null, Locale.US),
					messageSource.getMessage("dbt.credit.file.location", null, Locale.US),
					inwardFileDataBean.getDbtCreditFileName(),
					subject,
					messageBody);
			sendMailService.sendMail();
		}
		return RepeatStatus.FINISHED;
	}
	public SendMailService getSendMailService() {
		return sendMailService;
	}
	public void setSendMailService(SendMailService sendMailService) {
		this.sendMailService = sendMailService;
	}
	public JavaMailSender getMailSender() {
		return mailSender;
	}
	public void setMailSender(JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}
	public MessageSource getMessageSource() {
		return messageSource;
	}
	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}
	public InwardFileDataBean getInwardFileDataBean() {
		return inwardFileDataBean;
	}
	public void setInwardFileDataBean(InwardFileDataBean inwardFileDataBean) {
		this.inwardFileDataBean = inwardFileDataBean;
	}
	public DbtMappingDao getDbtMappingDao() {
		return dbtMappingDao;
	}
	public void setDbtMappingDao(DbtMappingDao dbtMappingDao) {
		this.dbtMappingDao = dbtMappingDao;
	}
	
}
