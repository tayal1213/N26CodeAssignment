package com.airtel.money.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.airtel.money.bean.AadhaarVaultRequest;
import com.airtel.money.bean.GlobalBean;
import com.airtel.money.bean.InwardFileBean;
import com.airtel.money.util.Utility;

public class InwardFileMapper implements RowMapper<InwardFileBean> {

	Logger LOGGER = Logger.getLogger(InwardFileMapper.class);
	private Utility util;
	private GlobalBean singletonMap;

	public GlobalBean getSingletonMap() {
		return singletonMap;
	}

	public void setSingletonMap(GlobalBean singletonMap) {
		this.singletonMap = singletonMap;
	}

	public Utility getUtil() {
		return util;
	}

	public void setUtil(Utility util) {
		this.util = util;
	}

	@Override
	public InwardFileBean mapRow(ResultSet rs, int arg1) throws SQLException {
		InwardFileBean inwardFileBean = new InwardFileBean();
		try {
			inwardFileBean.setId(rs.getLong("ID"));
			inwardFileBean.setApbsTransactionCode(rs.getString("FREE_FIELD_3"));
			// inwardFileBean.setDestinationBankIIN(rs.getString(""));
			// inwardFileBean.setDestinationAccountType(rs.getString(""));
			inwardFileBean.setLedgerFolioNumber(rs.getString("FROM_ACTOR_PARAM5"));
			if (rs.getString("FREE_FIELD_10") != null && rs.getString("FREE_FIELD_10").equalsIgnoreCase("REF_KEY")) {

				if (singletonMap.getMap().get(rs.getString("TO_ACTOR_PARAM1")) != null) {
					inwardFileBean
							.setBeneficiaryAadhaarNumber(singletonMap.getMap().get(rs.getString("TO_ACTOR_PARAM1")));
				} else {
					AadhaarVaultRequest request = new AadhaarVaultRequest();
					request.setReferenceKey(rs.getString("TO_ACTOR_PARAM1"));
					request.setRequestId("ABPS" + (new Date().getTime() * 94 % 100000000 * 6));
					request.setApiKey("paymentBank");
					inwardFileBean.setBeneficiaryAadhaarNumber(util.callVaultAPI(request));
				}
			} else
				inwardFileBean.setBeneficiaryAadhaarNumber(rs.getString("TO_ACTOR_PARAM1"));
			inwardFileBean.setBeneficiaryAccountHolderName(rs.getString("TO_ACTOR_PARAM2"));
			inwardFileBean.setSponsorBankIIN(rs.getString("FROM_ACTOR_PARAM4"));
			inwardFileBean.setUsernumber(rs.getString("FROM_ACTOR_PARAM1"));
			inwardFileBean.setUserName(rs.getString("FROM_ACTOR_PARAM2"));
			inwardFileBean.setUserCreditreference(rs.getString("FROM_ACTOR_PARAM3"));
			inwardFileBean.setAmount(rs.getString("AMOUNT"));
			inwardFileBean.setReserved1(rs.getString("PARTNER_TXN_ID"));
			inwardFileBean.setReserved2(rs.getString("FREE_FIELD_2"));
			// inwardFileBean.setReserved3(rs.getString(""));
			inwardFileBean.setDestinationBankAccountNumber(rs.getString("TO_ACTOR_PARAM3"));
			inwardFileBean.setReturnReasonCode(rs.getString("ERROR_CODE"));
			inwardFileBean.setStatus(rs.getString("STATUS"));
		} catch (Exception e) {
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}

		return inwardFileBean;
	}
	
	

}
