package com.airtel.money.util;

import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class CipherUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(CipherUtil.class);

	private static final byte[] salt = { (byte) 0xA8, (byte) 0x9B, (byte) 0xC8, (byte) 0x32, (byte) 0x56, (byte) 0x34,
			(byte) 0xE3, (byte) 0x03 };

	public static String decryptData(final String str) {
		if (StringUtils.isEmpty(str)) {
			return "";
		}

		int iterationCount = 20;

		try {
			String passphrase = "TbueAgc3azFf";
			KeySpec keySpec = new PBEKeySpec(passphrase.toCharArray(), salt, iterationCount, 128);
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
			byte[] keyBytes = keyFactory.generateSecret(keySpec).getEncoded();
			SecretKey key = new SecretKeySpec(keyBytes, "AES");
			Cipher dcipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			dcipher.init(Cipher.DECRYPT_MODE, key);
			byte[] dec = new sun.misc.BASE64Decoder().decodeBuffer(str);
			byte[] utf8 = dcipher.doFinal(dec);
			return new String(utf8, "UTF8");
		} catch (Exception e) {
			LOGGER.error("Inside CipherUtil.decryptData : with error {}", e);
		}
		return str;

	}

	public static String encryptData(final String str) {
		if (StringUtils.isEmpty(str)) {
			return "";
		}

		int iterationCount = 20;
		try {
			String passphrase = "TbueAgc3azFf";
			KeySpec keySpec = new PBEKeySpec(passphrase.toCharArray(), salt, iterationCount, 128);
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
			byte[] keyBytes = keyFactory.generateSecret(keySpec).getEncoded();
			SecretKey key = new SecretKeySpec(keyBytes, "AES");
			Cipher ecipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			ecipher.init(Cipher.ENCRYPT_MODE, key);
			byte[] utf8 = str.getBytes("UTF8");
			byte[] enc = ecipher.doFinal(utf8);
			return new sun.misc.BASE64Encoder().encode(enc);
		} catch (Exception e) {
			LOGGER.error("Inside CipherUtil.decryptData : with error {}", e);
		}
		return str;
	}

	public static void main(String[] args) {
		System.out.println("Encrypted Data :: " + encryptData("{\r\n\"referenceKey\": \"000051234567\",\r\n\"apiKey\" : \"ecaf\",\r\n\"requestId\" : \"absv73202n82ni\"\r\n}"));
		System.out.println("Decrypted Data :: " + decryptData("h8bJf5z4B94UST36n3uhBWumCJufH6EeW4EA5ji22Agwib2ur0IQTrMgK/0sOsk8zOKxiCiXvv13VOAXVgM9avgJlq19/4XRkJLFAQ/vn+E0DyWPl0AwBkG1qesDvRZK"));
	}
}
