package com.airtel.money.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.AadhaarVaultRequest;
import com.airtel.money.bean.AadhaarVaultResponse;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;
import freemarker.template.Version;

public class Utility {
	private static Logger logger = Logger.getLogger(Utility.class);
	private static SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	static SimpleDateFormat formatter1 = new SimpleDateFormat("dd-MMM-yyyy");
	static SimpleDateFormat formatter2 = new SimpleDateFormat("yyyy-MM-dd");
	private static MessageSource messageSource;
	private APIClient apiClient;
	private MessageSource messageSource2;

	public MessageSource getMessageSource2() {
		return messageSource2;
	}

	public void setMessageSource2(MessageSource messageSource2) {
		this.messageSource2 = messageSource2;
	}

	Logger LOGGER = Logger.getLogger(Utility.class);

	public static MessageSource getMessageSource() {
		return messageSource;
	}

	public static void setMessageSource(MessageSource messageSource) {
		Utility.messageSource = messageSource;
	}

	public APIClient getApiClient() {
		return apiClient;
	}

	public void setApiClient(APIClient apiClient) {
		this.apiClient = apiClient;
	}

	public static Timestamp getcurrentTimestamp() {
		Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
		return currentTimestamp;
	}

	public static boolean isFutureDate(Date date) {
		if (date != null) {
			Date currentDate = Calendar.getInstance().getTime();
			return date.after(currentDate);
		}
		return false;
	}

	/**
	 * @see this is the common method to validate using regular expression,but
	 *      method is case sensitive
	 * @param format
	 * @param invalue
	 * @return boolean
	 */
	public static boolean validate(String format, String invalue) {
		if (invalue == null)
			invalue = "";
		Pattern pattern = Pattern.compile(format);
		return pattern.matcher(invalue.trim()).matches();
	}

	/**
	 * For empty checks
	 * 
	 * @param inObj
	 * @return boolean
	 */
	public static boolean isEmpty(Object inObj) {
		if (inObj == null)
			return true;
		if (inObj instanceof String) {
			return (((String) inObj).trim().length() == 0);
		}
		if (inObj instanceof StringBuffer)
			return (((StringBuffer) inObj).length() == 0);
		if (inObj instanceof StringBuilder)
			return (((StringBuilder) inObj).length() == 0);
		if (inObj instanceof Collection<?>)
			return ((Collection<?>) inObj).isEmpty();
		if (inObj instanceof Map<?, ?>)
			return ((Map<?, ?>) inObj).isEmpty();
		if (inObj instanceof Long)
			return ((Long) inObj == 0);
		return false;
	}

	public static String getStringFromDate(Date timestamp, String format) {
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		return formatter.format(timestamp);
	}

	public static String getStringFromDate(Date timestamp) {
		if (timestamp != null) {
			return formatter1.format(timestamp);
		} else {
			return null;
		}
	}

	public static Timestamp parseStringIntoTimestamp(String date) {
		SimpleDateFormat simpleDateFormate = new SimpleDateFormat("dd-MMM-yyyy");
		Timestamp dateTimestamp = null;
		try {
			simpleDateFormate.setLenient(false);
			Date datee = simpleDateFormate.parse(date);
			dateTimestamp = new Timestamp(datee.getTime());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dateTimestamp;
	}

	public static Timestamp parseStringIntoToTimestamp(String date) {
		SimpleDateFormat simpleDateFormate = new SimpleDateFormat("dd-MMM-yyyy");
		Timestamp dateTimestamp = null;
		try {
			simpleDateFormate.setLenient(false);
			Date datee = simpleDateFormate.parse(date);
			datee.setHours(23);
			datee.setMinutes(59);
			datee.setSeconds(59);
			dateTimestamp = new Timestamp(datee.getTime());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dateTimestamp;
	}

	public static boolean validatePassword(String invalue) {
		Pattern smallCharPattern = Pattern.compile("([\\w\\?<>!@%\\^\\&]*[a-z]{1,}[\\w\\?<>!@%\\^\\&]*)");
		Pattern capsCharPattern = Pattern.compile("([\\w\\?<>!@%\\^\\&]*[A-Z]{1,}[\\w\\?<>!@%\\^\\&]*)");
		Pattern specialPattern = Pattern.compile("([\\w]*[\\?<>!@%\\^\\&]{1,}[\\w]*)");
		Pattern numericPattern = Pattern.compile("([\\w\\?<>!@%\\^\\&]*[0-9]{1,}[\\w\\?<>!@%\\^\\&]*)");
		int count = 0;
		if (smallCharPattern.matcher(invalue).matches()) {
			count++;
		}
		if (capsCharPattern.matcher(invalue).matches()) {
			count++;
		}
		if (specialPattern.matcher(invalue).matches()) {
			count++;
		}
		if (numericPattern.matcher(invalue).matches()) {
			count++;
		}
		return count > 2;
	}

	public static String generateTempPasswordString() {
		String tempPassKey = "abcABC0defgDE1FGhij2HJIk4lmKL5MnopN6OPq7rsQRS8TUVtuv9WXYwxyZz";
		String displayTempPass = "";
		for (int i = 0; i < 7; i++) {
			int position = (int) ((Math.random() * tempPassKey.length()));
			displayTempPass += tempPassKey.charAt(position);
		}
		return displayTempPass;
	}

	public static boolean hasObjectPropertyChanged(Object source, Object dest) {
		if (source != null && dest == null)
			return true;
		if (source == null && dest != null)
			return true;
		if (source == null && dest == null)
			return false;
		Class<?> classObj = source.getClass();
		Class<?> destClassObj = dest.getClass();
		Field[] declaredField = destClassObj.getDeclaredFields();
		Field[] sourceField = classObj.getDeclaredFields();
		int i = 0;
		for (Field field : declaredField) {
			String declaredName = field.getName();
			String sourceName = sourceField[i].getName();
			String declaredMethodName = "get" + Character.toUpperCase(declaredName.charAt(0))
					+ declaredName.substring(1);
			String sourceMethodName = "get" + Character.toUpperCase(declaredName.charAt(0)) + sourceName.substring(1);
			try {
				Method declaredgetterMethod = destClassObj.getDeclaredMethod(declaredMethodName);
				Method sourcegetterMethod = classObj.getDeclaredMethod(declaredMethodName);
				Object obj1 = declaredgetterMethod.invoke(dest);
				Object obj2 = sourcegetterMethod.invoke(source);
				if (obj1 != null && obj2 == null) {
					return false;
				}
				if (obj2 != null && obj1 == null) {
					return false;
				}
				if (obj1 != null && obj2 != null && !obj1.equals(obj2)) {
					System.out.println(declaredgetterMethod + "\t" + declaredgetterMethod.invoke(dest) + "\t"
							+ sourcegetterMethod.invoke(source));
					return false;
				}
			} catch (Exception e) {
				e.printStackTrace();
				logger.debug("Not saving in  " + " " + e);
			}
			i++;
		}
		return true;
	}

	public static void copyObject(Object source, Object dest) {
		Class<?> classObj = source.getClass();
		Class<?> destClassObj = dest.getClass();
		Field[] declaredField = classObj.getDeclaredFields();
		for (Field field : declaredField) {
			String name = field.getName();
			String getterMethodName = "get" + Character.toUpperCase(name.charAt(0)) + name.substring(1);
			String setterMethodName = "set" + Character.toUpperCase(name.charAt(0)) + name.substring(1);
			try {
				Method getterMethod = classObj.getDeclaredMethod(getterMethodName);
				Class returnType = getterMethod.getReturnType();
				Object obj = getterMethod.invoke(source);
				Method setterMethod = destClassObj.getDeclaredMethod(setterMethodName, new Class[] { returnType });
				setterMethod.invoke(dest, obj);
			} catch (SecurityException e) {
				Utility.logger.debug("Not saving in  " + name + " " + e);
			} catch (NoSuchMethodException e) {
				Utility.logger.info("Not saving in  " + name + " " + e);
			} catch (IllegalArgumentException e) {
				Utility.logger.debug("Not saving in  " + name + " " + e);
			} catch (IllegalAccessException e) {
				Utility.logger.debug("Not saving in  " + name + " " + e);
			} catch (InvocationTargetException e) {
				Utility.logger.debug("Not saving in  " + name + " " + e);
			}
		}
	}

	public static Timestamp addDay(Timestamp dt, int day) {
		Timestamp date = new Timestamp(dt.getTime());
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DAY_OF_WEEK, day);
		date.setTime(cal.getTime().getTime());
		date = new Timestamp(cal.getTime().getTime());
		return date;
	}

	public static String getCurrentDateInString() {
		Calendar TimeStop = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		return sdf.format(TimeStop.getTime());
	}

	public static Date getDateFromStringWithDate(String dateStringObj) {
		Date loginDate = null;
		try {
			Date fDate = formatter1.parse(dateStringObj);
			dateStringObj = formatter2.format(fDate);
			dateStringObj = dateStringObj + " 23:59:59";
			dateFormat1.parse(dateStringObj);
			loginDate = dateFormat1.parse(dateStringObj);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return loginDate;
	}

	public static String getOnlyDateFromDateTime(Timestamp birthDateTime) {
		String date = "";
		if (birthDateTime != null) {
			SimpleDateFormat dateOfBirth = new SimpleDateFormat("dd-MM-yyyy");
			date = dateOfBirth.format(birthDateTime);
		}
		return date;
	}

	/**
	 * getToDate() method is for getting today date
	 * 
	 * @return String todayDate
	 */
	public static String getTodayDate() {
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		Calendar calendar = GregorianCalendar.getInstance();
		return dateFormat.format(calendar.getTime());
	}

	/**
	 * getFromDate() method is for getting date of before 3 months
	 * 
	 * @return fromDate before 3 months.
	 */
	public static String getFromDate() {
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(new Date());
		calendar.add(GregorianCalendar.MONTH, -3);
		return dateFormat.format(calendar.getTime());
	}

	public static String getPhoneNumberFormat(String number) {
		if (number.length() > 10) {
			number = number.substring(number.length() - 10);
		}
		return number;
	}

	public static Date getDateFromString(String dateStringObj) {
		Date loginDate = null;
		SimpleDateFormat formatter1 = new SimpleDateFormat("dd-MMM-yyyy");
		SimpleDateFormat formatter2 = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date fDate = formatter1.parse(dateStringObj);
			dateStringObj = formatter2.format(fDate);
			dateFormat1.parse(dateStringObj);
			loginDate = dateFormat1.parse(dateStringObj);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return loginDate;
	}

	public void writeFile(InputStream inputStream, String fileName) throws IOException {
		OutputStream outputStream = new FileOutputStream(fileName);
		int readBytes = 0;
		byte[] buffer = new byte[10000];
		while ((readBytes = inputStream.read(buffer, 0, 10000)) != -1) {
			outputStream.write(buffer, 0, readBytes);
		}
		outputStream.close();
		inputStream.close();
	}

	public String getFileName(String originalFileName, MessageSource messageSource, Locale locale) {
		Timestamp stamp = new Timestamp(new Date().getTime());
		String stampString = stamp.toString().replace('.', '_');
		stampString = stampString.replace(':', '_');
		String fileFullName = "Excel_" + stampString + "_" + originalFileName;
		return fileFullName;
	}

	public static boolean ignoreCaseValidate(String format, String invalue) {
		if (invalue == null) {
			invalue = "";
		}
		return Pattern.compile(format, Pattern.CASE_INSENSITIVE).matcher(invalue.trim()).matches();
	}

	public static String getFileNameWithTimeStamp(String fileName, String fileExtension) {
		Date date = Calendar.getInstance().getTime();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
		return fileName + "-" + formatter.format(date) + "." + fileExtension;
	}

	public static boolean isNumeric(String obj) {
		String regexNumerix = messageSource.getMessage("regex.number", null, Locale.US);
		obj = obj.trim();
		return Utility.validate(regexNumerix, obj);
	}

	public static boolean isNumberStartWithZero(String obj) {
		String regexStartsWithZero = messageSource.getMessage("regex.number.startwithzero", null, Locale.US);
		obj = obj.trim();
		return Utility.validate(regexStartsWithZero, obj);
	}

	public static boolean isCorrectMailId(String obj) {
		String regexMailId = messageSource.getMessage("regex.email.address", null, Locale.US);
		obj = obj.trim();
		return Utility.validate(regexMailId, obj);
	}

	public static boolean isCorrectName(String obj) {
		String regexName = messageSource.getMessage("regex.for.name", null, Locale.US);
		obj = obj.trim();
		return Utility.validate(regexName, obj);
	}

	public static String getFtlResponse(String fileName, Map<String, Object> mapObj)
			throws IOException, TemplateException {
		Configuration cfg = new Configuration();

		// Where do we load the templates from:
		// cfg.setClassForTemplateLoading(MainTest.class, "/");

		cfg.setDirectoryForTemplateLoading(new File("templates"));

		// Some other recommended settings:
		cfg.setIncompatibleImprovements(new Version(2, 3, 20));
		cfg.setDefaultEncoding("UTF-8");
		cfg.setLocale(Locale.US);
		cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
		Template template = cfg.getTemplate(fileName);

		Writer out = new StringWriter();
		template.process(mapObj, out);
		String transformedTemplate = out.toString();
		out.flush();
		return transformedTemplate;
	}

	public String callVaultAPI(AadhaarVaultRequest request) {
		String requestObj = null;
		// APIClient apiClient=new APIClient();
		try {
			Map<String, Object> input = new HashMap<String, Object>();
			AadhaarVaultResponse resp = null;
			input.put("bean", request);
			if (request.getReferenceKey() != null) {
				requestObj = Utility.getFtlResponse("aadhaar_vault_key.ftl", input);
				resp = apiClient.invokeAPI(messageSource2.getMessage("aadhar.vault.aadhaar.url", null, Locale.US),
						requestObj);
			} else if (request.getUid() != null) {
				requestObj = Utility.getFtlResponse("aadhaar_vault_uid.ftl", input);
				resp = apiClient.invokeAPI(messageSource2.getMessage("aadhar.vault.refkey.url", null, Locale.US),
						requestObj);
			}

			if (resp != null && resp.getResult().getStatusCode().equalsIgnoreCase("uid-00")) {
				if (request.getReferenceKey() != null)
					return resp.getUid();
				else
					return resp.getReferenceKey();
			} else
				return null;

		}

		catch (Exception e) {
			LOGGER.info("Exception while calling Aadhar Vault Service" + e);
			return null;

		}

	}

	
	  public static void main(String[] args) {
	  
	  /*Utility util =new Utility();
	  AadhaarVaultRequest request = new AadhaarVaultRequest(); 
	  request.setUid("970964850993");
	  request.setRequestId("ABPS" + (new Date().getTime() * 94 % 100000000 * 6)); 
	  request.setApiKey("paymentBank"); 
	  util.callVaultAPI(request);*/
		  
	//	  String data="{\r\n\"uid\": \"938852442073\",\r\n\"apiKey\" : \"paymentBank\",\r\n\"requestId\" : \"ABPS380933628\"\r\n} "; 
	//	System.out.println(  CipherUtil.encryptData(String.valueOf(data.hashCode())));
		  
		//  System.out.println(CipherUtil.encryptData(""));
	  
	  }
	 

}
