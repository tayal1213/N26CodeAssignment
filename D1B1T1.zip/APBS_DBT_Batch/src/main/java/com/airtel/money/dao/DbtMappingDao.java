package com.airtel.money.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.jdbc.core.JdbcTemplate;

import com.airtel.money.bean.AadharSeedingResponseXmlBean;
import com.airtel.money.bean.ApbsErrorLogBean;
import com.airtel.money.bean.DbtMappingDetailsBean;
import com.airtel.money.bean.DbtReasonCode;
import com.airtel.money.bean.ETLSummary;
import com.airtel.money.bean.TimeoutCountBean;
import com.airtel.money.bean.TrmtReconData;
import com.airtel.money.mapper.DbtMappingDetailsBeanMapper;
import com.airtel.money.mapper.DbtReasonCodeMapper;
import com.airtel.money.mapper.EtlSummaryMapper;
import com.airtel.money.mapper.TimeoutCountMapper;
import com.airtel.money.mapper.TrmtReconDataMapper;

public class DbtMappingDao {
	private MessageSource messageSource;

	final Logger LOGGER = Logger.getLogger(DbtMappingDao.class);

	private DataSource dataSourceReport;
	private DataSource dataSourceVolt;

	private JdbcTemplate jdbcTemplateObjectReport;
	private JdbcTemplate jdbcTemplateObjectVolt;

	public boolean isEtlTransactionAlready(Long partnerTxnId) {

		boolean isExist = false;
		String SQL = "select count(PARTNER_TXN_ID) from ETL_TRANSACTION where PARTNER_TXN_ID=?";

		try {
			int count = jdbcTemplateObjectReport.queryForObject(SQL, new Object[] { partnerTxnId }, Integer.class);
			if (count > 0) {
				isExist = true;
			}

		} catch (org.springframework.dao.EmptyResultDataAccessException e) {
			LOGGER.warn("APBS Batch:  No Records found: " + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
			e.printStackTrace();
		}
		return isExist;

	}

	public boolean isAadhaarExist(String aadhar) {

		boolean isExist = false;
		String SQL = "select AADHAR_NUMBER from DBT_MAPPING_DETAILS where AADHAR_NUMBER=?";

		try {
			String aadharNumber = jdbcTemplateObjectVolt.queryForObject(SQL, new Object[] { aadhar }, String.class);
			if (aadharNumber != null) {
				isExist = true;
			}

		} catch (org.springframework.dao.EmptyResultDataAccessException e) {
			LOGGER.warn("APBS Batch:  No Records found: " + e.getMessage());
		//	e.printStackTrace();
		} catch (Exception e) {
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		//	e.printStackTrace();
		}
		return isExist;

	}

	public TrmtReconData getTrmtReconData(String partnerTxnId) {
		TrmtReconData trmtReconData = null;
		// String SQL = "select * from TRMT_HOURLY where tran_ref_no=?";

		String SQL = "select * from volt_txn_log where SERVICE_PROVIDER_SESSION_ID=?";

		try {
			List<TrmtReconData> lstTrmtReconData = jdbcTemplateObjectVolt.query(SQL, new Object[] { partnerTxnId },
					new TrmtReconDataMapper());
			if (lstTrmtReconData != null && lstTrmtReconData.size() > 0) {
				trmtReconData = lstTrmtReconData.get(0);
			}

		} catch (org.springframework.dao.EmptyResultDataAccessException e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  No Records found: " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}
		return trmtReconData;
	}

	public List<DbtReasonCode> getDbtReturnCode() {
		List<DbtReasonCode> lstDbtReasonCode = new ArrayList<DbtReasonCode>();
		String SQL = "select * from DBT_REASON_CODE where status='ACTIVE'";

		try {
			lstDbtReasonCode = jdbcTemplateObjectReport.query(SQL, new Object[] {}, new DbtReasonCodeMapper());

		} catch (org.springframework.dao.EmptyResultDataAccessException e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  No Records found: " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}
		return lstDbtReasonCode;
	}

	public boolean updateETLSummaryStatus(Long etlId) {
		try {
			String sql = "update ETL_SUMMARY set STATUS='COMPLETED', MODIFIED_TIMESTAMP=? where ID=?";
			jdbcTemplateObjectReport.update(sql, new Object[] { new Timestamp(System.currentTimeMillis()), etlId });
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch: Error in updating ETL_TRANSACTION: " + e.getMessage());
			return false;
		}
		return true;

	}

	public boolean updateETLSummaryFileName(Long etlId, String fileName) {
		try {
			String sql = "update ETL_SUMMARY set STATUS='SENT_TO_NPCI',OUTPUT_FILENAME=?, MODIFIED_TIMESTAMP=? where ID=?";
			jdbcTemplateObjectReport.update(sql,
					new Object[] { fileName, new Timestamp(System.currentTimeMillis()), etlId });
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch: Error in updating ETL_TRANSACTION: " + e.getMessage());
			return false;
		}
		return true;

	}
	//

	public List<TimeoutCountBean> getTimeoutCount(String etlIds) {
		List<TimeoutCountBean> lstTimeoutCountBean = null;

		try {
			String sql = "select ETL_SUMMARY_ID, count(1) as total_count,  count( case when status ='2' or status is null then 'x' end ) as timeout_count from ETL_TRANSACTION where  ETL_SUMMARY_ID in ("
					+ etlIds + ") group by ETL_SUMMARY_ID";
			lstTimeoutCountBean = jdbcTemplateObjectReport.query(sql, new Object[] {}, new TimeoutCountMapper());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch: Error in updating ETL_TRANSACTION: " + e.getMessage());
		}
		return lstTimeoutCountBean;
	}

	public List<ETLSummary> getEtlSummary() {
		List<ETLSummary> lstEtlSummarie = null;
		try {
			String sql = messageSource.getMessage("inward.return.etl.summary.read.query", null, Locale.US);
			lstEtlSummarie = jdbcTemplateObjectReport.query(sql, new Object[] {}, new EtlSummaryMapper());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch: Error in updating ETL_TRANSACTION: " + e.getMessage());
		}
		return lstEtlSummarie;
	}

	//
	public Long getErrorSeq() {

		String SQL = "select ABPS_ERROR_LOG_SEQ.nextval from dual";
		Long seqNo = 0l;
		try {
			seqNo = jdbcTemplateObjectReport.queryForObject(SQL, new Object[] {}, Long.class);
		} catch (org.springframework.dao.EmptyResultDataAccessException e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  No Sequence found: " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}
		return seqNo;

	}

	public void insertApbsErrorLog(ApbsErrorLogBean errorLog) {

		try {
			errorLog.setId(getErrorSeq());
			errorLog.setCreatedTime(new Timestamp(System.currentTimeMillis()));
			String sql = "Insert into ABPS_ERROR_LOG (ID,ERROR_MSG,BATCH_NAME,CREATED_TIME,INPUT_DATA,FILE_NAME) values "
					+ " (?,?,?,?,?,?)";

			jdbcTemplateObjectReport.update(sql,
					new Object[] { errorLog.getId(), errorLog.getErrorMsg(), errorLog.getBatchName(),
							errorLog.getCreatedTime(), errorLog.getInputData(), errorLog.getFileName() });
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}

	}

	public void insertEtlIdsInward(Collection<Long> lstEtlIds, String type) {

		try {
			for (Long id : lstEtlIds) {
				String sql = "Insert into ETL_IDS (ID,TYPE) values  (?,?)";
				//
				jdbcTemplateObjectReport.update(sql, new Object[] { id, type });
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}

	}

	public void deleteEtlIdsInward(String type) {

		try {

			String sql = "delete from ETL_IDS where type=?";

			jdbcTemplateObjectReport.update(sql, new Object[] { type });

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}

	}

	public boolean updateTransaction(Map<String, Object> body) {
		// {ampTxnId=577181434, amount=200, message=Transaction Successful,
		// volt_transaction_id=7605591, customerId=7827968400, flag=0,
		// partnerTxnId=673, status=SUCCESS}
		LOGGER.info("Inside DbtMappingDao.updateTransaction");
		try {
			String sql = "update ETL_TRANSACTION set VOLT_TXN_ID=?, CORE_TXN_ID=?, STATUS=?, REMARKS=?, ERROR_CODE=?, FREE_FIELD_1=? where PARTNER_TXN_ID=?";
			int count = jdbcTemplateObjectReport.update(sql,
					new Object[] { body.get("voltTxnId"), body.get("ampTxnId"), body.get("status"), body.get("message"),
							body.get("errorCode"), "PROCESSED", body.get("partnerTxnId") });
			LOGGER.info(count + " record updated.");
		} catch (Exception e) {
			e.printStackTrace();

			LOGGER.warn("APBS Batch: Error in updating ETL_TRANSACTION: " + e.getMessage());
			return false;
		}
		return true;
	}

	public DbtMappingDetailsBean getDbtMappingDetailsBeanByAadhaar(String refKey) {

		DbtMappingDetailsBean dbtMappingDetailsBean = null;
		List<DbtMappingDetailsBean> lstDbtMappingDetailsBean = new ArrayList<DbtMappingDetailsBean>();
		String SQL = "select * from DBT_MAPPING_DETAILS where AADHAR_NUMBER = ?";

		try {
			lstDbtMappingDetailsBean = jdbcTemplateObjectVolt.query(SQL, new Object[] { refKey },
					new DbtMappingDetailsBeanMapper());
			if (lstDbtMappingDetailsBean != null && lstDbtMappingDetailsBean.size() > 0) {
				dbtMappingDetailsBean = lstDbtMappingDetailsBean.get(0);
			}
		} catch (org.springframework.dao.EmptyResultDataAccessException e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  No Records found: " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}
		return dbtMappingDetailsBean;

	}

	public boolean checkFileAlreadyExist(String fileName) {
		boolean isExist = false;
		String SQL = "select count(1) from ETL_SUMMARY where INPUT_FILENAME = ? and STATUS in ('COMPLETED','SENT_TO_NPCI')";
		try {
			Integer count = jdbcTemplateObjectReport.queryForObject(SQL, new Object[] { fileName }, Integer.class);
			if (count != null && count > 0) {
				isExist = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}
		return isExist;
	}

	public List<DbtMappingDetailsBean> getDbtMappingDetailsBean() {
		//
		List<DbtMappingDetailsBean> lstCustomerMasterData = new ArrayList<DbtMappingDetailsBean>();
		String SQL = "select * from DBT_MAPPING_DETAILS where AADHAR_NUMBER in(select AADHAAR_NO from DBT_XML_DATA) and DBT_STATUS='ACTIVE'";
		try {
			lstCustomerMasterData = jdbcTemplateObjectVolt.query(SQL, new Object[] {},
					new DbtMappingDetailsBeanMapper());
		} catch (org.springframework.dao.EmptyResultDataAccessException e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  No record found: " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}
		return lstCustomerMasterData;
	}

	public boolean truncateXmlDataTbl() {
		try {
			jdbcTemplateObjectVolt.execute("TRUNCATE TABLE DBT_XML_DATA");

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
			return false;
		}
		return true;
	}

	public Long getDBTHeaderSeq() {
		String SQL = "select ETL_SUMMARY_SEQ.nextval from dual";
		Long seqNo = 0l;
		try {
			seqNo = jdbcTemplateObjectReport.queryForObject(SQL, new Object[] {}, Long.class);
		} catch (org.springframework.dao.EmptyResultDataAccessException e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  No Sequence found: " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}
		return seqNo;
	}

	public void insertHeaderInfo(ETLSummary etlSummary) {

		try {
			String sql = "Insert into ETL_SUMMARY (ID,UC_ID,INPUT_FILENAME,OUTPUT_FILENAME,CREATED_TIMESTAMP,MODIFIED_TIMESTAMP,TOTAL_AMOUNT,RECORD_COUNT,STATUS,CHANNEL)"
					+ "values (?,?,?,?,?,?,?,?,?,?) ";
			jdbcTemplateObjectReport.update(sql,
					new Object[] { etlSummary.getId(), etlSummary.getUcId(), etlSummary.getInputFilename(),
							etlSummary.getOutputFilename(), etlSummary.getCreatedTimestamp(),
							etlSummary.getModifiedTimestamp(), etlSummary.getTotalAmount(), etlSummary.getRecordCount(),
							etlSummary.getStatus(), etlSummary.getChannel() });
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}

	}

	public void insert(AadharSeedingResponseXmlBean asrBean) {

		try {
			String sql = "Insert into DBT_XML_DATA (AADHAAR_NO,MAPPED_IIN,SCHEME,MANDATE_CUST_DATE,MAPPING_STATUS,UID_REASON_CODE,UID_RESULT,ACCEPTED) "
					+ "values (?,?,?,?,?,?,?,?)";
			jdbcTemplateObjectVolt.update(sql,
					new Object[] { asrBean.getAadharNo(), asrBean.getMappedIin(), asrBean.getScheme(),
							asrBean.getMandateCustDate(), asrBean.getMappingStatus(), asrBean.getUidReasonCode(),
							asrBean.getUidResult(), asrBean.getAccepted() });
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}

	}

	public Integer getAadharSeedingSeq() {
		String SQL = "select AADHAR_SEEDING_SEQ.nextval from dual";
		Integer seqNo = 0;
		try {
			seqNo = jdbcTemplateObjectReport.queryForObject(SQL, new Object[] {}, Integer.class);
		} catch (org.springframework.dao.EmptyResultDataAccessException e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  No Sequence found: " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}
		return seqNo;
	}

	public Integer getInwardHeaderSeq() {
		String SQL = "select INWARD_HEADER_SEQ.nextval from dual";
		Integer seqNo = 0;
		try {
			seqNo = jdbcTemplateObjectReport.queryForObject(SQL, new Object[] {}, Integer.class);
		} catch (org.springframework.dao.EmptyResultDataAccessException e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch: No Sequence found" + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}
		return seqNo;
	}

	public Long getTotalAmt(Long etlSummaryID) {
		Long totalAmt = 0l;
		String SQL = messageSource.getMessage("inward.return.row.amout.query", null, Locale.US);
		Double amt = 0.0;
		try {
			amt = jdbcTemplateObjectReport.queryForObject(SQL, new Object[] { etlSummaryID }, Double.class);
			if (amt != null)
				totalAmt = Math.round(amt * 100);
		} catch (org.springframework.dao.EmptyResultDataAccessException e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  No record found in ETL_TRANSACTION : " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}
		return totalAmt;
	}

	public Integer getDbtMappingCount() {

		String SQL = messageSource.getMessage("aadhar.seeding.flat.file.row.count.query", null, Locale.US);
		int count = 0;
		try {
			count = jdbcTemplateObjectVolt.queryForObject(SQL, new Object[] {}, Integer.class);
		} catch (org.springframework.dao.EmptyResultDataAccessException e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  No record found in DBT_MAPPING_DETAILS : " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}
		return count;
	}

	public AadharSeedingResponseXmlBean getNationId(AadharSeedingResponseXmlBean bean) {
		String SQL = messageSource.getMessage("response.profile.fetch.natlid", null, Locale.US);

		try {
			String natId = jdbcTemplateObjectVolt.queryForObject(SQL, new Object[] { bean.getAadharNo() },
					String.class);
			bean.setNatId(natId);
		} catch (org.springframework.dao.EmptyResultDataAccessException e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  No record found in DBT_MAPPING_DETAILS : " + e.getMessage());

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());

		}
		return bean;
	}

	public Integer getInwardMappingCount(Long etlSummaryId) {
		String SQL = messageSource.getMessage("inward.return.row.count.query", null, Locale.US);
		int count = 0;
		try {
			count = jdbcTemplateObjectReport.queryForObject(SQL, new Object[] { etlSummaryId }, Integer.class);
		} catch (org.springframework.dao.EmptyResultDataAccessException e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  No record found in ETL_TRANSACTION : " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
		}
		return count;
	}

	public boolean updateAadhaarVaultNumbers() {
		try {
			String sql = messageSource.getMessage("dbt.aadhaar.vault.query", null, Locale.US);
			// String sql = "update ETL_TRANSACTION set TO_ACTOR_PARAM1='',
			// MODIFIED_TIMESTAMP=? where created_timestamp>=trunc(sysdate) and
			// etl_summary_id in(select id from ETL_SUMMARY where
			// created_timestamp>=trunc(sysdate) ) and free_field_4 is not
			// null";
			jdbcTemplateObjectReport.update(sql, new Object[] {});
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warn("APBS Batch: Error in updating ETL_TRANSACTION: " + e.getMessage());
			return false;
		}
		return true;

	}

	public boolean isAllInwardCompleted() {
		String sql = messageSource.getMessage("dbt.inward.completed.check", null, Locale.US);
		boolean iscompleted=false;
		try {
			int count = jdbcTemplateObjectReport.queryForObject(sql, new Object[] {}, Integer.class);
			if (count > 0) {
				return iscompleted;
			}
			else
				iscompleted=true;

		} catch (org.springframework.dao.EmptyResultDataAccessException e) {
			LOGGER.warn("APBS Batch:  No Records found: " + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			LOGGER.warn("APBS Batch:  Exception occured: " + e.getMessage());
			e.printStackTrace();
		}
		return iscompleted;

	}

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public DataSource getDataSourceReport() {
		return dataSourceReport;
	}

	public void setDataSourceReport(DataSource dataSourceReport) {
		this.dataSourceReport = dataSourceReport;
		jdbcTemplateObjectReport = new JdbcTemplate(dataSourceReport);
	}

	public void setDataSourceVolt(DataSource dataSourceVolt) {
		this.dataSourceVolt = dataSourceVolt;
		jdbcTemplateObjectVolt = new JdbcTemplate(dataSourceVolt);
	}

	public DataSource getDataSourceVolt() {
		return dataSourceVolt;
	}
}
