package com.airtel.money.bean;

public class TimeoutCountBean 
{
	private Long etlSummaryId;
	private Long totalCount;
	private Long timeoutCount;
	public Long getEtlSummaryId() {
		return etlSummaryId;
	}
	public void setEtlSummaryId(Long etlSummaryId) {
		this.etlSummaryId = etlSummaryId;
	}
	public Long getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}
	public Long getTimeoutCount() {
		return timeoutCount;
	}
	public void setTimeoutCount(Long timeoutCount) {
		this.timeoutCount = timeoutCount;
	}
	
}
