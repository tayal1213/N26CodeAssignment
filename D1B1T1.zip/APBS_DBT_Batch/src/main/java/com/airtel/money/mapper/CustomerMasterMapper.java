package com.airtel.money.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.airtel.money.bean.CustomerMaster;

public class CustomerMasterMapper implements RowMapper<CustomerMaster>
{

	@Override
	public CustomerMaster mapRow(ResultSet rs, int arg1) throws SQLException 
	{
		CustomerMaster customerMaster = new  CustomerMaster();
		customerMaster.setActorType(rs.getString("ACTOR_TYPE"));
		customerMaster.setMsisdn(rs.getString("MSISDN"));
		return customerMaster;
	}

}
