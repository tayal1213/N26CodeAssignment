package com.airtel.money.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.airtel.money.bean.DbtMappingDetailsBean;

public class DbtMappingDetailsBeanMapper implements RowMapper<DbtMappingDetailsBean>
{

	Logger LOGGER = Logger.getLogger(DbtMappingDetailsBeanMapper.class);
	@Override
	public DbtMappingDetailsBean mapRow(ResultSet rs, int arg1) throws SQLException 
	{
		DbtMappingDetailsBean dbtMappingDetailsBean = new DbtMappingDetailsBean();
		try 
		{     //Aadhaar Vault Changes
			//dbtMappingDetailsBean.setAadharNumber(rs.getLong("AADHAR_NUMBER"));
			dbtMappingDetailsBean.setRefKey(rs.getString("AADHAR_NUMBER"));
			dbtMappingDetailsBean.setAccNumber(rs.getLong("ACC_NUMBER"));
			dbtMappingDetailsBean.setDbtStatus(rs.getString("DBT_STATUS"));
			dbtMappingDetailsBean.setActivationStatus(rs.getString("ACTIVATION_STATUS"));
			dbtMappingDetailsBean.setMandateTimestamp(rs.getTimestamp("MANDATE_TIMESTAMP"));
			dbtMappingDetailsBean.setCreatedTimestamp(rs.getTimestamp("CREATED_TIMESTAMP"));
			dbtMappingDetailsBean.setCreatedChannel(rs.getString("CREATED_CHANNEL"));
			dbtMappingDetailsBean.setModifiedChannel(rs.getString("MODIFIED_CHANNEL"));
			dbtMappingDetailsBean.setFileName(rs.getString("FILE_NAME"));
			dbtMappingDetailsBean.setUidReasonCode(rs.getString("UID_REASON_CODE"));
			dbtMappingDetailsBean.setUidResult(rs.getString("UID_RESULT"));
			dbtMappingDetailsBean.setCustMsisdn(rs.getString("CUST_MSISDN"));
			dbtMappingDetailsBean.setAccHolderName(rs.getString("ACC_HOLDER_NAME"));
			dbtMappingDetailsBean.setIsRefKey(rs.getString("IS_REF_NO_UPDATED"));
		} 
		catch (Exception e) 
		{
			LOGGER.error("APBS Batch:  Exception occured: "+e.getMessage());
		}
		return dbtMappingDetailsBean;
	}

}
