package com.airtel.money.bean;

public class AadharSeedingResponseXmlBean {
	private String aadharNo;
	private String refKey;
	private String mappedIin;
	private String scheme;
	private String mandateCustDate;
	private String mappingStatus;
	private String uidReasonCode;
	private String uidResult;
	private String accepted;
	private String status;
	private String extRefNum;
	private String natId;

	public String getRefKey() {
		return refKey;
	}

	public void setRefKey(String refKey) {
		this.refKey = refKey;
	}

	public String getNatId() {
		return natId;
	}

	public void setNatId(String natId) {
		this.natId = natId;
	}

	public String getExtRefNum() {
		return extRefNum;
	}

	public void setExtRefNum(String extRefNum) {
		this.extRefNum = extRefNum;
	}

	public String getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}

	public String getMappedIin() {
		return mappedIin;
	}

	public void setMappedIin(String mappedIin) {
		this.mappedIin = mappedIin;
	}

	public String getScheme() {
		return scheme;
	}

	public void setScheme(String scheme) {
		this.scheme = scheme;
	}

	public String getMandateCustDate() {
		return mandateCustDate;
	}

	public void setMandateCustDate(String mandateCustDate) {
		this.mandateCustDate = mandateCustDate;
	}

	public String getMappingStatus() {
		return mappingStatus;
	}

	public void setMappingStatus(String mappingStatus) {
		this.mappingStatus = mappingStatus;
	}

	public String getUidReasonCode() {
		return uidReasonCode;
	}

	public void setUidReasonCode(String uidReasonCode) {
		this.uidReasonCode = uidReasonCode;
	}

	public String getUidResult() {
		return uidResult;
	}

	public void setUidResult(String uidResult) {
		this.uidResult = uidResult;
	}

	public String getAccepted() {
		return accepted;
	}

	public void setAccepted(String accepted) {
		this.accepted = accepted;
	}

	@Override
	public String toString() {
		return "AadharSeedingResponseXmlBean [aadharNo=" + aadharNo + ", mappedIin=" + mappedIin + ", scheme=" + scheme
				+ ", mandateCustDate=" + mandateCustDate + ", mappingStatus=" + mappingStatus + ", uidReasonCode="
				+ uidReasonCode + ", uidResult=" + uidResult + ", accepted=" + accepted + "]";
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}