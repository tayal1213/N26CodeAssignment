package com.airtel.money.processor;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.ApbsErrorLogBean;
import com.airtel.money.bean.DbtReasonCode;
import com.airtel.money.bean.InwardFileBean;
import com.airtel.money.bean.InwardFileDataBean;
import com.airtel.money.bean.TrmtReconData;
import com.airtel.money.dao.DbtMappingDao;
import com.airtel.money.util.Utility;

public class InwarFileProcessor implements ItemProcessor<InwardFileBean, InwardFileBean> 
{

	Logger LOGGER = Logger.getLogger(InwarFileProcessor.class);
	private MessageSource messageSource = null;
	private DbtMappingDao dbtMappingDao = null;
	private InwardFileDataBean inwardFileDataBean = null;
	
	Map<String,DbtReasonCode> mapDbtReasonCode = new HashMap<String,DbtReasonCode>();
	public void initIt()  throws Exception
	{
		List<DbtReasonCode> lstDbtReasonCode = dbtMappingDao.getDbtReturnCode();
		for(DbtReasonCode  dbtReasonCode : lstDbtReasonCode)
		{
			mapDbtReasonCode.put(dbtReasonCode.getMappingCode(), dbtReasonCode);
		}
		
	}
	@Override
	public InwardFileBean process(InwardFileBean inwardFileBean) throws Exception 
	{
		LOGGER.info("APBS Batch: Record being processing for inwardFileBean: "+inwardFileBean);
		try 
		{
			inwardFileBean.setOutputFileName(inwardFileDataBean.getFileName());
			
			
			int destinationBankIINLength = 9;
			int ledgerFolioNumberLength = 3;
			int beneficiaryAadhaarNumberLength = 15;
			int beneficiaryAccountHolderNameLength = 40;
			int sponsorBankIINLength = 9;
			int usernumberLength = 7;
			int userNameLength = 20;
			int userCreditreferenceLength = 13;
			int amountLength = 13;
			int reserved1Length = 10;
			int reserved2Length = 10;
			int reserved3Length = 2;
			int destinationBankAccountNumberLength = 20;
			int returnReasonCodeLength = 2;
			
			String apbsTransactionCode = inwardFileBean.getApbsTransactionCode()==null?messageSource.getMessage("inward.return.apbs.transaction.code", null,Locale.US):inwardFileBean.getApbsTransactionCode();
			String destinationBankIIN =  messageSource.getMessage("inward.return.destination.bank.iin", null,Locale.US);
			String destinationAccountType =  messageSource.getMessage("inward.return.destination.account.type", null, Locale.US);
			
			String ledgerFolioNumber =  inwardFileBean.getLedgerFolioNumber()==null?"":inwardFileBean.getLedgerFolioNumber(); 
			String beneficiaryAadhaarNumber =  inwardFileBean.getBeneficiaryAadhaarNumber()==null?"":inwardFileBean.getBeneficiaryAadhaarNumber();
			String beneficiaryAccountHolderName =  inwardFileBean.getBeneficiaryAccountHolderName()==null?"":inwardFileBean.getBeneficiaryAccountHolderName();
			while(beneficiaryAccountHolderName.length()>40)
			{
				beneficiaryAccountHolderName = beneficiaryAccountHolderName.substring(0,40);
			}
			String sponsorBankIIN =  inwardFileBean.getSponsorBankIIN()==null?"":inwardFileBean.getSponsorBankIIN(); 
			String usernumber =  inwardFileBean.getUsernumber()==null?"":inwardFileBean.getUsernumber(); 
			String userName =  inwardFileBean.getUserName()==null?"":inwardFileBean.getUserName(); 
			String userCreditreference =  inwardFileBean.getUserCreditreference()==null?"":inwardFileBean.getUserCreditreference(); 
			
			String amount =  inwardFileBean.getAmount()==null?"":""+Math.round(Double.valueOf(inwardFileBean.getAmount())*100); 
			String reserved1 =  inwardFileBean.getReserved1()==null?"":inwardFileBean.getReserved1(); 
			String reserved2 =  inwardFileBean.getReserved2()==null?"":inwardFileBean.getReserved2(); 
			String reserved3 =  inwardFileBean.getReserved3()==null?"":inwardFileBean.getReserved3(); 
			String destinationBankAccountNumber =  inwardFileBean.getDestinationBankAccountNumber()==null?"":inwardFileBean.getDestinationBankAccountNumber(); 
			String returnReasonCode =  inwardFileBean.getReturnReasonCode()==null?"":inwardFileBean.getReturnReasonCode(); 
			
			StringBuffer sb = new StringBuffer();
			
						
			
			// 1	APBS Transaction Code				2
			sb.append(apbsTransactionCode);
			
			// 2	Destination Bank IIN				9			
			for(int i=0;i<destinationBankIINLength-destinationBankIIN.length();i++)
			{
				sb.append("0");
			}
			sb.append(destinationBankIIN);
			
			// 3	Destination Account Type			2			
			sb.append(destinationAccountType);
			
			// 4	Ledger Folio Number					3			
			for(int i=0;i<ledgerFolioNumberLength-ledgerFolioNumber.length();i++)
			{
				sb.append(" ");
			}
			sb.append(ledgerFolioNumber);
			
			// 5	Beneficiary Aadhaar Number			15			
			for(int i=0;i<beneficiaryAadhaarNumberLength-beneficiaryAadhaarNumber.length();i++)
			{
				sb.append("0");
			}
			sb.append(beneficiaryAadhaarNumber);
			
			// 6	Beneficiary account holder's name	40			
			sb.append(beneficiaryAccountHolderName);
			for(int i=0;i<beneficiaryAccountHolderNameLength-beneficiaryAccountHolderName.length();i++)
			{
				sb.append(" ");
			}
			
			// 7	Sponsor Bank IIN					9			
			for(int i=0;i<sponsorBankIINLength-sponsorBankIIN.length();i++)
			{
				sb.append("0");
			}
			sb.append(sponsorBankIIN);
			
			// 8	User number							7
			for(int i=0;i<usernumberLength-usernumber.length();i++)
			{
				sb.append("0");
			}
			sb.append(usernumber);
			
			
			// 9	User Name							20
			sb.append(userName);
			for(int i=0;i<userNameLength-userName.length();i++)
			{
				sb.append(" ");
			}
			
			// 10	User Credit reference				13
			sb.append(userCreditreference);
			for(int i=0;i<userCreditreferenceLength-userCreditreference.length();i++)
			{
				sb.append(" ");
			}
			
			
			// 11	Amount	13
			for(int i=0;i<amountLength-amount.length();i++)
			{
				sb.append("0");
			}
			sb.append(amount);
			
			// 12	Reserved (Kept blank by user)		10
			
			for(int i=0;i<reserved1Length-reserved1.length();i++)
			{
				sb.append("0");
			}
			sb.append(reserved1);
			
			// 13	Reserved (Kept blank by user)		10
			sb.append(reserved2);
			for(int i=0;i<reserved2Length-reserved2.length();i++)
			{
				sb.append(" ");
			}
			
			
			// 14	Reserved (Kept blank by user)		2
			sb.append(reserved3);
			for(int i=0;i<reserved3Length-reserved3.length();i++)
			{
				sb.append(" ");
			}

						
			// 15	Destination bank account number		20
			sb.append(destinationBankAccountNumber);
			for(int i=0;i<destinationBankAccountNumberLength-destinationBankAccountNumber.length();i++)
			{
				sb.append(" ");
			}
			
			// 16	Return reason code					2
			if(inwardFileBean.getStatus()==null || inwardFileBean.getStatus().equals("1"))
			{
				String dbtReasonCode =mapDbtReasonCode.get(returnReasonCode)==null?"": mapDbtReasonCode.get(returnReasonCode).getDbtCode();				
				if(Utility.isEmpty(dbtReasonCode))
				{
					sb.append("59");
				}
				else
				{
					for(int i=0;i<returnReasonCodeLength-dbtReasonCode.length();i++)
					{
						sb.append(" ");
					}
					sb.append(dbtReasonCode);
				}				
			}
			else
			{
				sb.append("  ");
			}
			inwardFileBean.setFlatFileRow(sb.toString());
			
		} 
		catch (Exception e) 
		{
			ApbsErrorLogBean apbsErrorLogBean = new ApbsErrorLogBean();
			apbsErrorLogBean.setBatchName("inward-file-job");
			apbsErrorLogBean.setErrorMsg(e.getMessage());
			apbsErrorLogBean.setInputData(inwardFileBean.toString());
			dbtMappingDao.insertApbsErrorLog(apbsErrorLogBean);
			LOGGER.warn("APBS Batch:  Exception occured: "+e);
			e.printStackTrace();
			return null;
		}
		
		return inwardFileBean;
	}
	public MessageSource getMessageSource() {
		return messageSource;
	}
	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}
	public DbtMappingDao getDbtMappingDao() {
		return dbtMappingDao;
	}
	public void setDbtMappingDao(DbtMappingDao dbtMappingDao) {
		this.dbtMappingDao = dbtMappingDao;
	}
	public InwardFileDataBean getInwardFileDataBean() {
		return inwardFileDataBean;
	}
	public void setInwardFileDataBean(InwardFileDataBean inwardFileDataBean) {
		this.inwardFileDataBean = inwardFileDataBean;
	}
	
	public static void main(String[] args) {
		//String amt = "136.17";
		//String amt = "8506.8";
		/*String amt = "157.18";
		System.out.println("#"+Math.round(Double.valueOf(amt)*100));
		System.out.println(Double.valueOf(amt)*100);
		System.out.println(Float.valueOf(amt)*100);
		System.out.println(amt.replace(".", ""));
		System.out.println((long)(Double.valueOf(amt)*100));
		System.out.println((long)(Float.valueOf(amt)*100));*/
		
		String str = "12345";
		System.out.println(str.length());
		System.out.println(str.substring(0,5));
		
		
		
		
	}
}
