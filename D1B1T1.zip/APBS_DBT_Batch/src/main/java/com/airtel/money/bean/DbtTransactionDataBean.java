package com.airtel.money.bean;

import java.util.Map;

public class DbtTransactionDataBean 
{
	private Long etlSummaryId;
	private String fileName;
	private String etlIds;
	
	Map<String, Long> mapFileEtlId;

	public Long getEtlSummaryId() {
		return etlSummaryId;
	}

	public void setEtlSummaryId(Long etlSummaryId) {
		this.etlSummaryId = etlSummaryId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Map<String, Long> getMapFileEtlId() {
		return mapFileEtlId;
	}

	public void setMapFileEtlId(Map<String, Long> mapFileEtlId) {
		this.mapFileEtlId = mapFileEtlId;
	}

	public String getEtlIds() 
	{
		String str = "";
		for(Long etlId: mapFileEtlId.values())
		{
			str = str+etlId+",";
		}
		if(str.length()>0)
		{
			etlIds = str.substring(0,str.length()-1);
		}
		return etlIds;
	}

	public void setEtlIds(String etlIds) {
		this.etlIds = etlIds;
	}
	
	
}
