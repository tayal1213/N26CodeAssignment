package com.airtel.money.batch.listeners;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;

import com.airtel.money.util.Property;

public class MonitoringExecutionListener  implements JobExecutionListener 
{
	private BatchMonitoringNotifier monitoringNotifier;
	
	@Override
	public void beforeJob(JobExecution jobExecution) {
		monitoringNotifier.notify(jobExecution, Property.BATCH_BEFORE_JOB);
		
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		monitoringNotifier.notify(jobExecution, Property.BATCH_AFTER_JOB);
	}
	

	public BatchMonitoringNotifier getMonitoringNotifier() {
		return monitoringNotifier;
	}

	public void setMonitoringNotifier(BatchMonitoringNotifier monitoringNotifier) {
		this.monitoringNotifier = monitoringNotifier;
	}

	
	
}
