package com.airtel.money.tasklet;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.apache.camel.ProducerTemplate;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.InwardFileDataBean;
import com.airtel.money.dao.DbtMappingDao;

public class InwardStatusUpdateTasklet implements Tasklet 
{
	Logger LOGGER = Logger.getLogger(InwardStatusUpdateTasklet.class);
	private MessageSource messageSource;
	private DbtMappingDao dbtMappingDao;
	private InwardFileDataBean inwardFileDataBean;
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception 
	{	
		return RepeatStatus.FINISHED;
	
	}

	

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public DbtMappingDao getDbtMappingDao() {
		return dbtMappingDao;
	}

	public void setDbtMappingDao(DbtMappingDao dbtMappingDao) {
		this.dbtMappingDao = dbtMappingDao;
	}



	public InwardFileDataBean getInwardFileDataBean() {
		return inwardFileDataBean;
	}



	public void setInwardFileDataBean(InwardFileDataBean inwardFileDataBean) {
		this.inwardFileDataBean = inwardFileDataBean;
	}
	
}
