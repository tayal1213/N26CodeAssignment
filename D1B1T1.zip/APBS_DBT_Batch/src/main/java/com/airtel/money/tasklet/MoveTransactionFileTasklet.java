package com.airtel.money.tasklet;

import java.io.File;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.DbtMappingDetailsBean;
import com.airtel.money.bean.DbtTransactionDataBean;
import com.airtel.money.dao.DbtMappingDao;
import com.airtel.money.service.SmsService;
import com.airtel.money.util.Utility;

public class MoveTransactionFileTasklet  implements Tasklet{

	private DbtMappingDao dbtMappingDao;
	private MessageSource messageSource;
	private DbtTransactionDataBean dbtTransactionDataBean;
	Logger logger = Logger.getLogger(MoveTransactionFileTasklet.class);
	private SmsService smsService;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception 
	{
		logger.info("Inside MoveTransactionFileTasklet.execute()");
		try 
		{
			for(Long etlId: dbtTransactionDataBean.getMapFileEtlId().values())
			{
				dbtMappingDao.updateETLSummaryStatus(etlId);
			}
			
			
			String inputFileLocationDir = messageSource.getMessage("dbt.inward.input.file.locatiion", null, Locale.US);
			String archiveFileLocationDir = messageSource.getMessage("dbt.inward.archive.file.location", null, Locale.US);
			
			
			inputFileLocationDir = inputFileLocationDir.substring(0,inputFileLocationDir.lastIndexOf("/")+1);
			String[] extensions = messageSource.getMessage("dbt.inward.supporting.file.extension", null, Locale.US).split(",");
			File inputFile = new File(inputFileLocationDir);
			
			List<File> files = (List<File>) FileUtils.listFiles(inputFile, extensions, true);
			if(files!=null && files.size()>0)
			{
				Timestamp ts = new Timestamp(System.currentTimeMillis());
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH_mm_ss");
				File archiveFile = new File(archiveFileLocationDir+sdf.format(ts));
				archiveFile.mkdir();
				for(File file : files) 
				{
				    FileUtils.copyFileToDirectory(file, archiveFile);
				    file.delete();
				}
			}
			
			
		} 
		catch (Exception e) 
		{
			logger.error("Error occured in MoveTransactionFileTasklet: "+ e.getMessage());
		}
		// TODO Auto-generated method stub
		return RepeatStatus.FINISHED;
	}
	public MessageSource getMessageSource() {
		return messageSource;
	}
	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}
	public DbtMappingDao getDbtMappingDao() {
		return dbtMappingDao;
	}
	public void setDbtMappingDao(DbtMappingDao dbtMappingDao) {
		this.dbtMappingDao = dbtMappingDao;
	}
	public SmsService getSmsService() {
		return smsService;
	}
	public void setSmsService(SmsService smsService) {
		this.smsService = smsService;
	}
	public DbtTransactionDataBean getDbtTransactionDataBean() {
		return dbtTransactionDataBean;
	}
	public void setDbtTransactionDataBean(DbtTransactionDataBean dbtTransactionDataBean) {
		this.dbtTransactionDataBean = dbtTransactionDataBean;
	}
	
}
