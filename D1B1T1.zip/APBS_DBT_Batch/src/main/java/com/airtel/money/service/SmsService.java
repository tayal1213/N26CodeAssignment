package com.airtel.money.service;

import java.io.StringWriter;
import java.text.DecimalFormat;
import java.util.Locale;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.log4j.Logger;
import org.springframework.context.MessageSource;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class SmsService 
{
	Logger LOGGER = Logger.getLogger(SmsService.class);
	private MessageSource messageSource;
	public String sendSMS(String msisdn, String actualMessage) 
	{
		LOGGER.info("APBS Batch: Inside SmsService.sendSMS having msisdn: "+msisdn);
		try 
		{
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.newDocument();
			// root element
			Element rootElement = doc.createElement("message");
			doc.appendChild(rootElement);

			// sms type
			Element smstype = doc.createElement("sms");
			Attr attType = doc.createAttribute("type");
			attType.setValue("mt");
			smstype.setAttributeNode(attType);
			rootElement.appendChild(smstype);

			Element destination = doc.createElement("destination");
			smstype.appendChild(destination);
			Element address = doc.createElement("address");
			destination.appendChild(address);
			Element number = doc.createElement("number");
			Attr attrType = doc.createAttribute("type");
			attrType.setValue("international");
			number.setAttributeNode(attrType);
			number.appendChild(doc.createTextNode(msisdn));
			address.appendChild(number);

			Element source = doc.createElement("source");
			Element address1 = doc.createElement("address");
			Element alphanumeric = doc.createElement("alphanumeric");

			alphanumeric.appendChild(doc.createTextNode(messageSource.getMessage("sms.id", null, Locale.US)));
			address1.appendChild(alphanumeric);
			source.appendChild(address1);
			smstype.appendChild(source);

			Element rsr = doc.createElement("rsr");
			Attr attr = doc.createAttribute("type");
			attr.setValue("all");
			rsr.setAttributeNode(attr);
			smstype.appendChild(rsr);

			Element segmentation = doc.createElement("segmentation");
			smstype.appendChild(segmentation);

			Element ud = doc.createElement("ud");

			Attr attrType1 = doc.createAttribute("type");
			attrType1.setValue("text");
			Attr attrType2 = doc.createAttribute("encoding");
			attrType2.setValue("default");
			ud.setAttributeNode(attrType1);
			ud.setAttributeNode(attrType2);
			ud.appendChild(doc.createTextNode(actualMessage));
			smstype.appendChild(ud);

			// write the content into xml file
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource sor = new DOMSource(doc);

			StringWriter writer = new StringWriter();
			StreamResult result = new StreamResult(writer);
			transformer.transform(sor, result);
			String strResult = writer.toString();
			String returnString = sendPost(strResult);
			//smsReportStatus.setMessageContent(strResult);
			return returnString;

		} 
		catch (Exception e) 
		{
			LOGGER.warn("APBS Batch:  Exception occured: "+e.getMessage());
			return "FAILURE";
		}

	}
	
	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	String sendPost(String xml) throws Exception {

		String returnString;
		String xmlString = xml.toString();

		StringRequestEntity requestEntity = new StringRequestEntity(xmlString, "application/xml", "UTF-8");

		HttpClient client = new HttpClient();
		PostMethod method = new PostMethod(messageSource.getMessage("sms.url", null, Locale.US));
		// HttpPost post = new HttpPost(messageSource.getMessage("bw.sms.url",
		// null, Locale.US));
		// HttpEntity entity = new ByteArrayEntity(xmlString.getBytes("UTF-8"));
		method.setRequestEntity(requestEntity);

		method.addRequestHeader("Connection", "Keep-Alive");
		method.addRequestHeader("Method", "POST");
		method.addRequestHeader("User-Agent", "volt");
		method.addRequestHeader("Content-Type", "text/xml");
		method.addRequestHeader("Authorization", "Basic dm9sdDEyMzozMjF2b2x0");
		int response = client.executeMethod(method);

		// String result = EntityUtils.toString(response.getEntity());
       
		if (response == 200 || response == 202) {
			 LOGGER.info("Meesage sent is" +  xml );
			returnString = "SUCCESS";
			return returnString;
		} else {
			returnString = "FAILURE";
			return returnString;
		}

	}

	public String format(String value) {
		double d = Double.parseDouble(value);
		if (d < 1000) {
			return format("###", value);
		} else {
			double hundreds = d % 1000;
			double other = (double) (d / 1000);
			return format(",##", other) + ',' + format("000", hundreds);
		}
	}

	public String format(String pattern, Object value) {
		return new DecimalFormat(pattern).format(value);
	}
}
