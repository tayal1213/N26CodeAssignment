package com.airtel.money.app;

import java.io.File;

public  class Test {
	
	
	
	public static void print()
	{
		System.out.println("a");
	}
	
	private static void print(int x)
	{
		System.out.println("a");
	}
	
	public static class test2
	{
		
	}
	
		}
	

