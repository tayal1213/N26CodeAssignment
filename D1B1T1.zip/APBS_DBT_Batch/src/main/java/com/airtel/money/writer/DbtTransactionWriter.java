package com.airtel.money.writer;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.camel.ProducerTemplate;
import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.ETLTransaction;

/**
 * @author A1HSG0LG
 *
 */
public class DbtTransactionWriter implements ItemWriter<ETLTransaction> 
{
	Logger LOGGER = Logger.getLogger(DbtTransactionWriter.class);
	private ProducerTemplate producerTemplate = null;
	ItemWriter<ETLTransaction> delegate1;
	private MessageSource messageSource; 

	@Override
	public void write(List<? extends ETLTransaction> items) throws Exception 
	{
		LOGGER.info("APBS Batch: Inside DbtTransactionWriter.write()");
		try 
		{
			/*for(ETLTransaction etlTransaction:items)
			{
				Map<String, Object> request = new HashMap<String, Object>();
				
				request.put("ucId", etlTransaction.getUcId());
				request.put("fromActorParam1", etlTransaction.getFromActorParam1());
				request.put("fromActorParam2", etlTransaction.getFromActorParam2());
				request.put("fromActorParam3", etlTransaction.getFromActorParam3());
				request.put("fromActorParam4", etlTransaction.getFromActorParam4());
				request.put("toActorParam1", etlTransaction.getToActorParam1());
				request.put("toActorParam2", etlTransaction.getToActorParam2());
				request.put("fromActorId", etlTransaction.getFromActorId());
				
				request.put("toAccountMsisdn",etlTransaction.getToActorMsisdn());
				request.put("amount",etlTransaction.getAmount());
				request.put("partnerTxnId", etlTransaction.getPartnerTxnId().toString());
				producerTemplate.sendBody("activemq:queue:"+messageSource.getMessage("apbs.volt.insert.mq.name",null,Locale.US), request);
			}*/
			
			delegate1.write(items);
		} 
		catch (Exception e) 
		{
			LOGGER.warn("APBS Batch:  Exception occured: "+e.getMessage());
		}
		
		
	}

	public ItemWriter<ETLTransaction> getDelegate1() {
		return delegate1;
	}

	public void setDelegate1(ItemWriter<ETLTransaction> delegate1) {
		this.delegate1 = delegate1;
	}

	public ProducerTemplate getProducerTemplate() {
		return producerTemplate;
	}

	public void setProducerTemplate(ProducerTemplate producerTemplate) {
		this.producerTemplate = producerTemplate;
	}

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}
	

}
