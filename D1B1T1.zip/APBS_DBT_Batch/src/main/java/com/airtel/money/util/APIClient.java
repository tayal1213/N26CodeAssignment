package com.airtel.money.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
//import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.AadhaarVaultRequest;
import com.airtel.money.bean.AadhaarVaultResponse;
import com.google.gson.Gson;

public class APIClient {

	private MessageSource messageSource;

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	static final Logger log = Logger.getLogger(APIClient.class);

	public AadhaarVaultResponse invokeAPI(String url, String data) throws Exception {
		return invokeAPI(url, data, false);
	}

	public AadhaarVaultResponse invokeAPI(String url, String data, boolean useProxy) throws Exception {
		log.info("URL:" + url);
		log.info("Post Data :" + data);
		HttpURLConnection conn = null;
		if (useProxy && StringUtils.isNotBlank(messageSource.getMessage("proxy.ip", null, Locale.US))) {
			Proxy proxy = new Proxy(Proxy.Type.HTTP,
					new InetSocketAddress(messageSource.getMessage("proxy.ip", null, Locale.US),
							Integer.parseInt(messageSource.getMessage("proxy.port", null, Locale.US))));
			log.info("Proxy IP :" + messageSource.getMessage("proxy.ip", null, Locale.US));
			log.info("Proxy PORT :" + messageSource.getMessage("proxy.port", null, Locale.US));
			conn = (HttpURLConnection) new URL(url).openConnection(proxy);
		} else
			conn = (HttpURLConnection) new URL(url).openConnection();
		conn.setReadTimeout(Integer.parseInt(messageSource.getMessage("read.timeout", null, Locale.US)));
		conn.setConnectTimeout(Integer.parseInt(messageSource.getMessage("read.timeout", null, Locale.US)));
	//	conn.setReadTimeout(30000);
	//	conn.setConnectTimeout(30000);
		conn.setRequestProperty("Content-Type", "application/json");
		conn.setRequestProperty("Accept", "application/json");
		conn.setRequestProperty("Message_Signature", CipherUtil.encryptData(String.valueOf(data.hashCode())));

		if (data != null) {
			conn.setRequestMethod("POST");
			conn.setDoInput(true);
			conn.setDoOutput(true);
			OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
			wr.write(data);
			wr.close();
		}
		BufferedReader rd = null;
		if (conn.getResponseCode() == 200)
			rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		else
			rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
		String output;
		StringBuffer totalOutput = new StringBuffer();
		while ((output = rd.readLine()) != null) {
			totalOutput.append(output);
		}
		rd.close();
		conn.disconnect();
		log.info("Response status: " + conn.getResponseCode());
		String response = totalOutput.toString();
		log.info("Response:" + response);

		// String encryptedHeader = conn.getHeaderField("Message_Signature");

		// String decryptedHeader = CipherUtil.decryptData(encryptedHeader);

		// System.out.println(decryptedHeader + "----" + response.hashCode());

		Gson gson = new Gson();
		AadhaarVaultResponse resp = gson.fromJson(response, AadhaarVaultResponse.class);

	//	System.out.println(resp.getReferenceKey());
		return resp;
	}

}
