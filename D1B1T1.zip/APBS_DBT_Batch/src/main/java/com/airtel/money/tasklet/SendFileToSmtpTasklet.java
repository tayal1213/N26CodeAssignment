package com.airtel.money.tasklet;

import java.io.File;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.MessageSource;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.integration.support.MessageBuilder;

import com.airtel.money.bean.DbtMappingDataBean;
import com.airtel.money.bean.InwardFileDataBean;

public class SendFileToSmtpTasklet implements Tasklet {

	Logger LOGGER = Logger.getLogger(SendFileToSmtpTasklet.class);
	private MessageChannel sftpChannel;
	private MessageSource messageSource;
	private DbtMappingDataBean dbtMappingDataBean;
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception 
	{
		LOGGER.info("Inward return file batch completed successfully");
		File file = new File(messageSource.getMessage("dbt.mapping.data.file.output.location", null, Locale.US)+dbtMappingDataBean.getFileName());
		 
        if (file.exists()) 
        {
             Message message = MessageBuilder.withPayload(file).build();
            try 
            {
                sftpChannel.send(message);
            } 
            catch (Exception e) {
                System.out.println("Could not send file per SFTP: " + e);
            }
        }
        else 
        {
            System.out.println("File does not exist.");
        }
		return RepeatStatus.FINISHED;
	}
	public MessageChannel getSftpChannel() {
		return sftpChannel;
	}
	public void setSftpChannel(MessageChannel sftpChannel) {
		this.sftpChannel = sftpChannel;
	}
	public MessageSource getMessageSource() {
		return messageSource;
	}
	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}
	public DbtMappingDataBean getDbtMappingDataBean() {
		return dbtMappingDataBean;
	}
	public void setDbtMappingDataBean(DbtMappingDataBean dbtMappingDataBean) {
		this.dbtMappingDataBean = dbtMappingDataBean;
	}
	
}
