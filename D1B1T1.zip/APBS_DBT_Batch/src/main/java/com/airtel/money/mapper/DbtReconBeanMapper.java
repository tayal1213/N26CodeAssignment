package com.airtel.money.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.airtel.money.bean.DbtReconBean;

public class DbtReconBeanMapper implements RowMapper<DbtReconBean> 
{
	@Override
	public DbtReconBean mapRow(ResultSet rs, int arg1) throws SQLException 
	{
		DbtReconBean dbtReconBean = new DbtReconBean();
		dbtReconBean.setPartnerTxnId(rs.getString("PARTNER_TXN_ID"));
		dbtReconBean.setStatus(rs.getString("STATUS"));
		return dbtReconBean;
	}
}
