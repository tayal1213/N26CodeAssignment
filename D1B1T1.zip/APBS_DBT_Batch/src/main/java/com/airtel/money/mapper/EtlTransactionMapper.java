package com.airtel.money.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;

import org.springframework.jdbc.core.RowMapper;

import com.airtel.money.bean.ETLTransaction;

public class EtlTransactionMapper implements RowMapper<ETLTransaction> 
{

	@Override
	public ETLTransaction mapRow(ResultSet rs, int arg1) throws SQLException 
	{
		DecimalFormat df2 = new DecimalFormat("#.##");
		ETLTransaction etlTransaction = new ETLTransaction();
		etlTransaction.setId(rs.getLong("ID"));
		etlTransaction.setUcId(rs.getString("uc_id"));
		etlTransaction.setFromActorParam1(rs.getString("from_actor_param1"));
		etlTransaction.setFromActorParam2(rs.getString("from_actor_param2"));
		etlTransaction.setFromActorParam3(rs.getString("from_actor_param3"));
		etlTransaction.setFromActorParam4(rs.getString("from_actor_param4"));
		etlTransaction.setToActorParam1(rs.getString("to_actor_param1"));
		etlTransaction.setToActorParam2(rs.getString("to_actor_param2"));
		etlTransaction.setFromActorId(rs.getLong("from_actor_id"));
		
		etlTransaction.setToActorMsisdn(rs.getLong("to_actor_msisdn"));
		etlTransaction.setAmount(Double.valueOf(df2.format(rs.getDouble("amount"))));
		etlTransaction.setPartnerTxnId(rs.getLong("partner_txn_id"));

		return etlTransaction;
	}

}
