package com.airtel.money.tasklet;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.MessageSource;



import com.airtel.money.bean.ApbsErrorLogBean;
import com.airtel.money.bean.DbtMappingDataBean;
import com.airtel.money.dao.DbtMappingDao;

public class DbtMappingTasklet implements Tasklet 
{
	Logger LOGGER = Logger.getLogger(DbtMappingTasklet.class);
	private DbtMappingDao dbtMappingDao;
	private DbtMappingDataBean dbtMappingDataBean;
	private MessageSource messageSource;
	

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception 
	{
		/*Header Identifier	2
		Uploading Bank IIN	9
		User Name	30
		Date of Input	8
		Input file number	5
		Total number of records	5
		Filler	301*/
		StringBuffer sb = new StringBuffer("");
		LOGGER.info("APBS Batch:  Inside DbtMappingTasklet.execute()");
		try 
		{
			Integer rowCount = dbtMappingDao.getDbtMappingCount();
			if(rowCount!=null && rowCount>0)
			{
				dbtMappingDataBean.setRowCount(rowCount);
			}
			else
			{
				throw new Exception("No record found for aadhaar seeding");
			}
			String fileNameStartWith = messageSource.getMessage("dbt.mapping.data.file.start.with", null, Locale.US);
			String bankCode = messageSource.getMessage("dbt.mapping.bank.code", null, Locale.US);
			String wordSeparator = messageSource.getMessage("dbt.mapping.word.separator", null, Locale.US);
			String fileEndWith = messageSource.getMessage("dbt.mapping.file.end.with", null, Locale.US);
			
			Date date = new Date();
			Calendar cal = Calendar.getInstance();
		    cal.setTime(date);
		    int year = cal.get(Calendar.YEAR);
		    int month = cal.get(Calendar.MONTH)+1;
		    int day = cal.get(Calendar.DAY_OF_MONTH);
		    String dateStr = (day > 9?""+day:"0"+day)+(month>9?""+month:"0"+month)+year;
		    
			
			int headerIdentifierLength = 2;
			int uploadingBankIINLength = 9;
			int userNameLength = 30;
			int dateOfInputLength = 8;
			int inputFileNumberLengthFile = 6;
			int inputFileNumberLengthHeader = 5;
			int totalNoOfRecordsLength = 5;
			int fillerLength = 301;
			
			String headerIdentifier = messageSource.getMessage("aadhar.seeding.file.header.identifier", null, Locale.US);
			String uploadingBankIIN =  messageSource.getMessage("aadhar.seeding.file.header.iin", null, Locale.US);
			String userName = messageSource.getMessage("aadhar.seeding.file.header.user.name", null, Locale.US);
			String dateOfInput = dateStr;
			String inputFileNumber = dbtMappingDao.getAadharSeedingSeq().toString(); 
			String totalNoOfRecords = ""+dbtMappingDataBean.getRowCount();
			
			
			String inputFileNumberRecordsStr = "";
			
			for(int i = 0; i<inputFileNumberLengthFile-inputFileNumber.length(); i++)
		    {
				inputFileNumberRecordsStr = inputFileNumberRecordsStr+"0";
		    }
			inputFileNumberRecordsStr=inputFileNumberRecordsStr+inputFileNumber;
			dbtMappingDataBean.setFileName(fileNameStartWith+wordSeparator+bankCode+wordSeparator+dateStr+wordSeparator+inputFileNumberRecordsStr+wordSeparator+fileEndWith);

					    
		    
		    
		    for(int i = 0; i<headerIdentifierLength-headerIdentifier.length(); i++)
		    {
		    	sb.append("0");
		    }
		    sb.append(headerIdentifier);
		    
		    for(int i = 0; i<uploadingBankIINLength-uploadingBankIIN.length(); i++)
		    {
		    	sb.append("0");
		    }
		    sb.append(uploadingBankIIN);
		    
		    sb.append(userName);
		    for(int i = 0; i<userNameLength-userName.length(); i++)
		    {
		    	sb.append(" ");
		    }
		    
		    
		    for(int i = 0; i<dateOfInputLength-dateOfInput.length(); i++)
		    {
		    	sb.append("0");
		    }
		    sb.append(dateOfInput);
		    
		    for(int i = 0; i<inputFileNumberLengthHeader-inputFileNumber.length(); i++)
		    {
		    	sb.append("0");
		    }
		    sb.append(inputFileNumber);
		    
		    for(int i = 0; i<totalNoOfRecordsLength-totalNoOfRecords.length(); i++)
		    {
		    	sb.append("0");
		    }
		    sb.append(totalNoOfRecords);
		    for(int i = 0; i<fillerLength; i++)
		    {
		    	sb.append(" ");
		    }
		    
		    dbtMappingDataBean.setHeader(sb.toString());
			
		} 
		catch (Exception e) 
		{
			LOGGER.warn("APBS Batch:  Exception occured: "+e.getMessage());
			ApbsErrorLogBean apbsErrorLogBean = new ApbsErrorLogBean();
			apbsErrorLogBean.setBatchName("aadhar-seeding-job");
			apbsErrorLogBean.setErrorMsg(e.getMessage());
			apbsErrorLogBean.setInputData(sb.toString());
			dbtMappingDao.insertApbsErrorLog(apbsErrorLogBean);
			throw new java.lang.Exception(e.getMessage());
		}
		
		return RepeatStatus.FINISHED;
	}

	public DbtMappingDao getDbtMappingDao() {
		return dbtMappingDao;
	}

	public void setDbtMappingDao(DbtMappingDao dbtMappingDao) {
		this.dbtMappingDao = dbtMappingDao;
	}

	public DbtMappingDataBean getDbtMappingDataBean() {
		return dbtMappingDataBean;
	}

	public void setDbtMappingDataBean(DbtMappingDataBean dbtMappingDataBean) {
		this.dbtMappingDataBean = dbtMappingDataBean;
	}
	

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}
	

}
