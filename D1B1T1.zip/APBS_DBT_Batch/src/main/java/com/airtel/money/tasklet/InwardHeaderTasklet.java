package com.airtel.money.tasklet;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.apache.camel.ProducerTemplate;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.ApbsErrorLogBean;
import com.airtel.money.bean.InwardFileDataBean;
import com.airtel.money.dao.DbtMappingDao;

public class InwardHeaderTasklet implements Tasklet 
{
	Logger LOGGER = Logger.getLogger(InwardHeaderTasklet.class);
	private MessageSource messageSource;
	private DbtMappingDao dbtMappingDao;
	private InwardFileDataBean inwardFileDataBean;
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception 
	{

		LOGGER.info("APBS Batch:  Inside InwardHeaderTasklet.execute()");
		/*Header Identifier	2
		Uploading Bank IIN	9
		User Name	30
		Date of Input	8
		Input file number	5
		Total number of records	5
		Filler	301*/
		StringBuffer sb = new StringBuffer("");
		try 
		{
			inwardFileDataBean.setRowCount(dbtMappingDao.getInwardMappingCount(inwardFileDataBean.getLstEtlSummary().get(inwardFileDataBean.getCurCount()).getId()));
			String fileNameStartWith = messageSource.getMessage("inward.mapping.data.file.start.with", null, Locale.US);
			String bankCode = messageSource.getMessage("inward.mapping.bank.code", null, Locale.US);
			String wordSeparator = messageSource.getMessage("inward.mapping.word.separator", null, Locale.US);
			String fileEndWith = messageSource.getMessage("inward.mapping.file.end.with", null, Locale.US);
			String seqStartWith = messageSource.getMessage("inward.seq.start.with",null, Locale.US);
			
			Date date = new Date();
			Calendar cal = Calendar.getInstance();
		    cal.setTime(date);
		    int year = cal.get(Calendar.YEAR);
		    int month = cal.get(Calendar.MONTH)+1;
		    int day = cal.get(Calendar.DAY_OF_MONTH);
		    String dateStr = (day > 9?""+day:"0"+day)+(month>9?""+month:"0"+month)+year;
		    
			
		    int controlCharLength=7;
		    int filterLength1=87;
		    int controlCharLengthBankIIN=7;
		    int filterLength2=43;
		    
			
			int inputFileNumberLengthFile = 6;
			int totalNoOfRecordsLength = 9;
			int totalAmtLenth = 13;
			
			String abpsTransactionCode = messageSource.getMessage("inward.apbs.transaction.code",null, Locale.US);
			String bankIIN = messageSource.getMessage("inward.control.character.bank.iin",null, Locale.US);
			
			String inputFileNumber = dbtMappingDao.getInwardHeaderSeq().toString(); 
			String totalNoOfRecords = ""+inwardFileDataBean.getRowCount();
			
			
			String inputFileNumberRecordsStr = "";

			
			
			
			
			
			
			
			


			
			for(int i = 0; i<inputFileNumberLengthFile-inputFileNumber.length(); i++)
		    {
				inputFileNumberRecordsStr = inputFileNumberRecordsStr+"0";
		    }
			inputFileNumberRecordsStr=inputFileNumberRecordsStr+inputFileNumber;
			inwardFileDataBean.setFileName(fileNameStartWith+wordSeparator+bankCode+wordSeparator+dateStr+wordSeparator+seqStartWith+inputFileNumberRecordsStr+wordSeparator+fileEndWith);

					    
		    
		    
		    // 1	APBS Transaction Code		2
		    sb.append(abpsTransactionCode);
		    
		    // 2	Control Character			7		    
		    for(int i = 0; i<controlCharLength; i++)
		    {
		    	sb.append("0");
		    }
		    
		    // 3	Filler						87
		    for(int i = 0; i<filterLength1; i++)
		    {
		    	sb.append(" ");
		    }
		    
		    // 4	Control Character Bank IIN	7
		    for(int i = 0; i<controlCharLengthBankIIN-bankIIN.length(); i++)
		    {
		    	sb.append("0");
		    }
		    sb.append(bankIIN);
		    
		    // 5	Total number of items		9
		    for(int i = 0; i<totalNoOfRecordsLength-totalNoOfRecords.length(); i++)
		    {
		    	sb.append("0");
		    }
		    sb.append(totalNoOfRecords);
		    
		    // 6	Total amount				13
		    String totalAmt = ""+ dbtMappingDao.getTotalAmt(inwardFileDataBean.getLstEtlSummary().get(inwardFileDataBean.getCurCount()).getId());	
		    totalAmt= ""+(Long.valueOf(totalAmt));
		    for(int i = 0; i<totalAmtLenth-totalAmt.length(); i++)
		    {
		    	sb.append("0");
		    }
		    sb.append(totalAmt);
		    
		    // 7	Settlement date (DDMMYYYY)	8
		    sb.append(dateStr);
		    
		    // 8	Filler						44		    
		    for(int i = 0; i<filterLength2; i++)
		    {
		    	sb.append(" ");
		    }
		    sb.append(".");
		    
		    inwardFileDataBean.setHeader(sb.toString());
			
		} 
		catch (Exception e) 
		{
			ApbsErrorLogBean apbsErrorLogBean = new ApbsErrorLogBean();
			apbsErrorLogBean.setBatchName("inward-file-job");
			apbsErrorLogBean.setErrorMsg(e.getMessage());
			apbsErrorLogBean.setInputData(sb.toString());
			dbtMappingDao.insertApbsErrorLog(apbsErrorLogBean);
			LOGGER.warn("APBS Batch:  Exception occured: "+e.getMessage());
			throw new Exception(e.getMessage());
		}
		
		return RepeatStatus.FINISHED;
	
	}

	

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public DbtMappingDao getDbtMappingDao() {
		return dbtMappingDao;
	}

	public void setDbtMappingDao(DbtMappingDao dbtMappingDao) {
		this.dbtMappingDao = dbtMappingDao;
	}



	public InwardFileDataBean getInwardFileDataBean() {
		return inwardFileDataBean;
	}



	public void setInwardFileDataBean(InwardFileDataBean inwardFileDataBean) {
		this.inwardFileDataBean = inwardFileDataBean;
	}
	
}
