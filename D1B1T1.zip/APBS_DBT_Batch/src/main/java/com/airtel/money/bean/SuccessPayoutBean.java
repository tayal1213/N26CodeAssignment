package com.airtel.money.bean;

public class SuccessPayoutBean {

	private int id;
	private String custMsisdn;
	private String retMsisdn;
	private String retadd1;
	private String retAdd2;
	private String retAdd3;
	private String retcity;
	private String shopName;
	private String messaeStatusRetailerInfo;
	private String messaeStatusAmount;
	private String amount;

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	
	public String getMessaeStatusRetailerInfo() {
		return messaeStatusRetailerInfo;
	}

	public void setMessaeStatusRetailerInfo(String messaeStatusRetailerInfo) {
		this.messaeStatusRetailerInfo = messaeStatusRetailerInfo;
	}

	public String getMessaeStatusAmount() {
		return messaeStatusAmount;
	}

	public void setMessaeStatusAmount(String messaeStatusAmount) {
		this.messaeStatusAmount = messaeStatusAmount;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCustMsisdn() {
		return custMsisdn;
	}

	public void setCustMsisdn(String custMsisdn) {
		this.custMsisdn = custMsisdn;
	}

	public String getRetMsisdn() {
		return retMsisdn;
	}

	public void setRetMsisdn(String retMsisdn) {
		this.retMsisdn = retMsisdn;
	}

	public String getRetadd1() {
		return retadd1;
	}

	public void setRetadd1(String retadd1) {
		this.retadd1 = retadd1;
	}

	public String getRetAdd2() {
		return retAdd2;
	}

	public void setRetAdd2(String retAdd2) {
		this.retAdd2 = retAdd2;
	}

	public String getRetAdd3() {
		return retAdd3;
	}

	public void setRetAdd3(String retAdd3) {
		this.retAdd3 = retAdd3;
	}

	public String getRetcity() {
		return retcity;
	}

	public void setRetcity(String retcity) {
		this.retcity = retcity;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

}