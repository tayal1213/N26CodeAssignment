package com.airtel.money.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.airtel.money.bean.AadharSeedingResponseXmlBean;
import com.airtel.money.processor.ResponseProfilingProcessor;

public class XmlBeanHandler extends DefaultHandler {

	
	Logger LOGGER = Logger.getLogger(ResponseProfilingProcessor.class);
	
	String tagName;
	
	String sbTemp = null;
	StringBuffer sbAadhaar = null;
	StringBuffer sbMappedIin = null;
	StringBuffer sbScheme = null;
	StringBuffer sbMandateCustDate = null;
	StringBuffer sbMappingStatus = null;
	StringBuffer sbUidReasonCode = null;
	StringBuffer sbUidResult = null;
	StringBuffer sbAccepted = null;
	AadharSeedingResponseXmlBean aadharSeedingResponseXmlBean = null;
	List<AadharSeedingResponseXmlBean> lstasrBean = null;
	public List<AadharSeedingResponseXmlBean> getLstasrBean()
	{
		return lstasrBean;
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException 
	{
		tagName = qName;
		if (qName.equalsIgnoreCase("Record")) 
		{
			aadharSeedingResponseXmlBean = new AadharSeedingResponseXmlBean();
			if(lstasrBean==null)
			{
				lstasrBean = new ArrayList<AadharSeedingResponseXmlBean>();
			}
		}	
		
		else if (qName.equalsIgnoreCase("AADHAAR_NO")) 
		{
			sbAadhaar = new StringBuffer();
		}
		else if (qName.equalsIgnoreCase("MAPPED_IIN")) 
		{
			sbMappedIin = new StringBuffer();
		}
		else if (qName.equalsIgnoreCase("SCHEME")) 
		{
			sbScheme = new StringBuffer();
		}
		else if (qName.equalsIgnoreCase("MANDATE_CUST_DATE")) 
		{
			sbMandateCustDate = new StringBuffer();
		}
		else if (qName.equalsIgnoreCase("MAPPING_STATUS")) 
		{
			sbMappingStatus = new StringBuffer();
		}
		else if (qName.equalsIgnoreCase("UID_REASON_CODE")) 
		{
			sbUidReasonCode = new StringBuffer();
		}
		else if (qName.equalsIgnoreCase("UID_RESULT")) 
		{
			sbUidResult = new StringBuffer();
		}
		else if (qName.equalsIgnoreCase("ACCEPTED")) 
		{
			sbAccepted = new StringBuffer();
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		
		if (qName.equalsIgnoreCase("Record")) 
		{
			aadharSeedingResponseXmlBean.setAadharNo(sbAadhaar.toString());
			aadharSeedingResponseXmlBean.setMappedIin(sbMappedIin.toString());
			aadharSeedingResponseXmlBean.setScheme(sbScheme.toString());
			aadharSeedingResponseXmlBean.setMandateCustDate(sbMandateCustDate.toString());
			aadharSeedingResponseXmlBean.setMappingStatus(sbMappingStatus.toString());
			aadharSeedingResponseXmlBean.setUidReasonCode(sbUidReasonCode.toString());
			aadharSeedingResponseXmlBean.setUidResult(sbUidResult.toString());
			aadharSeedingResponseXmlBean.setAccepted(sbAccepted.toString());
			lstasrBean.add(aadharSeedingResponseXmlBean);
		}
	}

	@Override
	public void characters(char ch[], int start, int length) 	throws SAXException 
	{
		sbTemp  = new String(ch, start, length);
		if(tagName.equals("AADHAAR_NO"))
		{
			sbAadhaar.append(sbTemp.toString());
		}		
		else if (tagName.equalsIgnoreCase("MAPPED_IIN")) 
		{
			sbMappedIin.append(sbTemp.toString());
		}
		else if (tagName.equalsIgnoreCase("SCHEME")) 
		{
			sbScheme.append(sbTemp.toString());
		}
		else if (tagName.equalsIgnoreCase("MANDATE_CUST_DATE")) 
		{
			sbMandateCustDate.append(sbTemp.toString());
		}
		else if (tagName.equalsIgnoreCase("MAPPING_STATUS")) 
		{
			sbMappingStatus.append(sbTemp.toString());
		}
		else if (tagName.equalsIgnoreCase("UID_REASON_CODE")) 
		{
			sbUidReasonCode.append(sbTemp.toString());
		}
		else if (tagName.equalsIgnoreCase("UID_RESULT")) 
		{
			sbUidResult.append(sbTemp.toString());
		}
		else if (tagName.equalsIgnoreCase("ACCEPTED")) 
		{
			sbAccepted.append(sbTemp.toString());
		}
	}
}