package com.airtel.money.bean;

import java.util.HashMap;

public class GlobalBean {

	private HashMap<String, String> map;

	public HashMap<String, String> getMap() {
		return map;
	}

	public void setMap(HashMap<String, String> map) {
		this.map = map;
	}

}
