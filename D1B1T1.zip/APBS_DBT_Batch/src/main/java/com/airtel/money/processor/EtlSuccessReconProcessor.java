package com.airtel.money.processor;

import java.sql.Timestamp;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.DbtReconBean;
import com.airtel.money.bean.TrmtReconData;
import com.airtel.money.dao.DbtMappingDao;

public class EtlSuccessReconProcessor implements ItemProcessor<DbtReconBean, DbtReconBean> 
{
	Logger LOGGER = Logger.getLogger(EtlSuccessReconProcessor.class);
	private MessageSource messageSource;
	private DbtMappingDao dbtMappingDao;
	@Override
	public DbtReconBean process(DbtReconBean dbtReconBean) throws Exception 
	{
		LOGGER.info("APBS Batch: Record being processing for DbtReconBean: "+dbtReconBean);
		try 
		{
			TrmtReconData trmtReconData = dbtMappingDao.getTrmtReconData(dbtReconBean.getPartnerTxnId());
			if(trmtReconData!=null && trmtReconData.getTxnStatus().equalsIgnoreCase("SUCCESS"))
			{
				dbtReconBean.setStatus("0");
				dbtReconBean.setReconStatus("SUCCESS");
				dbtReconBean.setReconTimestamp(new Timestamp(System.currentTimeMillis()));
				dbtReconBean.setCoreTxnId(trmtReconData.getCoreTxnId());
			}
			else
			{
				return null;
			}
		} 
		catch (Exception e) 
		{
			LOGGER.warn("APBS Batch:  Exception occured: "+e);
			return null;
		}
				
		return dbtReconBean;
	}
	
	public MessageSource getMessageSource() {
		return messageSource;
	}
	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public DbtMappingDao getDbtMappingDao() {
		return dbtMappingDao;
	}

	public void setDbtMappingDao(DbtMappingDao dbtMappingDao) {
		this.dbtMappingDao = dbtMappingDao;
	}
	
}
