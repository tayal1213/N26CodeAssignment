package com.airtel.money.reader;

import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamException;

import com.airtel.money.bean.AadharSeedingResponseXmlBean;

public class DbtXmlSyncItemReader  implements ItemReader<AadharSeedingResponseXmlBean>, ItemStream {

	private ItemReader<AadharSeedingResponseXmlBean> delegate;

	public ItemReader<AadharSeedingResponseXmlBean> getDelegate() {
		return delegate;
	}

	public void setDelegate(ItemReader<AadharSeedingResponseXmlBean> delegate) {
		this.delegate = delegate;
	}

	public synchronized AadharSeedingResponseXmlBean read() throws Exception {
		return delegate.read();
	}

	public void close() throws ItemStreamException {
		if (this.delegate instanceof ItemStream) {
			((ItemStream) this.delegate).close();
		}
	}

	@Override
	public void open(ExecutionContext context) throws ItemStreamException {
		if (this.delegate instanceof ItemStream) {
			((ItemStream)this.delegate).open(context);
		}
		
	}

	@Override
	public void update(ExecutionContext context) throws ItemStreamException {
		// TODO Auto-generated method stub
		if (this.delegate instanceof ItemStream) {
			((ItemStream)this.delegate).update(context);
		}
	}


}
