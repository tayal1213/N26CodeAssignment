export JAVA_HOME=/usr/java/jdk1.8.0_71
export PATH=$JAVA_HOME/bin:$PATH

nohup java -Dlog4j.configuration=file:///home/testuser/APBS_DBT/log4j.properties -jar APBS_DBT_Batch-0.1.jar  &