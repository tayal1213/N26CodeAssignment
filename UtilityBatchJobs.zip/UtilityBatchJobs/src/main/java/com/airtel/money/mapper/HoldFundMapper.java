package com.airtel.money.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.airtel.money.bean.HoldFund;

public class HoldFundMapper implements RowMapper<HoldFund> {

	@Override
	public HoldFund mapRow(ResultSet rs, int arg1) throws SQLException {

		HoldFund holdFund = new HoldFund();
		
		holdFund.setAADHAAR_ID(rs.getString("AADHAAR_ID"));
		holdFund.setCUST_MSISDN(rs.getString("CUST_MSISDN"));
		holdFund.setHOLD_NUMBER(rs.getString("HOLD_NUMBER"));
		holdFund.setVOLT_TRANSACTION_ID(rs.getString("VOLT_TRANSACTION_ID"));
		
		return holdFund;
	}

}