package com.airtel.money.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.airtel.money.bean.CustomerMasterData;

public class OlaMapper implements RowMapper<CustomerMasterData> {
	Logger LOGGER = Logger.getLogger(OlaMapper.class);

	@Override
	public CustomerMasterData mapRow(ResultSet rs, int rowNum) throws SQLException {
		CustomerMasterData data = new CustomerMasterData();
		try {
			data.setCustmsisdn(rs.getString("CUST_MSISDN"));
			data.setCustfname(rs.getString("CUST_FNAME"));
			data.setCustmname(rs.getString("CUST_MNAME"));
			data.setCustlname(rs.getString("CUST_LNAME"));
			data.setCustdob(rs.getString("CUST_DOB"));
			data.setGender(rs.getString("GENDER"));
			data.setAadhaarid(rs.getString("AADHAAR_ID"));
			data.setFatherorhusbandname(rs.getString("FATHER_OR_HUSBAND_NAME"));
			data.setMothermaidenname(rs.getString("MOTHER_MAIDEN_NAME"));
			if(rs.getString("LOCAL_ADDRESS1")!=null)
			data.setLocaladdress1(rs.getString("LOCAL_ADDRESS1").replace(","," "));
			if(rs.getString("LOCAL_ADDRESS2")!=null)
			data.setLocaladdress2(rs.getString("LOCAL_ADDRESS2").replace(","," "));
			if(rs.getString("LOCAL_ADDRESS3")!=null)
			data.setLocaladdress3(rs.getString("LOCAL_ADDRESS3").replace(","," "));
			if(rs.getString("LOCAL_ADDRESS4")!=null)
			data.setLocaladdress4(rs.getString("LOCAL_ADDRESS4").replace(","," "));
			data.setLocalcity(rs.getString("LOCAL_CITY"));
			data.setLocaldistrict(rs.getString("LOCAL_DISTRICT"));
			data.setLocalpostalcode(rs.getString("LOCAL_POSTAL_CODE"));
			data.setLocalstate(rs.getString("LOCAL_STATE"));
			if(rs.getString("CUSTHOUSE")!=null)
			data.setCusthouse(rs.getString("CUSTHOUSE").replace(","," "));
			if(rs.getString("CUSTSTREET")!=null)
			data.setCuststreet(rs.getString("CUSTSTREET").replace(","," "));
			if(rs.getString("CUSTLANDMARK")!=null)
			data.setCustlandmark(rs.getString("CUSTLANDMARK").replace(","," "));
			if(rs.getString("CUSTLOCALITY")!=null)
			data.setCustlocality(rs.getString("CUSTLOCALITY").replace(","," "));
			data.setCustvtc(rs.getString("CUSTVTC"));
			data.setCustdistrict(rs.getString("CUSTDISTRICT"));
			data.setCuststate(rs.getString("CUSTSTATE"));
			data.setCustpincode(rs.getString("CUSTPINCODE"));
			data.setOlacodeordl(rs.getString("OLA_CODE_OR_DL"));

		} catch (Exception e) {
			LOGGER.error("OLA Batch:  Exception occured: " + e.getMessage());
			return null;
		}

		return data;
	}
	

}
