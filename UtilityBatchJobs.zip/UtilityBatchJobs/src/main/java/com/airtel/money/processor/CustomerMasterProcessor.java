package com.airtel.money.processor;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.context.MessageSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.airtel.money.bean.BatchStatus;
import com.airtel.money.bean.CustDataCBS;

import freemarker.template.Configuration;
import freemarker.template.Template;

public class CustomerMasterProcessor implements ItemProcessor<CustDataCBS, CustDataCBS> {
	private MessageSource messageSource;
	private BatchStatus batchStatus;

	public CustomerMasterProcessor() {
	}

	public BatchStatus getBatchStatus() {
		return batchStatus;
	}

	public void setBatchStatus(BatchStatus batchStatus) {
		this.batchStatus = batchStatus;
	}

	Logger logger = Logger.getLogger(CustomerMasterProcessor.class);

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public CustDataCBS process(CustDataCBS custDetails) throws Exception {
		String blackListedCircles = messageSource.getMessage("blacklisted.circles", null, Locale.US);
		if ((custDetails.getState() != null) && (custDetails.getCategory() != null)
				&& (blackListedCircles.contains(custDetails.getState().toUpperCase()))) {

			logger.info("Inside CustomerMasterProcessor.process(), Updating Cat  for: " + custDetails.getMsisdn() + ","
					+ custDetails.getCategory() + "," + custDetails.getState());

			callUpdateApi(custDetails);

			custDetails.setCreatedTs(new Timestamp(System.currentTimeMillis()));
			custDetails.setModifiedTs(new Timestamp(System.currentTimeMillis()));
		} else {

			String eligibleCircles = messageSource.getMessage("eligible.circles", null, Locale.US);
			if ((custDetails.getState() != null) && (eligibleCircles.contains(custDetails.getState().toUpperCase()))) {
				logger.info("Inside CustomerMasterCircleProcessor.process(), Fetching Actor for circle: "
						+ custDetails.getMsisdn() + "," + custDetails.getCategory() + "," + custDetails.getState());
				custDetails.setBatchIdentifier("circleBatch");
				return custDetails;
			}
			logger.info("Data not matching the Circle or Category Condition" + custDetails.getCircle() + ","
					+ custDetails.getCategory());

			return null;
		}
		custDetails.setBatchId(batchStatus.getBatchId());
		custDetails.setBatchIdentifier("updateBatch");
		return custDetails;
	}

	public void callUpdateApi(CustDataCBS custDetails) {
		logger.info("Calling WS to update Profile ");
		Configuration cfg = new Configuration();
		try {

			String ftlname = "update_profile.ftl";
			String wsUrl = messageSource.getMessage("update.call.ws.url", null, Locale.US);
			cfg.setDirectoryForTemplateLoading(new File("templates"));
			// cfg.setClassForTemplateLoading(getClass(), "/");
			Template template = cfg.getTemplate(ftlname);
			custDetails.setExtRefNum(UUID.randomUUID().toString().replaceAll("-", ""));
			Map<String, Object> data = new HashMap();
			data.put("bean", custDetails);
			Writer out = new StringWriter();
			template.process(data, out);
			String transformedTemplate = out.toString();
			out.flush();

			URL obj = new URL(wsUrl);
			HttpURLConnection connection = (HttpURLConnection) obj.openConnection();

			connection.setRequestMethod("POST");
			connection.setRequestProperty("User-Agent", "Jakarta Commons-HttpClient/3.1");
			connection.setRequestProperty("SOAPAction", "cspNationalIdentificationCode");
			connection.setRequestProperty("APIVERSION", "1.0");

			connection.setRequestProperty("Content-Type", "text/xml; charset=utf-8");

			connection.setDoOutput(true);
			connection.setInstanceFollowRedirects(false);
			connection.setRequestMethod("POST");
			connection.setConnectTimeout(
					Integer.parseInt(messageSource.getMessage("api.call.conn.timeout", null, Locale.US)));

			connection.setReadTimeout(
					Integer.parseInt(messageSource.getMessage("api.call.read.timeout", null, Locale.US)));

			connection.setRequestProperty("Content-Type", "application/xml");

			OutputStream os = connection.getOutputStream();

			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer transformer = tf.newTransformer();
			transformer.setOutputProperty("omit-xml-declaration", "yes");

			StreamSource source = new StreamSource(new StringReader(transformedTemplate));
			StreamResult result = new StreamResult(os);
			transformer.transform(source, result);

			logger.info("Request Message :" + result.getOutputStream().toString());

			os.flush();
			connection.getResponseCode();

			int responseCode = connection.getResponseCode();
			logger.info("response code from server is :" + responseCode);

			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));

			StringBuffer response = new StringBuffer();
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			connection.disconnect();

			logger.info("Response from AMP  :" + response.toString());

			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(new InputSource(new StringReader(response.toString())));
			doc.getDocumentElement().normalize();

			NodeList nList = doc.getElementsByTagName("Response");

			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == 1) {
					Element eElement = (Element) nNode;
                    
					custDetails.setResponseCode(eElement.getElementsByTagName("ReplyCode").item(0).getTextContent());
					if(eElement.getElementsByTagName("ReplyCode").item(0).getTextContent().equalsIgnoreCase("0")){
						custDetails.setResponseStatus("SUC");
						custDetails.setResponseMsg("Category Update Successful");
					}
					else{
						custDetails.setResponseStatus("FAL");
					custDetails.setResponseMsg(eElement.getElementsByTagName("ReplyText").item(0).getTextContent());
					}
					}
			}
		} catch (SocketTimeoutException ex) {
			logger.error("Update could not be done due to :" + ex.getMessage());

			custDetails.setResponseStatus("FAL");
			custDetails.setResponseCode("408");
			custDetails.setResponseMsg(ex.getMessage());
		} catch (Exception ex) {
			logger.error("Update could not be done due to :" + ex.getMessage());
			custDetails.setResponseStatus("FAL");
			custDetails.setResponseMsg(ex.getMessage());
			custDetails.setResponseCode("111");
		}
	}

}