package com.airtel.money.bean;

public class DataBean {

	private String status;
	private String MSISDN;
	private String VOLT_TRANSACTION_ID;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMSISDN() {
		return MSISDN;
	}

	public void setMSISDN(String mSISDN) {
		MSISDN = mSISDN;
	}

	public String getVOLT_TRANSACTION_ID() {
		return VOLT_TRANSACTION_ID;
	}

	public void setVOLT_TRANSACTION_ID(String vOLT_TRANSACTION_ID) {
		VOLT_TRANSACTION_ID = vOLT_TRANSACTION_ID;
	}
	
	
}
