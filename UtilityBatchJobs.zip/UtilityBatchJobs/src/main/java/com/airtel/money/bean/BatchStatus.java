package com.airtel.money.bean;

import java.sql.Timestamp;

public class BatchStatus {
	private Long id; // NUMBER
	private Timestamp batchExeStartTs; // TIMESTAMP(6)
	private Timestamp batchExeEndTs; // TIMESTAMP(6)
	private Timestamp batchDataPickedStartTs; // TIMESTAMP(6)
	private Timestamp batchDataPickedEndTs; // TIMESTAMP(6)
	private String batchStatus;
	private String batchId;

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public String getBatchStatus() {
		return batchStatus;
	}

	public void setBatchStatus(String batchStatus) {
		this.batchStatus = batchStatus;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	
	public Timestamp getBatchExeStartTs() {
		return batchExeStartTs;
	}

	public void setBatchExeStartTs(Timestamp batchExeStartTs) {
		this.batchExeStartTs = batchExeStartTs;
	}

	public Timestamp getBatchExeEndTs() {
		return batchExeEndTs;
	}

	public void setBatchExeEndTs(Timestamp batchExeEndTs) {
		this.batchExeEndTs = batchExeEndTs;
	}

	public Timestamp getBatchDataPickedStartTs() {
		return batchDataPickedStartTs;
	}

	public void setBatchDataPickedStartTs(Timestamp batchDataPickedStartTs) {
		this.batchDataPickedStartTs = batchDataPickedStartTs;
	}

	public Timestamp getBatchDataPickedEndTs() {
		return batchDataPickedEndTs;
	}

	public void setBatchDataPickedEndTs(Timestamp batchDataPickedEndTs) {
		this.batchDataPickedEndTs = batchDataPickedEndTs;
	}

	@Override
	public String toString() {
		return "StgAmpReplBthStatus [id=" + id + ", batchExeStartTs=" + batchExeStartTs
				+ ", batchExeEndTs=" + batchExeEndTs + ", batchDataPickedStartTs=" + batchDataPickedStartTs
				+ ", batchDataPickedEndTs=" + batchDataPickedEndTs + ", batchStatus=" + batchStatus + "]";
	}

}
