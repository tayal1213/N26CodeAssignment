package com.airtel.money.bean;

public class AccountClosureBean {
	
	private String custMsisdn;

	public String getCustMsisdn() {
		return custMsisdn;
	}

	public void setCustMsisdn(String custMsisdn) {
		this.custMsisdn = custMsisdn;
	}

}
