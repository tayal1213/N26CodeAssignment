package com.airtel.money.tasklet;

import java.io.File;


import javax.ejb.Stateless;
import javax.mail.Message;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import org.apache.log4j.Logger;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;

@Stateless
// @Name("SendMail")
public class SendMailService {

	Logger logger = Logger.getLogger(SendMailService.class);
	private JavaMailSender mailSender;
	private String senderAddress;
	private String recipientTO;
	private String recipientCC;
	private String attachmentFile;

	

	public String getAttachmentFile() {
		return attachmentFile;
	}

	public void setAttachmentFile(String attachmentFile) {
		this.attachmentFile = attachmentFile;
	}

	private String subject;
	private String bodyData;

	// set the fields
	public void setFields(JavaMailSender mailSender, String senderAddress, String recipientTO, String recipientCC,
			String subject, String bodyData, String attachmentFile) {

		this.mailSender = mailSender;
		this.senderAddress = senderAddress;
		this.recipientTO = recipientTO;
		this.recipientCC = recipientCC;

		this.subject = subject;
		this.bodyData = bodyData;
		this.attachmentFile = attachmentFile;
	}

	public void sendMail() {
		logger.debug("Initiating request to send Email.");
		// read directory

		/*
		 * final File file = directory.listFiles(new FilenameFilter() { public
		 * boolean accept(File dir, String name) { return
		 * name.equals(attachmentFileName); } })[0];
		 */

		MimeMessagePreparator preparator = new MimeMessagePreparator() {
			public void prepare(MimeMessage mimeMessage) throws Exception {
				// mimeMessage.setRecipient(Message.RecipientType.TO, new
				// InternetAddress(recipient));
				mimeMessage.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientTO));
				if (recipientCC != null && !recipientCC.isEmpty())
					mimeMessage.setRecipients(Message.RecipientType.CC, InternetAddress.parse(recipientCC));
				mimeMessage.setFrom(new InternetAddress(senderAddress));
				mimeMessage.setSubject(subject);

				// MimeMessagesHelper is needed for the attachment. The Boolean
				// value in
				// constructor is for multipart/data = true
				MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
				if (attachmentFile != null) {
					logger.info("Attachment path Update ProfileResponse :" + attachmentFile);
					if (attachmentFile != null) {
						final File fileUpdate = new File(attachmentFile);
						if (fileUpdate.exists())
							helper.addAttachment(fileUpdate.getName(), new FileSystemResource(fileUpdate));
					}
				}
				helper.setText(bodyData, true);
			}
		};
		try {
			this.mailSender.send(preparator);
			// file.delete();
			logger.info("Mail sent successfully.");
		} catch (Exception ex) {
			logger.error("Exception occured while sending Email :" + ex.getMessage());
		}
	}

}
