package com.airtel.money.service;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;

public class EncryptionDecryptionService 
{
	
	
	public String getPassword(String pwd)
	{
		StandardPBEStringEncryptor encryptor =new StandardPBEStringEncryptor();
		encryptor.setPassword("root");
		encryptor.setAlgorithm("PBEWithMD5AndDES");
		return encryptor.decrypt(pwd);
	}
	public static void main(String[] args) 
	{
		StandardPBEStringEncryptor encryptor =new StandardPBEStringEncryptor();
		encryptor.setPassword("root");
		encryptor.setAlgorithm("PBEWithMD5AndDES");
		System.out.println(encryptor.encrypt("reader"));
		//System.out.println(encryptor.decrypt("uGLy7oa6LH4e0PAYCMayb+0+uiT95Q61"));
	}

}
