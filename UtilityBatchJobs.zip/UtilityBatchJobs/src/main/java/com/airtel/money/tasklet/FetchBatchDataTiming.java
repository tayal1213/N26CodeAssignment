/** <a href="http://www.cpupk.com/decompiler">Eclipse Class Decompiler</a> plugin, Copyright (c) 2017 Chen Chao. **/
package com.airtel.money.tasklet;

import com.airtel.money.bean.BatchStatus;
import com.airtel.money.dao.BatchDAO;

import java.sql.Timestamp;
import java.util.Locale;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.MessageSource;

public class FetchBatchDataTiming implements Tasklet {

	private MessageSource messageSource;
	private BatchStatus bthStatus;
	private BatchDAO dao;

	public MessageSource getMessageSource() {
		return this.messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public BatchStatus getBthStatus() {
		return this.bthStatus;
	}

	public void setBthStatus(BatchStatus bthStatus) {
		this.bthStatus = bthStatus;
	}

	public BatchDAO getDao() {
		return dao;
	}

	public void setDao(BatchDAO dao) {
		this.dao = dao;
	}

	public RepeatStatus execute(StepContribution arg0, ChunkContext arg1) throws Exception {
		BatchStatus prevBthStatus = this.dao.getBatchStatus();

		Long timeDiff = Long.valueOf(
				Long.parseLong(this.messageSource.getMessage("batch.time.diff", null, Locale.US)) * 60L * 1000L);

		if ((prevBthStatus.getBatchStatus() != null) && (prevBthStatus.getBatchStatus().equalsIgnoreCase("SUCCESS"))) {
			this.bthStatus.setBatchExeStartTs(new Timestamp(System.currentTimeMillis()));
			this.bthStatus.setBatchDataPickedStartTs(prevBthStatus.getBatchDataPickedEndTs());
			this.bthStatus.setBatchDataPickedEndTs(new Timestamp(System.currentTimeMillis() - timeDiff.longValue()));
			this.bthStatus.setBatchStatus("STARTED");

			this.dao.insertBatchStatus(this.bthStatus);
		} else {
			throw new Exception("Previous Batch  is in Progress or could not be completed");
		}
		return RepeatStatus.FINISHED;
	}
}