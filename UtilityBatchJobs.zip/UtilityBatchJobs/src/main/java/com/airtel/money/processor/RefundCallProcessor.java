package com.airtel.money.processor;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.net.SocketTimeoutException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.apache.log4j.Logger;
import org.eclipse.jetty.util.log.Log;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.context.MessageSource;
import com.airtel.money.bean.RefundDetailsBean;
import com.airtel.money.service.APIClient;
import com.airtelbank.models.envelop.ResponseDTO;
import com.airtelbank.payments.model.PaymentDetails;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;
import freemarker.template.Version;

public class RefundCallProcessor implements ItemProcessor<RefundDetailsBean, RefundDetailsBean> {

	private MessageSource messageSource;
	private APIClient apiClient;

	Logger logger = Logger.getLogger(RefundCallProcessor.class);

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public APIClient getApiClient() {
		return apiClient;
	}

	public void setApiClient(APIClient apiClient) {
		this.apiClient = apiClient;
	}

	@Override
	public RefundDetailsBean process(RefundDetailsBean refundBean) throws Exception {
		logger.info("Inside RefundCallProcessor.process(), Processing refund for: " + refundBean.getPrId());

		callRefundApi(refundBean);
		refundBean.setCreatedTs(new Timestamp(System.currentTimeMillis()));
		refundBean.setModifiedTs(new Timestamp(System.currentTimeMillis()));

		return refundBean;
	}

	public void callRefundApi(RefundDetailsBean refundBean) {

		logger.info("Calling Refund API ");
		String requestObj = null;

		try {
			refundBean.setRequestTimestamp(jacksonDate(refundBean.getRequestTimestamp()));
			Map<String, Object> input = new HashMap<String, Object>();
			input.put("refundBean", refundBean);
			requestObj = getFtlResponse("refund_api_call.ftl", input);

			ResponseDTO<PaymentDetails> resp = apiClient
					.invokeAPI(messageSource.getMessage("refund.call.ws.url", null, Locale.US), requestObj);

			if (resp != null && resp.getMeta().getCode().equalsIgnoreCase("0")) {
				if (resp.getData().getStatus().toString().equalsIgnoreCase("0")) {
					logger.info("REFUND Successfully Processed for PRID " + refundBean.getPrId());
					refundBean.setResponseCode(resp.getData().getStatus().toString());
					refundBean.setResponseMsg(resp.getData().getTxnMessage());
					refundBean.setResponseStatus("SUCCESS");
					refundBean.setPartnerOrgTxnId(resp.getData().getParamaters().get("partnerOrgTxnId"));
					refundBean.setPartnerRefundTxnId(resp.getData().getParamaters().get("partnerRefundId"));
				}

				else {
					logger.info("REFUND Failed Processed for PRID " + refundBean.getPrId());
					refundBean.setResponseCode(resp.getData().getStatus().toString());
					refundBean.setResponseMsg(resp.getData().getTxnMessage());
					refundBean.setResponseStatus("FAILURE");

				}
			}

			else {
				logger.info("REFUND Failed Processed for PRID " + refundBean.getPrId());
				refundBean.setResponseCode(resp.getMeta().getCode());
				refundBean.setResponseMsg(resp.getMeta().getDescription());
				refundBean.setResponseStatus("FAILURE");

			}

		} catch (SocketTimeoutException ex) {
			logger.error("Refund could not be done due to :" + ex.getMessage());

			refundBean.setResponseStatus("FAL");
			refundBean.setResponseCode("408");
			refundBean.setResponseMsg(ex.getMessage());
		} catch (Exception ex) {
			logger.error("Refund could not be done due to :" + ex.getMessage());
			refundBean.setResponseStatus("FAL");
			refundBean.setResponseMsg(ex.getMessage());
			refundBean.setResponseCode("111");

		}

	}

	public static String getFtlResponse(String fileName, Map<String, Object> mapObj)
			throws IOException, TemplateException {
		Configuration cfg = new Configuration();

		// Where do we load the templates from:
		// cfg.setClassForTemplateLoading(MainTest.class, "/");

		cfg.setDirectoryForTemplateLoading(new File("templates"));

		// Some other recommended settings:
		cfg.setIncompatibleImprovements(new Version(2, 3, 20));
		cfg.setDefaultEncoding("UTF-8");
		cfg.setLocale(Locale.US);
		cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
		Template template = cfg.getTemplate(fileName);

		Writer out = new StringWriter();
		template.process(mapObj, out);
		String transformedTemplate = out.toString();
		out.flush();
		return transformedTemplate;
	}

	public static String jacksonDate(String date) throws ParseException
	{
		
		DateFormat formatter;
		formatter = new SimpleDateFormat("dd-MMM-yy HH.mm.ss.S aa");
		DateFormat formatter1;
		formatter1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		Date date1 = (Date) formatter.parse(date);
		return formatter1.format(date1);
		
	}
	
}
