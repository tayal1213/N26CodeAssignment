package com.airtel.money.bean;

import java.sql.Timestamp;
import java.util.Date;

public class RefundDetailsBean {

	private String prId;
	private String refundAmount;

	private Timestamp createdTs;
	private Timestamp modifiedTs;

	private String responseStatus;
	private String responseCode;
	private String responseMsg;

	private String partnerOrgTxnId;
	private String partnerRefundTxnId;
	private String toSms;
	private String toNarration;
	private String requestTimestamp;
	
	
	public String getPartnerOrgTxnId() {
		return partnerOrgTxnId;
	}

	public void setPartnerOrgTxnId(String partnerOrgTxnId) {
		this.partnerOrgTxnId = partnerOrgTxnId;
	}

	public String getPartnerRefundTxnId() {
		return partnerRefundTxnId;
	}

	public void setPartnerRefundTxnId(String partnerRefundTxnId) {
		this.partnerRefundTxnId = partnerRefundTxnId;
	}

	public String getToSms() {
		return toSms;
	}

	public void setToSms(String toSms) {
		this.toSms = toSms;
	}

	public String getToNarration() {
		return toNarration;
	}

	public void setToNarration(String toNarration) {
		this.toNarration = toNarration;
	}

	public String getRequestTimestamp() {
		return requestTimestamp;
	}

	public void setRequestTimestamp(String requestTimestamp) {
		this.requestTimestamp = requestTimestamp;
	}

	public String getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMsg() {
		return responseMsg;
	}

	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}

	public Timestamp getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Timestamp createdTs) {
		this.createdTs = createdTs;
	}

	public Timestamp getModifiedTs() {
		return modifiedTs;
	}

	public void setModifiedTs(Timestamp modifiedTs) {
		this.modifiedTs = modifiedTs;
	}

	public String getPrId() {
		return prId;
	}

	public void setPrId(String prId) {
		this.prId = prId;
	}

	public String getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}

}
