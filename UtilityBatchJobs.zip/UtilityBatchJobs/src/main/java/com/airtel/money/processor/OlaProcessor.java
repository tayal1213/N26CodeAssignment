package com.airtel.money.processor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Locale;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.CustomerMasterData;

public class OlaProcessor implements ItemProcessor<CustomerMasterData, CustomerMasterData> {

	private MessageSource messageSource;

	Logger LOGGER = Logger.getLogger(OlaProcessor.class);

	@Override
	public CustomerMasterData process(CustomerMasterData data) throws Exception {

		File dir = new File(messageSource.getMessage("ola.file.dir", null, Locale.US));
		try {

			if (dir != null) {
				File img = searchFile(dir, data.getCustmsisdn());
				data.setBase64Img(encodeFileToBase64Binary(img));
			}

		}

		catch (Exception e) {
			LOGGER.info("Exception while searching/encoding the file :" + e);
		}

		return data;
	}

	private File searchFile(File dir, String custmsisdn) {

		LOGGER.info("Searching file for Customer Number " + custmsisdn);

		FilenameFilter beginswithMsisdn = new FilenameFilter() {
			public boolean accept(File directory, String filename) {
				return filename.startsWith(custmsisdn);
			}
		};

		File[] files = dir.listFiles(beginswithMsisdn);
		if (files != null && files.length >= 1 && files.length < 2) {

			LOGGER.info("Single file found for  " + custmsisdn);
			return files[0];
		} else {
			LOGGER.info("Multiple files found for  " + custmsisdn);
			Arrays.sort(files, (a, b) -> Long.compare(a.lastModified(), b.lastModified()));
			return files[files.length - 1];

		}

	}

	private String encodeFileToBase64Binary(File file) throws IOException {

		String encodedBase64 = null;
		try {

			LOGGER.info("Decoding the image to base64 String");
			FileInputStream fileInputStreamReader = new FileInputStream(file);
			byte[] bytes = new byte[(int) file.length()];
			fileInputStreamReader.read(bytes);
			encodedBase64 = new String(Base64.encodeBase64(bytes));

			fileInputStreamReader.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return encodedBase64;
	}

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

}
