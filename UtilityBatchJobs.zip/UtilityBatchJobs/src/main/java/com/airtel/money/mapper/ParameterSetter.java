package com.airtel.money.mapper;

import com.airtel.money.bean.BatchStatus;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.UUID;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.PreparedStatementSetter;

public class ParameterSetter implements PreparedStatementSetter {
	private BatchStatus bthStatus;
	Logger logger;

	public ParameterSetter() {
		this.logger = Logger.getLogger(ParameterSetter.class);
	}

	public BatchStatus getBthStatus() {
		return this.bthStatus;
	}

	public void setBthStatus(BatchStatus bthStatus) {
		this.bthStatus = bthStatus;
	}

	public void setValues(PreparedStatement ps) throws SQLException {
		ps.setTimestamp(1, this.bthStatus.getBatchDataPickedStartTs());
		ps.setTimestamp(2, this.bthStatus.getBatchDataPickedEndTs());
		String batchId = UUID.randomUUID().toString();
		this.logger.info("BatchID is  :" + batchId);
		this.bthStatus.setBatchId(batchId);
	}
}