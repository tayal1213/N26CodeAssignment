package com.airtel.money.tasklet;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.mail.javamail.JavaMailSender;

import com.airtel.money.bean.BatchStatus;
import com.airtel.money.dao.BatchDAO;
import com.airtel.money.listener.StepListener;
import com.airtel.money.tasklet.SendMailService;

public class SendMailTasklet implements Tasklet {

	Logger log = Logger.getLogger(SendMailTasklet.class);

	private SendMailService sendMailService;
	private JavaMailSender mailSender;
	private String senderAddress;
	private String recipientTO;
	private String recipientCC;
	private String subject;
	private String bodyData;
	private String attachmentFile;

	
	public String getAttachmentFile() {
		return attachmentFile;
	}

	public void setAttachmentFile(String attachmentFile) {
		this.attachmentFile = attachmentFile;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBodyData() {
		return bodyData;
	}

	public void setBodyData(String bodyData) {
		this.bodyData = bodyData;
	}

	public void setMailSender(JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}

	public String getRecipientCC() {
		return recipientCC;
	}

	public void setRecipientCC(String recipientCC) {
		this.recipientCC = recipientCC;
	}

	public void setSenderAddress(String senderAddress) {
		this.senderAddress = senderAddress;
	}

	public void setRecipientTO(String recipient) {
		this.recipientTO = recipient;
	}

	public void setSendMailService(SendMailService sendMailService) {
		this.sendMailService = sendMailService;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.info("execute(StepContribution contribution, ChunkContext chunkContext) begin");
		
		sendMailService.setFields(mailSender, senderAddress, recipientTO, recipientCC, subject, bodyData,
				attachmentFile);
		sendMailService.sendMail();
	//	dao.updateBatchStatus();

		log.info("execute(StepContribution contribution, ChunkContext chunkContext) end");
		return RepeatStatus.FINISHED;
	}

}