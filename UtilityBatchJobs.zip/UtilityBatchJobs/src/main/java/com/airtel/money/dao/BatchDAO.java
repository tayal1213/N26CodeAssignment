package com.airtel.money.dao;

import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.airtel.money.bean.BatchStatus;
import com.airtel.money.bean.CustomerMasterData;
import com.airtel.money.mapper.BatchStatusMapper;

import com.airtel.money.mapper.LongRowMapper;

public class BatchDAO {
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;
	private BatchStatus batchStatus;

	public void setBatchStatus(BatchStatus batchStatus) {
		this.batchStatus = batchStatus;
	}

	Logger logger = Logger.getLogger(BatchDAO.class);

	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplateObject = new JdbcTemplate(dataSource);

	}

	public BatchStatus getBatchStatus() {
		String SQL = "select * from CUST_BTH_STATUS where id=(select max(id) from CUST_BTH_STATUS) ";
		BatchStatus bthStatus = null;
		try {
			List<BatchStatus> lstStgAmpReplBthStatus = jdbcTemplateObject.query(SQL, new Object[] {},
					new BatchStatusMapper());
			if (lstStgAmpReplBthStatus != null && lstStgAmpReplBthStatus.size() > 0)
				bthStatus = lstStgAmpReplBthStatus.get(0);
		} catch (org.springframework.dao.EmptyResultDataAccessException e) {
			logger.info("No record found in AMP_CUST_BTH_STATUS for ");
		} catch (Exception e) {
			logger.warn("Exception occured", e);
		}
		return bthStatus;

	}

	public int getSuccessCount(String batchId) {
		String sql = "select count(*) from UPDATE_API_LOG where RESP_STAT='SUC' and BATCH_ID=?";
		int count = jdbcTemplateObject.queryForObject(sql, new Object[] { batchId }, Integer.class);
		logger.info("SUCCESS COUNT =" + count);
		return count;

	}

	public int getFailedCount(String batchId) {
		String sql = "select count(*) from UPDATE_API_LOG where RESP_STAT='FAL' and BATCH_ID=?";
		int count = jdbcTemplateObject.queryForObject(sql, new Object[] { batchId }, Integer.class);

		logger.info("FAILURE COUNT =" + count);
		return count;

	}

	public void updateBatchStatus() {
		try {
			jdbcTemplateObject.execute(
					"Update CUST_BTH_STATUS set BATCH_EXE_END_TS=CURRENT_TIMESTAMP, BATCH_STATUS ='SUCCESS'"
							+ " where id=" + batchStatus.getId());
		} catch (Exception e) {
			logger.info("Exception occured", e);
		}

	}

	public void insertBatchStatus(BatchStatus batchStatus) {
		String SQL = "select BATCH_STATUS_SEQ.nextval from dual";
		Long seqNo = null;
		try {
			seqNo = jdbcTemplateObject.queryForObject(SQL, new Object[] {}, new LongRowMapper());
			batchStatus.setId(seqNo);
		} catch (org.springframework.dao.EmptyResultDataAccessException e) {
			logger.info(" BATCH: No Sequence found");
		} catch (Exception e) {
			logger.warn("BATCH: Exception occured", e);
		}
		String sql = "Insert into CUST_BTH_STATUS (ID, BATCH_EXE_START_TS, BATCH_EXE_END_TS, BATCH_DATA_PICKED_START_TS, BATCH_DATA_PICKED_END_TS,BATCH_STATUS) "
				+ "values (?,?,?,?,?,?)";
		jdbcTemplateObject.update(sql,
				new Object[] { batchStatus.getId(), batchStatus.getBatchExeStartTs(), batchStatus.getBatchExeEndTs(),
						batchStatus.getBatchDataPickedStartTs(), batchStatus.getBatchDataPickedEndTs(),
						batchStatus.getBatchStatus() });

	}


}
