package com.airtel.money.tasklet;

import java.io.File;
import java.util.List;
import java.util.Locale;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.MessageSource;

public class MoveDataFileTasklset implements Tasklet {

	private MessageSource messageSource;
	private String jobName;
	private String fileName;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public Logger getLogger() {
		return logger;
	}

	public void setLogger(Logger logger) {
		this.logger = logger;
	}

	Logger logger = Logger.getLogger(MoveDataFileTasklset.class);

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		logger.info("Inside MoveDataFileTasklset.execute()");
		String inputFileLocationDir = null;
		String archiveFileLocationDir = null;
		String outputFileLocationDir = null;
		File outputFile = null;

		try {

			if (jobName.equalsIgnoreCase("refundApiCallJob")) {
				inputFileLocationDir = messageSource.getMessage("refund.api.input.file.location", null, Locale.US);
				outputFileLocationDir = messageSource.getMessage("refund.api.output.file.location", null, Locale.US);
				archiveFileLocationDir = messageSource.getMessage("refund.api.archive.file.location", null, Locale.US);
				outputFile = new File(outputFileLocationDir + fileName);

				inputFileLocationDir = inputFileLocationDir.substring(0, inputFileLocationDir.lastIndexOf("/") + 1);
				String[] extensions = messageSource
						.getMessage("supporting.file.extension", null, Locale.US).split(",");
				File inputFile = new File(inputFileLocationDir);
				List<File> files = (List<File>) FileUtils.listFiles(inputFile, extensions, true);

			
					for (File file : files) {
						if (file.exists()) {
							try {
							FileUtils.moveFile(file, new File(archiveFileLocationDir + file.getName()));
							file.delete();
							}
							catch (Exception e) {
								logger.info("File could not be archived due to" + e.getMessage());
								file.delete();
							}
						}
					}
				} 

			else {

				inputFileLocationDir = messageSource.getMessage("master.card.closure.input.dir.path", null, Locale.US);

				archiveFileLocationDir = messageSource.getMessage("master.card.closure.archive.dir.path", null,
						Locale.US);

				inputFileLocationDir = inputFileLocationDir.substring(0, inputFileLocationDir.lastIndexOf("/") + 1);
				String[] extensions = messageSource.getMessage("supporting.file.extension", null, Locale.US).split(",");
				File inputFile = new File(inputFileLocationDir);
				List<File> files = (List<File>) FileUtils.listFiles(inputFile, extensions, true);

				for (File file : files) {
					if (file.exists()) {
						// FileUtils.copyFileToDirectory(file, archiveFile);
						FileUtils.moveFile(file, new File(archiveFileLocationDir + file.getName()));
						file.delete();
					}
				}

			}
		} catch (

		Exception e) {
			logger.error("File could not be archive due to some error" + e.getMessage());
		}
		// TODO Auto-generated method stub
		return RepeatStatus.FINISHED;
	}

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

}
