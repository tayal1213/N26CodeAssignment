/** <a href="http://www.cpupk.com/decompiler">Eclipse Class Decompiler</a> plugin, Copyright (c) 2017 Chen Chao. **/
package com.airtel.money.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class LongRowMapper implements RowMapper<Long> {
	public Long mapRow(ResultSet rs, int rowNum) throws SQLException {
		return Long.valueOf(rs.getLong(1));
	}
}