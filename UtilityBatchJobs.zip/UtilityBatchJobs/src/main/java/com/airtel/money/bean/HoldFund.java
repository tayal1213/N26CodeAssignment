package com.airtel.money.bean;

public class HoldFund {

	String CUST_MSISDN;
	String AADHAAR_ID;
	String VOLT_TRANSACTION_ID;
	String HOLD_NUMBER;
	public String getCUST_MSISDN() {
		return CUST_MSISDN;
	}
	public void setCUST_MSISDN(String cUST_MSISDN) {
		CUST_MSISDN = cUST_MSISDN;
	}
	public String getAADHAAR_ID() {
		return AADHAAR_ID;
	}
	public void setAADHAAR_ID(String aADHAAR_ID) {
		AADHAAR_ID = aADHAAR_ID;
	}
	public String getVOLT_TRANSACTION_ID() {
		return VOLT_TRANSACTION_ID;
	}
	public void setVOLT_TRANSACTION_ID(String vOLT_TRANSACTION_ID) {
		VOLT_TRANSACTION_ID = vOLT_TRANSACTION_ID;
	}
	public String getHOLD_NUMBER() {
		return HOLD_NUMBER;
	}
	public void setHOLD_NUMBER(String hOLD_NUMBER) {
		HOLD_NUMBER = hOLD_NUMBER;
	}
	
	
}
