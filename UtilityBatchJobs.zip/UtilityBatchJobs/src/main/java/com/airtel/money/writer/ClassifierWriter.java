package com.airtel.money.writer;

import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.batch.support.annotation.Classifier;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.CustDataCBS;;

public class ClassifierWriter {
	private MessageSource messageSource;

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	Logger logger = Logger.getLogger(Classifier.class);

	@Classifier
	public String classify(CustDataCBS custData) {
		logger.info(custData.getBatchIdentifier());
		if (custData.getBatchIdentifier().equalsIgnoreCase("circleBatch")) {
			return "circleBatch";
		}
		return "updateBatch";

	}
}
