package com.airtel.money.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.airtel.money.bean.BatchStatus;

public class BatchStatusMapper implements RowMapper<BatchStatus> {

	@Override
	public BatchStatus mapRow(ResultSet rs, int arg1) throws SQLException {
		BatchStatus batchStatus = new BatchStatus();
		batchStatus.setId(rs.getLong("ID"));

		batchStatus.setBatchExeStartTs(rs.getTimestamp("BATCH_EXE_START_TS"));
		batchStatus.setBatchExeEndTs(rs.getTimestamp("BATCH_EXE_END_TS"));
		batchStatus.setBatchDataPickedStartTs(rs.getTimestamp("BATCH_DATA_PICKED_START_TS"));
		batchStatus.setBatchDataPickedEndTs(rs.getTimestamp("BATCH_DATA_PICKED_END_TS"));
		batchStatus.setBatchStatus(rs.getString("BATCH_STATUS"));

		return batchStatus;
	}

}
