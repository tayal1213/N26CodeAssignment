/** <a href="http://www.cpupk.com/decompiler">Eclipse Class Decompiler</a> plugin, Copyright (c) 2017 Chen Chao. **/
package com.airtel.money.tasklet;

import java.util.Locale;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.MessageSource;
import org.springframework.mail.javamail.JavaMailSender;

public class StepFailedTasklet implements Tasklet {
	private SendMailService sendMailService;
	private JavaMailSender mailSender;
	private MessageSource messageSource;
	private static Logger log = Logger.getLogger(StepFailedTasklet.class);

	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.info("Previous batch could not be completed");
		String errorMsgDetails = this.messageSource.getMessage("amp.delta.repl.error.email.body", null, Locale.US);
		String subject = this.messageSource.getMessage("amp.delta.repl.error.email.sub", null, Locale.US);
		this.sendMailService.setFields(this.mailSender,
				this.messageSource.getMessage("amp.delta.repl.error.email.from", null, Locale.US),
				this.messageSource.getMessage("amp.delta.repl.error.email.to", null, Locale.US),
				this.messageSource.getMessage("amp.delta.repl.error.email.cc", null, Locale.US), subject,
				errorMsgDetails, null);

		this.sendMailService.sendMail();
		return RepeatStatus.FINISHED;
	}

	public JavaMailSender getMailSender() {
		return this.mailSender;
	}

	public void setMailSender(JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}

	public MessageSource getMessageSource() {
		return this.messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public SendMailService getSendMailService() {
		return this.sendMailService;
	}

	public void setSendMailService(SendMailService sendMailService) {
		this.sendMailService = sendMailService;
	}
}