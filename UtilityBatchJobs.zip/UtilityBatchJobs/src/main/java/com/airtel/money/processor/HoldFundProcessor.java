package com.airtel.money.processor;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Locale;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.context.MessageSource;

import com.airtel.money.bean.DataBean;
import com.airtel.money.bean.HoldFund;

public class HoldFundProcessor implements ItemProcessor<HoldFund, DataBean> {
	Logger LOGGER = Logger.getLogger(HoldFundProcessor.class);
	private MessageSource messageSource;

	// private DbtMappingDao dbtMappingDao;
	@Override
	public DataBean process(HoldFund item) throws Exception {
		DataBean databean = new DataBean();
		String url = messageSource.getMessage("volt.post.url", null, Locale.US);
		URL obj = new URL(url);
		HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();

		con.setRequestMethod("POST");

		String urlParameters = "MSISDN=" + item.getCUST_MSISDN() + "&VOLT_TXN_ID=" + item.getVOLT_TRANSACTION_ID()
				+ "&HOLD_NUMBER=" + item.getHOLD_NUMBER();

		// Send post request
		con.setDoOutput(true);
		DataOutputStream wr = new DataOutputStream(con.getOutputStream());
		wr.writeBytes(urlParameters);
		wr.flush();
		wr.close();

		int responseCode = con.getResponseCode();
		System.out.println("\nSending 'POST' request to URL : " + url);
		System.out.println("Post parameters : " + urlParameters);
		System.out.println("Response Code : " + responseCode);

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		// print result
		String resp = response.toString();
		// System.out.println(resp);

		databean.setMSISDN(item.getCUST_MSISDN());
		databean.setVOLT_TRANSACTION_ID(item.getVOLT_TRANSACTION_ID());
		String result = "";

		if (resp != null) {

			result = StringUtils.substringBetween(resp, "<tns:errorMessage>", "</tns:errorMessage>");
			databean.setStatus(result);
		}

		return databean;
	}

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

}