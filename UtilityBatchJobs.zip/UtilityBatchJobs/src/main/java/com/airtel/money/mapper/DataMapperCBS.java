/** <a href="http://www.cpupk.com/decompiler">Eclipse Class Decompiler</a> plugin, Copyright (c) 2017 Chen Chao. **/
package com.airtel.money.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.airtel.money.bean.CustDataCBS;

public class DataMapperCBS implements RowMapper<CustDataCBS> {
	private static Logger logger = Logger.getLogger(DataMapperCBS.class);

	public CustDataCBS mapRow(ResultSet rs, int rowNum) throws SQLException {
		CustDataCBS custDetails = new CustDataCBS();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		custDetails.setCircle(rs.getString("CIRCLE"));
		if ((rs.getString("NAM_CUST_FIRST") != null))
			custDetails.setCustFirstName(rs.getString("NAM_CUST_FIRST").toUpperCase());
		else
			custDetails.setCustFirstName(rs.getString("NAM_CUST_FIRST"));
		if ((rs.getString("NAM_CUST_LAST") != null))
			custDetails.setCustLastName(rs.getString("NAM_CUST_LAST").toUpperCase());
		else
			custDetails.setCustLastName(rs.getString("NAM_CUST_LAST"));
		custDetails.setCustDob(sdf.format(rs.getDate("DAT_BIRTH_CUST")));
		if (rs.getString("REF_CUST_EMAIL") != null)
			custDetails.setCustMail(rs.getString("REF_CUST_EMAIL").toUpperCase());
		else
			custDetails.setCustMail(rs.getString("REF_CUST_EMAIL"));
		custDetails.setCustType(rs.getString("FLG_CUST_TYP"));
		custDetails.setChannel(rs.getString("OBOARD_CHANNEL"));
		custDetails.setCategory(rs.getString("COD_CATEGORY"));
		custDetails.setMsisdn(rs.getString("COD_CUST_NATL_ID"));
		custDetails.setState(rs.getString("NAM_CUSTADR_STATE"));
		custDetails.setCodAcctNum(rs.getString("COD_ACCT_NO"));
		return custDetails;
	}

}