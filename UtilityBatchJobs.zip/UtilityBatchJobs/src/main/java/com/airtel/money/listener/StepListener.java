package com.airtel.money.listener;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;

import com.airtel.money.bean.BatchStatus;
import com.airtel.money.dao.BatchDAO;


public class StepListener implements StepExecutionListener {

	private int successCount;
	private int failCount;
	private BatchStatus bthStatus;
	private BatchDAO dao;
	
	
	
	public BatchDAO getDao() {
		return dao;
	}

	public void setDao(BatchDAO dao) {
		this.dao = dao;
	}

	public BatchStatus getBthStatus() {
		return bthStatus;
	}

	public void setBthStatus(BatchStatus bthStatus) {
		this.bthStatus = bthStatus;
	}

	

	public int getSuccessCount() {
		return successCount;
	}

	public void setSuccessCount(int successCount) {
		this.successCount = successCount;
	}

	public int getFailCount() {
		return failCount;
	}

	public void setFailCount(int failCount) {
		this.failCount = failCount;
	}

	@Override
	public ExitStatus afterStep(StepExecution arg0) {

		successCount = dao.getSuccessCount(bthStatus.getBatchId());
		failCount = dao.getFailedCount(bthStatus.getBatchId());
		return null;
	}

	@Override
	public void beforeStep(StepExecution arg0) {

	}

}
