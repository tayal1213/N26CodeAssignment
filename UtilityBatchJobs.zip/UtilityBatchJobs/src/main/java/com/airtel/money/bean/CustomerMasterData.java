package com.airtel.money.bean;

public class CustomerMasterData {
	private String Custmsisdn;
	private String Custfname;
	private String Custmname;
	private String Custlname;
	private String Custdob;
	private String Gender;
	private String Aadhaarid;
	private String Fatherorhusbandname;
	private String Mothermaidenname;
	private String Localaddress1;
	private String Localaddress2;
	private String Localaddress3;
	private String Localaddress4;
	private String Localcity;
	private String Localdistrict;
	private String Localpostalcode;
	private String Localstate;
	private String Custhouse;
	private String Custstreet;
	private String Custlandmark;
	private String Custlocality;
	private String Custvtc;
	private String Custdistrict;
	private String Custstate;
	private String Custpincode;
	private String Olacodeordl;
	private String base64Img;

	public String getBase64Img() {
		return base64Img;
	}

	public void setBase64Img(String base64Img) {
		this.base64Img = base64Img;
	}

	public String getCustmsisdn() {
		return Custmsisdn;
	}

	public void setCustmsisdn(String custmsisdn) {
		Custmsisdn = custmsisdn;
	}

	public String getCustfname() {
		return Custfname;
	}

	public void setCustfname(String custfname) {
		Custfname = custfname;
	}

	public String getCustmname() {
		return Custmname;
	}

	public void setCustmname(String custmname) {
		Custmname = custmname;
	}

	public String getCustlname() {
		return Custlname;
	}

	public void setCustlname(String custlname) {
		Custlname = custlname;
	}

	public String getCustdob() {
		return Custdob;
	}

	public void setCustdob(String custdob) {
		Custdob = custdob;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String getAadhaarid() {
		return Aadhaarid;
	}

	public void setAadhaarid(String aadhaarid) {
		Aadhaarid = aadhaarid;
	}

	public String getFatherorhusbandname() {
		return Fatherorhusbandname;
	}

	public void setFatherorhusbandname(String fatherorhusbandname) {
		Fatherorhusbandname = fatherorhusbandname;
	}

	public String getMothermaidenname() {
		return Mothermaidenname;
	}

	public void setMothermaidenname(String mothermaidenname) {
		Mothermaidenname = mothermaidenname;
	}

	public String getLocaladdress1() {
		return Localaddress1;
	}

	public void setLocaladdress1(String localaddress1) {
		Localaddress1 = localaddress1;
	}

	public String getLocaladdress2() {
		return Localaddress2;
	}

	public void setLocaladdress2(String localaddress2) {
		Localaddress2 = localaddress2;
	}

	public String getLocaladdress3() {
		return Localaddress3;
	}

	public void setLocaladdress3(String localaddress3) {
		Localaddress3 = localaddress3;
	}

	public String getLocaladdress4() {
		return Localaddress4;
	}

	public void setLocaladdress4(String localaddress4) {
		Localaddress4 = localaddress4;
	}

	public String getLocalcity() {
		return Localcity;
	}

	public void setLocalcity(String localcity) {
		Localcity = localcity;
	}

	public String getLocaldistrict() {
		return Localdistrict;
	}

	public void setLocaldistrict(String localdistrict) {
		Localdistrict = localdistrict;
	}

	public String getLocalpostalcode() {
		return Localpostalcode;
	}

	public void setLocalpostalcode(String localpostalcode) {
		Localpostalcode = localpostalcode;
	}

	public String getLocalstate() {
		return Localstate;
	}

	public void setLocalstate(String localstate) {
		Localstate = localstate;
	}

	public String getCusthouse() {
		return Custhouse;
	}

	public void setCusthouse(String custhouse) {
		Custhouse = custhouse;
	}

	public String getCuststreet() {
		return Custstreet;
	}

	public void setCuststreet(String custstreet) {
		Custstreet = custstreet;
	}

	public String getCustlandmark() {
		return Custlandmark;
	}

	public void setCustlandmark(String custlandmark) {
		Custlandmark = custlandmark;
	}

	public String getCustlocality() {
		return Custlocality;
	}

	public void setCustlocality(String custlocality) {
		Custlocality = custlocality;
	}

	public String getCustvtc() {
		return Custvtc;
	}

	public void setCustvtc(String custvtc) {
		Custvtc = custvtc;
	}

	public String getCustdistrict() {
		return Custdistrict;
	}

	public void setCustdistrict(String custdistrict) {
		Custdistrict = custdistrict;
	}

	public String getCuststate() {
		return Custstate;
	}

	public void setCuststate(String custstate) {
		Custstate = custstate;
	}

	public String getCustpincode() {
		return Custpincode;
	}

	public void setCustpincode(String custpincode) {
		Custpincode = custpincode;
	}

	public String getOlacodeordl() {
		return Olacodeordl;
	}

	public void setOlacodeordl(String olacodeordl) {
		Olacodeordl = olacodeordl;
	}

	@Override
	public String toString() {
		return "CustomerMasterData [Custmsisdn=" + Custmsisdn + ", Custfname=" + Custfname + ", Custmname=" + Custmname
				+ ", Custlname=" + Custlname + ", Custdob=" + Custdob + ", Gender=" + Gender + ", Aadhaarid="
				+ Aadhaarid + ", Fatherorhusbandname=" + Fatherorhusbandname + ", Mothermaidenname=" + Mothermaidenname
				+ ", Localaddress1=" + Localaddress1 + ", Localaddress2=" + Localaddress2 + ", Localaddress3="
				+ Localaddress3 + ", Localaddress4=" + Localaddress4 + ", Localcity=" + Localcity + ", Localdistrict="
				+ Localdistrict + ", Localpostalcode=" + Localpostalcode + ", Localstate=" + Localstate + ", Custhouse="
				+ Custhouse + ", Custstreet=" + Custstreet + ", Custlandmark=" + Custlandmark + ", Custlocality="
				+ Custlocality + ", Custvtc=" + Custvtc + ", Custdistrict=" + Custdistrict + ", Custstate=" + Custstate
				+ ", Custpincode=" + Custpincode + ", Olacodeordl=" + Olacodeordl + "]";
	}

}
