package com.airtel.money.writer;

import java.io.IOException;
import java.io.Writer;

import org.springframework.batch.item.file.FlatFileHeaderCallback;

public class HeaderWriter implements FlatFileHeaderCallback {
	
	String headerData;

    public String getHeaderData() {
		return headerData;
	}

	public void setHeaderData(String headerData) {
		this.headerData = headerData;
	}

	@Override
	public void writeHeader(Writer writer) throws IOException {
		
		writer.write(headerData);
		
	}
}
