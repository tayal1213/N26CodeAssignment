package com.opi.sanity.opisanity.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OriginatorDetails {
	private Account account;
}