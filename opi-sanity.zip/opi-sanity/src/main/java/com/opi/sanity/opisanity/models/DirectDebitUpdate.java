package com.opi.sanity.opisanity.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DirectDebitUpdate {
	
	private String requestReferenceNumber;
	private String ddaReference;
	private String customerCIF;
	private String accountNumber;
	private String action;
	private String maximumDebitingAmount;
	private String accountCurrency;

}
