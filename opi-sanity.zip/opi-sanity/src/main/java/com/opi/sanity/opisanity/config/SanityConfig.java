package com.opi.sanity.opisanity.config;

import java.io.IOException;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public abstract class SanityConfig {
	
	private String clientId;
	private String apiKey;
	private String applicationId;
	private String country;
	private String ssl;
	private String privateKey;
	private String publicKey;
	
	private List<String> apiNameList;
	private List<String> urlList;
	private List<String> reqMethod;
	private List<String> payloadList;
	
	public abstract void initiateApiCalls()  throws IOException;

}
