package com.opi.sanity.opisanity;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.opi.sanity.opisanity.service.OpiSanityMainService;

@SpringBootApplication
public class OpiSanityApplication implements CommandLineRunner {

	@Autowired
	OpiSanityMainService opiSanityMainService;

	public static void main(String[] args) {
		SpringApplication.run(OpiSanityApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		System.setProperty("javax.net.ssl.trustStore", System.getProperty("files-location")+"\\client.jks");
		
		System.setProperty("javax.net.ssl.trustStorePassword", "s3cr3t");
		
		HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        });
		
		opiSanityMainService.initiateOpiSanity();
	}

}
