package com.opi.sanity.opisanity.models;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Transaction {
	
	private String transactionReference;
	private String transactionDate;
	private Account account;
	private PaymentAmount paymentAmount;

}
