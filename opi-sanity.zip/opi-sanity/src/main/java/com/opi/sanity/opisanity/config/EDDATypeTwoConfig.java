package com.opi.sanity.opisanity.config;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.opi.sanity.opisanity.models.DirectDebitCreation;
import com.opi.sanity.opisanity.models.EDDA;
import com.opi.sanity.opisanity.models.EDDASetupResponse;
import com.opi.sanity.opisanity.util.Util;


@ConfigurationProperties("eddatypetwo")
@Configuration
public class EDDATypeTwoConfig extends SanityConfig {

	private static final Logger log = LogManager.getLogger(EDDATypeTwoConfig.class);

	private List<String> dependent; 

	@Value("${json.location}")
	String jsonLocation;

	@Override
	public void initiateApiCalls() throws IOException {

		JsonParser parser = new JsonParser();
		for (int i=0; i<this.getApiNameList().size(); i++) {

			log.info("*** Starting for API: {} ***", this.getApiNameList().get(i));

			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			JsonElement json = parser.parse(new FileReader(this.getPayloadList().get(i)));
			String payload = gson.toJson(json).replaceFirst("##", "SANIT"+Util.date("yyyyMMddhhmmss"))
					.replaceFirst("###", "DDA"+Util.date("yyMMddhhmmss"));

			log.info("Request url: {}", this.getUrlList().get(i));
			log.info("Request method: {}", this.getReqMethod().get(i));
			log.info("Request body: {}", payload);
			String token = Util.createJWT(this.getPrivateKey(), Util.jsonToMap(payload));
			log.info("Token: {}", token);

			RestTemplate restTemplate = new RestTemplate();
			final HttpHeaders headers = new HttpHeaders();
			headers.set("Client-ID", this.getClientId());
			headers.set("API-Key", this.getApiKey());
			headers.set("Application-ID", this.getApplicationId());
			headers.set("Country", this.getCountry());
			headers.set("Authorization", token);
			headers.set("Content-Type", "application/json");
			headers.set("SSL_CLIENT_S_DN", this.getSsl());

			final HttpEntity<String> entity = new HttpEntity<String>(headers);

			ResponseEntity<Object> response = null;
			String responseStr = "";
			try {
				response = restTemplate.exchange(this.getUrlList().get(i), HttpMethod.resolve(this.getReqMethod().get(i)), entity, Object.class);
				responseStr = gson.toJson(response.getBody());
			} catch (HttpServerErrorException e) {
				log.info("Response code: {}", e.getStatusCode());
				log.info("Response body: {}", e.getResponseBodyAsString());
				continue;
			} catch (Exception e) {
				log.error("ERR: Error requesting url: {}", this.getUrlList().get(i));
				log.error("ERR MSG: {}", e.getMessage(), e);
				continue;
			}
			log.info("Response code: {}", response.getStatusCode());
			log.info("Response body: {}", responseStr);

			if (this.getApiNameList().get(i).contains("setup")) {
				log.info("*** setting JSON payload for EDDA status and cancel API ***");
				createEDDAStatusOrCancelPayload(payload, responseStr, gson, this.getDependent().get(i));
			}
		}
	}
	
	private void createEDDAStatusOrCancelPayload(String payload, String response, Gson gson, String fileNames) throws JsonIOException, JsonSyntaxException, FileNotFoundException {

		if (!fileNames.equals("0")) {
			EDDA edda = gson.fromJson(payload, EDDA.class);
			EDDASetupResponse eddaSetupResponse = gson.fromJson(response, EDDASetupResponse.class);
			
			for (String fileName : fileNames.split(",")) {

				if (!fileName.contains("might")) {
					DirectDebitCreation directDebitCreation = new DirectDebitCreation();
					directDebitCreation.setBankReference(eddaSetupResponse.getDirectDebitCreationStatus().getBankReference());
					directDebitCreation.setTransactionReference(edda.getDirectDebitCreation().getTransactionReference());
					directDebitCreation.setDdaReference(edda.getDirectDebitCreation().getDdaReference());
					directDebitCreation.setBillerAccount(edda.getDirectDebitCreation().getBillerAccount());


					try(FileWriter writer = new FileWriter(jsonLocation+"\\"+fileName)) {
						JsonElement je = gson.toJsonTree(directDebitCreation);
						JsonObject jo = new JsonObject();
						if (fileName.contains("cancel")) {
							jo.add("directDebitCancellation", je);
						} else if (fileName.contains("status")) {
							jo.add("directDebitCreation", je);
						}

						gson.toJson(jo, writer);
					} catch (JsonIOException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}

	public List<String> getDependent() {
		return dependent;
	}

	public void setDependent(List<String> dependent) {
		this.dependent = dependent;
	}
}