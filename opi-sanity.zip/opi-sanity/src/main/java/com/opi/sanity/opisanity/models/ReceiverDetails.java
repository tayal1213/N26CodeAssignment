package com.opi.sanity.opisanity.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReceiverDetails {
	private String accountName;
	private Account account;
	private String proxyType;
	private String proxyValue;
	private String bic;
}