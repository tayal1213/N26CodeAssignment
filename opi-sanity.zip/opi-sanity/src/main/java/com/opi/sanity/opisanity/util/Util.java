package com.opi.sanity.opisanity.util;

import java.io.IOException;
import java.security.interfaces.RSAPrivateKey;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.opi.sanity.opisanity.jwt.PemUtils;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class Util {

	private Util() {}

	public static String date(String format) {
		Date currentDate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(format);

		return sdf.format(currentDate);
	} 

	public static String createJWT(String privateKeyPath, Map claims) throws IOException {
		return Jwts.builder().setClaims(claims).signWith(SignatureAlgorithm.RS256, 
				(RSAPrivateKey) PemUtils.readPrivateKeyFromFile(privateKeyPath, "RSA")).compact();
	}

	public static Map jsonToMap(String jsonString) {
		return new Gson().fromJson(
				jsonString, new TypeToken<HashMap<String, Object>>() {}.getType()
				);
	}

}
