package com.opi.sanity.opisanity.jwt;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.EncodedKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Scanner;

import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PemUtils {

	private PemUtils() {}
	private static final Logger log = LoggerFactory.getLogger(PemUtils.class);

	private static byte[] parsePEMFile(File pemFile) throws IOException {
		if (!pemFile.isFile() || !pemFile.exists()) {
			throw new FileNotFoundException(String.format("The file '%s' doesn't exist.", pemFile.getAbsolutePath()));
		}
		byte[] content = null;
		try(PemReader reader = new PemReader(new FileReader(pemFile))) {
			PemObject pemObject = reader.readPemObject();
			content = pemObject.getContent();
		}
		
		return content;
	}

	public static PublicKey getPublicKey(byte[] keyBytes, String algorithm) {
		PublicKey publicKey = null;
		try {
			KeyFactory kf = KeyFactory.getInstance(algorithm);
			EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
			publicKey = kf.generatePublic(keySpec);
		} catch (NoSuchAlgorithmException e) {
			log.error("Could not reconstruct the public key, the given algorithm could not be found.");
		} catch (InvalidKeySpecException e) {
			log.error("Could not reconstruct the public key");
		}

		return publicKey;
	}

	private static PrivateKey getPrivateKey(byte[] keyBytes, String algorithm) {
		PrivateKey privateKey = null;
		try {
			KeyFactory kf = KeyFactory.getInstance(algorithm);
			EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
			privateKey = kf.generatePrivate(keySpec);
		} catch (NoSuchAlgorithmException e) {
			log.error("Could not reconstruct the private key, the given algorithm could not be found.");
		} catch (InvalidKeySpecException e) {
			log.error("Could not reconstruct the private key");
		}

		return privateKey;
	}

	public static PublicKey readPublicKeyFromFile(String filepath, String algorithm) throws IOException {
		byte[] bytes = PemUtils.parsePEMFile(new File(filepath));
		return PemUtils.getPublicKey(bytes, algorithm);
	}


	public static PrivateKey readPrivateKeyFromFile(String filepath, String algorithm) throws IOException {
		byte[] bytes = PemUtils.parsePEMFile(new File(filepath));
		return PemUtils.getPrivateKey(bytes, algorithm);
	}

	/**
	 * Parse an X509 Cert from a PEM string
	 *
	 * @param certificateString PEM format
	 * @return X.509 certificate object
	 * @throws IOException 
	 */
	public static RSAPublicKey parseX509Certificate(String filepath) throws GeneralSecurityException, IOException {
		try {
			String certificateString = readFile(filepath);
			CertificateFactory f = CertificateFactory.getInstance("X.509");
			X509Certificate certificate = (X509Certificate) f
					.generateCertificate(new ByteArrayInputStream(certificateString.getBytes("UTF-8")));
			return (RSAPublicKey) certificate.getPublicKey();

		} catch (UnsupportedEncodingException e) {
			throw new GeneralSecurityException(e);
		}
	}

	public static RSAPublicKey parseX509Certificate(byte[] cert) throws GeneralSecurityException, IOException {
		try {
			String certificateString = createStringFromByte(cert);
			CertificateFactory f = CertificateFactory.getInstance("X.509");
			X509Certificate certificate = (X509Certificate) f
					.generateCertificate(new ByteArrayInputStream(certificateString.getBytes("UTF-8")));
			return (RSAPublicKey) certificate.getPublicKey();

		} catch (UnsupportedEncodingException e) {
			throw new GeneralSecurityException(e);
		}
	}

	public static String createStringFromByte(byte[] cert) throws IOException {
		StringBuilder fileContents = new StringBuilder();
		Scanner scanner = new Scanner(new ByteArrayInputStream(cert));
		String lineSeparator = System.getProperty("line.separator");
		try {
			while(scanner.hasNextLine()) {
				fileContents.append(scanner.nextLine() + lineSeparator);
			}
			return fileContents.toString();
		} finally {
			scanner.close();
		}
	}

	public static String readFile(String pathname) throws IOException {
		File file = new File(pathname);
		StringBuilder fileContents = new StringBuilder((int)file.length());
		Scanner scanner = new Scanner(file);
		String lineSeparator = System.getProperty("line.separator");

		try {
			while(scanner.hasNextLine()) {
				fileContents.append(scanner.nextLine() + lineSeparator);
			}
			return fileContents.toString();
		} finally {
			scanner.close();
		}
	}
	
	public static void main(String[] args) throws IOException {
		readPrivateKeyFromFile("D:\\OPI-SANITY-TOOL\\certs\\fef37840-0cf3-4922-86e7-99c3e1d929b9.pem", "RSA");
	}

}