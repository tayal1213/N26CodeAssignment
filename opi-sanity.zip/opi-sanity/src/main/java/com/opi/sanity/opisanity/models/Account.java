package com.opi.sanity.opisanity.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Account {
	
	private String accountNumber;
	private String accountCurrency;
	private String accountType;
	
}
