package com.opi.sanity.opisanity.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EDDA {
	
	private DirectDebitCreation directDebitCreation;

}
