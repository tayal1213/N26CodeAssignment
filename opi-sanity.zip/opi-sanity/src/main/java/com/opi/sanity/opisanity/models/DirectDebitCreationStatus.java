package com.opi.sanity.opisanity.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DirectDebitCreationStatus {
	
	private String transactionReference;
	private String bankReference;
	private String code;
	private String description;
	private String billerName;
	private Links links;
	@Override
	public String toString() {
		return "[transactionReference=" + transactionReference + ", bankReference="
				+ bankReference + ", code=" + code + ", description=" + description + ", billerName=" + billerName
				+ ", links=" + links + "]";
	}

}
