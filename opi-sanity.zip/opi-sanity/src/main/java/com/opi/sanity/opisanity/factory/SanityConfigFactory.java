package com.opi.sanity.opisanity.factory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.opi.sanity.opisanity.config.CIConfig;
import com.opi.sanity.opisanity.config.EDDACancelConfig;
import com.opi.sanity.opisanity.config.EDDAConfig;
import com.opi.sanity.opisanity.config.EDDATypeTwoConfig;
import com.opi.sanity.opisanity.config.MightyConfig;
import com.opi.sanity.opisanity.config.PCPConfig;
import com.opi.sanity.opisanity.config.SanityConfig;

@Configuration
public class SanityConfigFactory {

	@Autowired
	PCPConfig pcpConfig;
	
	@Autowired
	CIConfig ciConfig;
	
	@Autowired
	EDDAConfig eddaConfig;
	
	@Autowired
	MightyConfig mightyConfig;
	
	@Autowired
	EDDACancelConfig eddaCancelConfig;
	
	@Autowired
	EDDATypeTwoConfig eddaTypeTwoConfig;
	
	public SanityConfig getConfig(String configName) {
		
		if (configName.equalsIgnoreCase("pcp")) {
			return pcpConfig;
		} else if (configName.equalsIgnoreCase("ci")) {
			return ciConfig;
		} else if (configName.equalsIgnoreCase("edda")) {
			return eddaConfig;
		} else if (configName.equalsIgnoreCase("mighty")) {
			return mightyConfig;
		} else if (configName.equalsIgnoreCase("eddacancel")) {
			return eddaCancelConfig;
		} else if (configName.equalsIgnoreCase("eddatypetwo")) {
			return eddaTypeTwoConfig;
		} else {
			return null;
		}
	}
}
