package com.opi.sanity.opisanity.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DirectDebitCreation {
	
	private String transactionReference;
	private String bankReference;
    private String customerId;
    private String customerIdType;
    private String customerIdCountryCode;
    private String ddaReference;
    private String requestType;
    private String purposeCode;
    private String billerOwnReferenceCode;
    private Account billerAccount;
    
}
