package com.opi.sanity.opisanity.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PCP {
	
	private String transactionReference;
	private String purposeCode;
	private String endToEndId;
	private OriginatorDetails originatorDetails;
	private ReceiverDetails receiverDetails;
	private PaymentAmount paymentAmount;

}
