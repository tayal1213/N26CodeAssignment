package com.opi.sanity.opisanity.config;

import java.io.FileReader;
import java.io.IOException;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.opi.sanity.opisanity.util.Util;


@ConfigurationProperties("ci")
@Configuration
public class CIConfig extends SanityConfig {
	
	private static final Logger log = LogManager.getLogger(CIConfig.class);

	@Override
	public void initiateApiCalls() throws IOException {
		JsonParser parser = new JsonParser();
		for (int i=0; i<this.getApiNameList().size(); i++) {
			
			log.info("*** Starting for API: {} ***", this.getApiNameList().get(i));
			
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			JsonElement json = parser.parse(new FileReader(this.getPayloadList().get(i)));
			String payload = gson.toJson(json).replace("##", "SANIT"+Util.date("yyyyMMddhhmmss"));
			log.info("Request url: {}", this.getUrlList().get(i));
			log.info("Request method: {}", this.getReqMethod().get(i));
			log.info("Request body: {}", payload);
			String token = Util.createJWT(this.getPrivateKey(), Util.jsonToMap(payload));
			log.info("Token: {}", token);
			
			RestTemplate restTemplate = new RestTemplate();
			final HttpHeaders headers = new HttpHeaders();
	        headers.set("Client-ID", this.getClientId());
	        headers.set("API-Key", this.getApiKey());
	        headers.set("Application-ID", this.getApplicationId());
	        headers.set("Country", this.getCountry());
	        headers.set("Authorization", token);
	        headers.set("Content-Type", "application/json");
	        headers.set("SSL_CLIENT_S_DN", this.getSsl());
	        
	        final HttpEntity<String> entity = new HttpEntity<String>(headers);
	        
	        ResponseEntity<Map> response = null;
	        try {
	        	response = restTemplate.exchange(this.getUrlList().get(i), HttpMethod.resolve(this.getReqMethod().get(i)), entity, Map.class);
	        } catch (HttpServerErrorException e) {
	        	log.info("Response code: {}", e.getStatusCode());
	        	log.info("Response body: {}", e.getResponseBodyAsString());
	        	continue;
			} catch (Exception e) {
				log.error("ERR: Error requesting url: {}", this.getUrlList().get(i));
				log.error("ERR MSG: {}", e.getMessage(), e);
				continue;
			}
	        log.info("Response code: {}", response.getStatusCode());
        	log.info("Response body: {}", response.getBody());
			
		}
		
	}

}