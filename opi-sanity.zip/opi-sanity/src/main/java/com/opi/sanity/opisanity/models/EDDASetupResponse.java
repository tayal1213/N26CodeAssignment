package com.opi.sanity.opisanity.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EDDASetupResponse {

	private DirectDebitCreationStatus directDebitCreationStatus;

	@Override
	public String toString() {
		return "EDDASetupResponse [directDebitCreationStatus=" + directDebitCreationStatus + "]";
	}
	
	
}
