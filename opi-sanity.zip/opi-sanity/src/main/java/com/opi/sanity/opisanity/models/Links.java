package com.opi.sanity.opisanity.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Links {

	@Override
	public String toString() {
		return "[android=" + android + ", ios=" + ios + "]";
	}
	private String android;
	private String ios;
	
}
